// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "types.hpp"
#include <string>
#include <cstdint>

namespace hush::daw_core {

// Binary session container. Format is versioned and intentionally minimal.
struct SessionHeader {
    char     magic[8]     = {'H','U','S','H','S','E','S','S'}; // "HUSHSESS"
    uint32_t version      = 1;
    uint32_t flags        = 0;
    double   sampleRate   = 48000.0;
    int64_t  lengthFrames = 0;
};

class Session; // forward

namespace session_io {

// Write a complete session to a binary file.
// Throws std::runtime_error on I/O failure.
void save(const Session& session, const std::string& path);

// Load a session from a binary file.
// Throws on bad magic, unsupported version, or I/O error.
Session load(const std::string& path);

} // namespace session_io
} // namespace hush::daw_core
