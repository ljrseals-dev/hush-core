// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "types.hpp"
#include "transport.hpp"
#include "render_graph.hpp"
#include "session_io.hpp"

#include <memory>
#include <string>

// Forward declarations of the concrete engine types provided by Tier 1 / Tier 2.
// The real headers are expected to be on the include path once those engines
// are integrated (as confirmed by the caller).
namespace hush::immersive { class Renderer; }
namespace hush::score     { class Score; }
namespace hush::plugins   { class PluginHost; }
namespace hush::video     { class Movie; }

namespace hush::daw_core {

class Session {
public:
    Session();
    ~Session();

    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;
    Session(Session&&) noexcept;
    Session& operator=(Session&&) noexcept;

    // ---- Configuration ----------------------------------------------------
    void setSampleRate(SampleRate r);
    SampleRate sampleRate() const noexcept;

    void setLength(FrameIndex frames);
    FrameIndex length() const noexcept;

    // ---- Subsystem ownership ----------------------------------------------
    // Each create* returns a stable string id that can be used later.
    ImmersiveSceneHandle createImmersiveScene(const std::string& name = {});
    ScoreHandle          createScore(const std::string& name = {});
    PluginChainHandle    createPluginChain(const std::string& name = {});
    VideoTimelineHandle  createVideoTimeline(const std::string& name = {});

    // Accessors — throw std::out_of_range if id is unknown.
    hush::immersive::Renderer& immersive(const ImmersiveSceneHandle& h);
    hush::score::Score&        score(const ScoreHandle& h);
    hush::plugins::PluginHost& plugins(const PluginChainHandle& h);
    hush::video::Movie&        video(const VideoTimelineHandle& h);

    // ---- Transport --------------------------------------------------------
    Transport& transport() noexcept;
    const Transport& transport() const noexcept;

    // ---- Render graph -----------------------------------------------------
    // Rebuild the graph from the current subsystem state.
    // Call after any structural change.
    void rebuildGraph();

    // Offline render of [start, start+count).
    AudioBuffer render(FrameIndex start, FrameIndex count);

    // Convenience: render the whole session and write interleaved float32 WAV.
    void renderToWav(const std::string& path);

    // ---- Persistence ------------------------------------------------------
    friend void session_io::save(const Session&, const std::string&);
    friend Session session_io::load(const std::string&);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace hush::daw_core
