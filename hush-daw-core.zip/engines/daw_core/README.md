# hush-daw-core

Tier-3 session engine for the Hush DAW.

## What it provides

- `hush::daw_core::Session` — owns immersive scenes, scores, plugin hosts and video timelines via stable opaque handles.
- Deterministic binary session format (`HUSHSESS` v1).
- Transport clock with play / stop / record and optional loop.
- Offline render graph that can produce interleaved float32 WAV.
- CLI `hush-session` for create / inspect / render.

## Requirements

- CMake 3.16+
- C++17 compiler (`CMAKE_CXX_EXTENSIONS OFF`)
- The four prior engines already integrated and exported as:
  - `hush::immersive`
  - `hush::score`
  - `hush::plugins`
  - `hush::video`

## Build

From the repository root (after Tier 1 and Tier 2 are present):

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --target hush_daw_core hush-session test_daw_core -j$(nproc)
ctest --test-dir build --output-on-failure
```

## CLI

```bash
# Create a 10-second empty session
./build/engines/daw_core/hush-session new demo.hushsess --rate 48000 --length 480000

# Inspect
./build/engines/daw_core/hush-session info demo.hushsess

# Render (produces silence until concrete RenderNodes are wired)
./build/engines/daw_core/hush-session render demo.hushsess demo.wav
```

## Parent CMakeLists.txt wiring

Add after the other engine subdirectories:

```cmake
add_subdirectory(engines/daw_core)
```

## License

MIT — Copyright (c) 2026 ljrseals-dev
