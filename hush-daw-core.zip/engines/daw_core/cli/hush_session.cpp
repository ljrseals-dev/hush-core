// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/daw_core/session.hpp"
#include <iostream>
#include <string>

static void usage() {
    std::cout
        << "hush-session — Hush DAW session engine CLI\n"
        << "Usage:\n"
        << "  hush-session --help\n"
        << "  hush-session new    <file.hushsess> [--rate 48000] [--length 480000]\n"
        << "  hush-session info   <file.hushsess>\n"
        << "  hush-session render <file.hushsess> <out.wav>\n"
        << std::endl;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        usage();
        return 0;
    }

    const std::string cmd = argv[1];
    if (cmd == "--help" || cmd == "-h") {
        usage();
        return 0;
    }

    try {
        if (cmd == "new" && argc >= 3) {
            hush::daw_core::Session s;
            double   rate = 48000.0;
            int64_t  len  = 480000; // 10 s @ 48 kHz default

            for (int i = 3; i < argc; ++i) {
                const std::string a = argv[i];
                if (a == "--rate" && i + 1 < argc)
                    rate = std::stod(argv[++i]);
                else if (a == "--length" && i + 1 < argc)
                    len = std::stoll(argv[++i]);
            }

            s.setSampleRate(rate);
            s.setLength(len);
            hush::daw_core::session_io::save(s, argv[2]);
            std::cout << "Created " << argv[2]
                      << " (" << len << " frames @ " << rate << " Hz)\n";
            return 0;
        }

        if (cmd == "info" && argc >= 3) {
            auto s = hush::daw_core::session_io::load(argv[2]);
            std::cout << "Sample rate : " << s.sampleRate() << "\n"
                      << "Length      : " << s.length() << " frames\n"
                      << "Duration    : " << (s.length() / s.sampleRate()) << " s\n";
            return 0;
        }

        if (cmd == "render" && argc >= 4) {
            auto s = hush::daw_core::session_io::load(argv[2]);
            s.renderToWav(argv[3]);
            std::cout << "Wrote " << argv[3] << "\n";
            return 0;
        }

        usage();
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
}
