// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/daw_core/session.hpp"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <cstdio>

#define CHECK(cond) do { \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " at " << __FILE__ << ":" << __LINE__ << "\n"; \
        std::exit(1); \
    } \
} while (0)

int main() {
    using namespace hush::daw_core;

    // ------------------------------------------------------------------
    // Happy path: create → configure → save → load
    // ------------------------------------------------------------------
    {
        Session s;
        s.setSampleRate(48000.0);
        s.setLength(96000);
        CHECK(s.sampleRate() == 48000.0);
        CHECK(s.length() == 96000);

        session_io::save(s, "test_session.hushsess");
        Session t = session_io::load("test_session.hushsess");
        CHECK(t.sampleRate() == 48000.0);
        CHECK(t.length() == 96000);
        std::remove("test_session.hushsess");
    }

    // ------------------------------------------------------------------
    // Edge: zero-length session — renderToWav must fail
    // ------------------------------------------------------------------
    {
        Session s;
        s.setSampleRate(44100.0);
        s.setLength(0);
        bool threw = false;
        try { s.renderToWav("should_fail.wav"); } catch (...) { threw = true; }
        CHECK(threw);
    }

    // ------------------------------------------------------------------
    // Failure mode: negative sample rate
    // ------------------------------------------------------------------
    {
        Session s;
        bool threw = false;
        try { s.setSampleRate(-1.0); } catch (const std::invalid_argument&) { threw = true; }
        CHECK(threw);
    }

    // ------------------------------------------------------------------
    // Failure mode: bad magic on load
    // ------------------------------------------------------------------
    {
        {
            std::ofstream ofs("bad.hushsess", std::ios::binary);
            ofs.write("BADMAGIC", 8);
        }
        bool threw = false;
        try { session_io::load("bad.hushsess"); } catch (...) { threw = true; }
        CHECK(threw);
        std::remove("bad.hushsess");
    }

    // ------------------------------------------------------------------
    // Transport basic behaviour
    // ------------------------------------------------------------------
    {
        Transport tr;
        tr.setSampleRate(48000.0);
        tr.setPosition(100);
        CHECK(tr.position() == 100);

        tr.play();
        CHECK(tr.state() == TransportState::Playing);

        auto adv = tr.advance(50);
        CHECK(adv.begin == 100);
        CHECK(adv.end   == 150);
        CHECK(tr.position() == 150);

        tr.stop();
        CHECK(tr.state() == TransportState::Stopped);
    }

    // ------------------------------------------------------------------
    // Transport loop
    // ------------------------------------------------------------------
    {
        Transport tr;
        tr.setSampleRate(48000.0);
        tr.setLoop(0, 1000);
        tr.setPosition(900);
        auto adv = tr.advance(200);
        CHECK(adv.looped == true);
        CHECK(adv.end == 1000);
        CHECK(tr.position() == 100); // 900+200-1000 = 100
    }

    // ------------------------------------------------------------------
    // RenderGraph empty path produces silence of correct size
    // ------------------------------------------------------------------
    {
        RenderGraph g;
        g.setMasterChannels(2);
        auto buf = g.render(0, 128);
        CHECK(buf.channels == 2);
        CHECK(buf.frames   == 128);
        CHECK(buf.data.size() == 256);
        for (float s : buf.data)
            CHECK(s == 0.f);
    }

    // ------------------------------------------------------------------
    // RenderGraph rejects null node
    // ------------------------------------------------------------------
    {
        RenderGraph g;
        bool threw = false;
        try { g.addNode(nullptr); } catch (const std::invalid_argument&) { threw = true; }
        CHECK(threw);
    }

    // ------------------------------------------------------------------
    // Session render range check
    // ------------------------------------------------------------------
    {
        Session s;
        s.setSampleRate(48000.0);
        s.setLength(1000);
        bool threw = false;
        try { s.render(900, 200); } catch (const std::out_of_range&) { threw = true; }
        CHECK(threw);
    }

    std::cout << "All daw_core tests passed\n";
    return 0;
}
