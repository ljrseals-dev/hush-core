// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#include "hush/score_cli/midi_reader.hpp"
#include "hush/score_cli/midi_writer.hpp"
#include "hush/score_cli/score_cli.hpp"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

#define CHECK(cond) do { \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " at " << __FILE__ << ":" << __LINE__ << "\n"; \
        std::exit(1); \
    } \
} while (0)

namespace {

void writeMinimalMidi(const std::string& path) {
    // Hand-crafted SMF format-0 with one note (C4, 1 beat at 480 TPQ)
    const unsigned char bytes[] = {
        // Header
        0x4D,0x54,0x68,0x64, 0x00,0x00,0x00,0x06,
        0x00,0x00,             // format 0
        0x00,0x01,             // 1 track
        0x01,0xE0,             // 480 ticks/quarter
        // Track
        0x4D,0x54,0x72,0x6B, 0x00,0x00,0x00,0x1C,
        // delta 0, tempo 500000
        0x00,0xFF,0x51,0x03, 0x07,0xA1,0x20,
        // delta 0, time-sig 4/4
        0x00,0xFF,0x58,0x04, 0x04,0x02,0x18,0x08,
        // delta 0, note-on C4 vel 100
        0x00,0x90,0x3C,0x64,
        // delta 480, note-off
        0x83,0x60,0x80,0x3C,0x00,
        // end of track
        0x00,0xFF,0x2F,0x00
    };
    std::ofstream out(path, std::ios::binary);
    out.write(reinterpret_cast<const char*>(bytes), sizeof(bytes));
}

} // namespace

int main() {
    const std::string tmpMidi = "test_score_cli_tmp.mid";
    const std::string tmpXml  = "test_score_cli_tmp.xml";
    const std::string tmpTxt  = "test_score_cli_tmp.txt";

    // --- Happy path ---
    writeMinimalMidi(tmpMidi);
    auto midi = hush::score_cli::readMidiFile(tmpMidi);
    CHECK(midi.format == 0);
    CHECK(midi.ticksPerQuarter == 480);
    CHECK(!midi.tracks.empty());
    CHECK(midi.tracks[0].notes.size() == 1);
    CHECK(midi.tracks[0].notes[0].pitch == 60);
    CHECK(midi.tracks[0].notes[0].durationTicks == 480);

    auto score = hush::score_cli::midiToScore(midi);
    hush::score_cli::writeMusicXml(score, tmpXml);
    hush::score_cli::writeEngravedText(score, tmpTxt);

    // --- Round-trip via writer ---
    hush::score_cli::writeMidiFile("test_score_cli_round.mid", midi);
    auto midi2 = hush::score_cli::readMidiFile("test_score_cli_round.mid");
    CHECK(!midi2.tracks.empty());
    CHECK(midi2.tracks[0].notes.size() >= 1);

    // --- Failure mode: non-existent file ---
    bool threw = false;
    try {
        hush::score_cli::readMidiFile("does_not_exist_42.mid");
    } catch (const hush::score_cli::MidiError&) {
        threw = true;
    }
    CHECK(threw);

    // --- Failure mode: truncated / garbage ---
    {
        std::ofstream bad("test_score_cli_bad.mid", std::ios::binary);
        bad << "not a midi file";
    }
    threw = false;
    try {
        hush::score_cli::readMidiFile("test_score_cli_bad.mid");
    } catch (const hush::score_cli::MidiError&) {
        threw = true;
    }
    CHECK(threw);

    // Cleanup
    std::remove(tmpMidi.c_str());
    std::remove(tmpXml.c_str());
    std::remove(tmpTxt.c_str());
    std::remove("test_score_cli_round.mid");
    std::remove("test_score_cli_bad.mid");

    std::cout << "All score-cli tests passed.\n";
    return 0;
}
