// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#pragma once

#include "hush/score_cli/midi_reader.hpp"
#include <string>
#include <vector>

// Minimal local Score model so this engine is self-contained when
// the prior-art hush::score is not yet present in the tree.
namespace hush {
namespace score {

struct Note {
    uint32_t startTicks = 0;
    uint32_t durationTicks = 0;
    uint8_t pitch = 60;
    uint8_t velocity = 100;
    uint8_t channel = 0;
};

class Score {
public:
    static Score fromMidiNotes(const std::vector<Note>& notes,
                               uint16_t ticksPerQuarter,
                               uint32_t usPerQuarter);

    std::string toMusicXml() const;
    std::string toEngravedText() const;

    const std::vector<Note>& notes() const { return notes_; }
    uint16_t ticksPerQuarter() const { return tpq_; }
    uint32_t microsecondsPerQuarter() const { return uspq_; }

private:
    std::vector<Note> notes_;
    uint16_t tpq_ = 480;
    uint32_t uspq_ = 500000;
};

} // namespace score
} // namespace hush

namespace hush {
namespace score_cli {

struct ConvertOptions {
    std::string partName; // empty = all channels / first track
};

/// Convert a parsed MidiFile into a hush::score::Score.
/// Notes are sorted by startTicks before measure distribution
/// (required by Score::fromMidiNotes).
hush::score::Score midiToScore(const MidiFile& midi,
                               const ConvertOptions& opts = {});

/// High-level helpers used by the CLI.
void writeMusicXml(const hush::score::Score& score, const std::string& path);
void writeEngravedText(const hush::score::Score& score, const std::string& path);
void writePdfViaLilyPond(const hush::score::Score& score, const std::string& path);

} // namespace score_cli
} // namespace hush
