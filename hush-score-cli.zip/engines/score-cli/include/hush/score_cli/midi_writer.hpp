// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#pragma once

#include "hush/score_cli/midi_reader.hpp"
#include <string>

namespace hush {
namespace score_cli {

/// Write a minimal SMF format-1 file containing the given notes.
/// Used by tests and by the neural-lite engine when present.
void writeMidiFile(const std::string& path, const MidiFile& midi);

} // namespace score_cli
} // namespace hush
