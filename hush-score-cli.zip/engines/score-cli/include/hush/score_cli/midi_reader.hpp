// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#pragma once

#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>

namespace hush {
namespace score_cli {

struct MidiError : public std::runtime_error {
    explicit MidiError(const std::string& msg) : std::runtime_error(msg) {}
};

struct TempoEvent {
    uint32_t tick = 0;
    uint32_t microsecondsPerQuarter = 500000; // 120 BPM default
};

struct TimeSigEvent {
    uint32_t tick = 0;
    uint8_t numerator = 4;
    uint8_t denominator = 4; // power of two (2=quarter, 3=eighth ...)
};

struct MidiNote {
    uint32_t startTicks = 0;
    uint32_t durationTicks = 0;
    uint8_t channel = 0;
    uint8_t pitch = 60;
    uint8_t velocity = 100;
};

struct MidiTrack {
    std::string name;
    std::vector<MidiNote> notes;
};

struct MidiFile {
    uint16_t format = 0;          // 0 or 1
    uint16_t ticksPerQuarter = 480;
    std::vector<TempoEvent> tempos;
    std::vector<TimeSigEvent> timeSigs;
    std::vector<MidiTrack> tracks;
};

/// Parse a Standard MIDI File (format 0 or 1) from a path.
/// Throws MidiError on any structural or I/O failure.
MidiFile readMidiFile(const std::string& path);

} // namespace score_cli
} // namespace hush
