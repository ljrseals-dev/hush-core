# hush-score (score-cli)

MIDI → MusicXML 3.1 / engraved ASCII / optional LilyPond PDF.

## Build

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Standalone (this directory only):

```bash
cmake -S engines/score-cli -B build-score-cli
cmake --build build-score-cli
ctest --test-dir build-score-cli --output-on-failure
```

## Run

```bash
# help
./build/engines/score-cli/hush-score --help

# default: engraved text to stdout
./build/engines/score-cli/hush-score example.mid

# explicit outputs
./build/engines/score-cli/hush-score example.mid \
    --xml score.xml \
    --text score.txt \
    --pdf score.pdf          # requires lilypond on PATH
```

## Design

- Pure `std::` SMF reader (format 0 & 1). No external MIDI library.
- Notes are sorted by `startTicks` before being handed to `Score::fromMidiNotes`.
- A minimal local `hush::score` model is included so the engine compiles
  stand-alone when the full prior-art score library is not yet present.
- PDF path shells out to `lilypond`; if the binary is missing the process
  exits with a clear error and leaves no partial file.

## License

MIT — Copyright (c) 2026 ljrseals-dev
