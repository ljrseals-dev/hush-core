// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#include "hush/score_cli/midi_reader.hpp"

#include <algorithm>
#include <cstring>
#include <fstream>
#include <vector>

namespace hush {
namespace score_cli {
namespace {

uint32_t readUint32BE(const uint8_t* p) {
    return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) |
           (uint32_t(p[2]) << 8)  |  uint32_t(p[3]);
}

uint16_t readUint16BE(const uint8_t* p) {
    return (uint16_t(p[0]) << 8) | uint16_t(p[1]);
}

uint32_t readVarLen(const uint8_t*& p, const uint8_t* end) {
    uint32_t value = 0;
    for (int i = 0; i < 4; ++i) {
        if (p >= end)
            throw MidiError("truncated variable-length quantity");
        uint8_t b = *p++;
        value = (value << 7) | (b & 0x7F);
        if ((b & 0x80) == 0)
            break;
    }
    return value;
}

} // namespace

MidiFile readMidiFile(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in)
        throw MidiError("cannot open MIDI file: " + path);

    in.seekg(0, std::ios::end);
    const auto size = static_cast<std::streamsize>(in.tellg());
    in.seekg(0, std::ios::beg);
    if (size < 14)
        throw MidiError("file too small to be a MIDI file");

    std::vector<uint8_t> data(static_cast<size_t>(size));
    if (!in.read(reinterpret_cast<char*>(data.data()), size))
        throw MidiError("failed to read MIDI file");

    const uint8_t* p = data.data();
    const uint8_t* end = p + data.size();

    if (std::memcmp(p, "MThd", 4) != 0)
        throw MidiError("missing MThd header");
    p += 4;

    if (readUint32BE(p) != 6)
        throw MidiError("unexpected MThd length");
    p += 4;

    MidiFile midi;
    midi.format = readUint16BE(p); p += 2;
    const uint16_t nTracks = readUint16BE(p); p += 2;
    const uint16_t division = readUint16BE(p); p += 2;

    if (midi.format > 1)
        throw MidiError("only SMF format 0 and 1 are supported");
    if (division & 0x8000)
        throw MidiError("SMPTE time division not supported");
    midi.ticksPerQuarter = division;

    // Default tempo / time-sig if none appear in the file
    midi.tempos.push_back({0, 500000});
    midi.timeSigs.push_back({0, 4, 2}); // 4/4, denominator power-of-two = 2

    for (uint16_t t = 0; t < nTracks; ++t) {
        if (p + 8 > end)
            throw MidiError("truncated track header");
        if (std::memcmp(p, "MTrk", 4) != 0)
            throw MidiError("missing MTrk header");
        p += 4;
        const uint32_t trackLen = readUint32BE(p); p += 4;
        if (p + trackLen > end)
            throw MidiError("truncated track data");

        const uint8_t* trackEnd = p + trackLen;
        uint32_t absTick = 0;
        uint8_t runningStatus = 0;
        MidiTrack track;
        // Active note-ons keyed by (channel<<8 | pitch)
        struct Active { uint32_t start; uint8_t vel; };
        std::vector<Active> active(128 * 16, {0, 0});

        while (p < trackEnd) {
            const uint32_t delta = readVarLen(p, trackEnd);
            absTick += delta;
            if (p >= trackEnd)
                break;

            uint8_t status = *p;
            if (status & 0x80) {
                runningStatus = status;
                ++p;
            } else {
                status = runningStatus;
            }

            const uint8_t type = status & 0xF0;
            const uint8_t channel = status & 0x0F;

            if (status == 0xFF) { // meta
                if (p >= trackEnd) throw MidiError("truncated meta event");
                const uint8_t meta = *p++;
                const uint32_t len = readVarLen(p, trackEnd);
                if (p + len > trackEnd)
                    throw MidiError("truncated meta data");

                if (meta == 0x51 && len == 3) { // tempo
                    uint32_t us = (uint32_t(p[0]) << 16) | (uint32_t(p[1]) << 8) | p[2];
                    midi.tempos.push_back({absTick, us});
                } else if (meta == 0x58 && len >= 2) { // time signature
                    midi.timeSigs.push_back({absTick, p[0], p[1]});
                } else if (meta == 0x03 && len > 0) { // track name
                    track.name.assign(reinterpret_cast<const char*>(p), len);
                }
                p += len;
            } else if (type == 0x90 || type == 0x80) { // note on / off
                if (p + 2 > trackEnd) throw MidiError("truncated note event");
                const uint8_t pitch = p[0];
                const uint8_t vel   = p[1];
                p += 2;
                if (pitch > 127) continue;

                const size_t key = size_t(channel) * 128 + pitch;
                if (type == 0x90 && vel > 0) {
                    active[key] = {absTick, vel};
                } else {
                    if (active[key].vel > 0) {
                        MidiNote n;
                        n.startTicks    = active[key].start;
                        n.durationTicks = absTick - active[key].start;
                        n.channel       = channel;
                        n.pitch         = pitch;
                        n.velocity      = active[key].vel;
                        if (n.durationTicks == 0)
                            n.durationTicks = 1; // zero-length guard
                        track.notes.push_back(n);
                        active[key] = {0, 0};
                    }
                }
            } else if (type == 0xA0 || type == 0xB0 || type == 0xE0) {
                if (p + 2 > trackEnd) throw MidiError("truncated two-byte event");
                p += 2;
            } else if (type == 0xC0 || type == 0xD0) {
                if (p + 1 > trackEnd) throw MidiError("truncated one-byte event");
                p += 1;
            } else if (status == 0xF0 || status == 0xF7) { // sysex
                const uint32_t len = readVarLen(p, trackEnd);
                if (p + len > trackEnd) throw MidiError("truncated sysex");
                p += len;
            } else {
                throw MidiError("unsupported MIDI status byte");
            }
        }

        // Close any hanging note-ons at end of track
        for (size_t key = 0; key < active.size(); ++key) {
            if (active[key].vel > 0) {
                MidiNote n;
                n.startTicks    = active[key].start;
                n.durationTicks = absTick > active[key].start
                                      ? absTick - active[key].start : 1;
                n.channel       = static_cast<uint8_t>(key / 128);
                n.pitch         = static_cast<uint8_t>(key % 128);
                n.velocity      = active[key].vel;
                track.notes.push_back(n);
            }
        }

        if (!track.notes.empty() || !track.name.empty())
            midi.tracks.push_back(std::move(track));

        p = trackEnd;
    }

    // Ensure tempos / time-sigs are sorted
    std::sort(midi.tempos.begin(), midi.tempos.end(),
              [](const TempoEvent& a, const TempoEvent& b) {
                  return a.tick < b.tick;
              });
    std::sort(midi.timeSigs.begin(), midi.timeSigs.end(),
              [](const TimeSigEvent& a, const TimeSigEvent& b) {
                  return a.tick < b.tick;
              });

    return midi;
}

} // namespace score_cli
} // namespace hush
