// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#include "hush/score_cli/midi_writer.hpp"

#include <algorithm>
#include <fstream>
#include <stdexcept>
#include <vector>

namespace hush {
namespace score_cli {
namespace {

void writeUint32BE(std::vector<uint8_t>& out, uint32_t v) {
    out.push_back(static_cast<uint8_t>((v >> 24) & 0xFF));
    out.push_back(static_cast<uint8_t>((v >> 16) & 0xFF));
    out.push_back(static_cast<uint8_t>((v >> 8)  & 0xFF));
    out.push_back(static_cast<uint8_t>( v        & 0xFF));
}

void writeUint16BE(std::vector<uint8_t>& out, uint16_t v) {
    out.push_back(static_cast<uint8_t>((v >> 8) & 0xFF));
    out.push_back(static_cast<uint8_t>( v       & 0xFF));
}

void writeVarLen(std::vector<uint8_t>& out, uint32_t value) {
    uint8_t buf[4];
    int n = 0;
    buf[n++] = value & 0x7F;
    while (value >>= 7)
        buf[n++] = 0x80 | (value & 0x7F);
    while (n--)
        out.push_back(buf[n]);
}

} // namespace

void writeMidiFile(const std::string& path, const MidiFile& midi) {
    // Minimal format-1: header + one track containing all notes
    std::vector<uint8_t> trackData;
    uint32_t lastTick = 0;

    // Tempo meta at tick 0
    writeVarLen(trackData, 0);
    trackData.push_back(0xFF);
    trackData.push_back(0x51);
    trackData.push_back(0x03);
    uint32_t us = midi.tempos.empty() ? 500000 : midi.tempos.front().microsecondsPerQuarter;
    trackData.push_back(static_cast<uint8_t>((us >> 16) & 0xFF));
    trackData.push_back(static_cast<uint8_t>((us >> 8)  & 0xFF));
    trackData.push_back(static_cast<uint8_t>( us        & 0xFF));

    // Time signature
    writeVarLen(trackData, 0);
    trackData.push_back(0xFF);
    trackData.push_back(0x58);
    trackData.push_back(0x04);
    trackData.push_back(4); // numerator
    trackData.push_back(2); // denominator (quarter)
    trackData.push_back(24);
    trackData.push_back(8);

    // Collect and sort all notes
    std::vector<MidiNote> notes;
    for (const auto& t : midi.tracks)
        notes.insert(notes.end(), t.notes.begin(), t.notes.end());
    std::sort(notes.begin(), notes.end(),
              [](const MidiNote& a, const MidiNote& b) {
                  return a.startTicks < b.startTicks;
              });

    for (const auto& n : notes) {
        // note-on
        uint32_t delta = n.startTicks - lastTick;
        writeVarLen(trackData, delta);
        trackData.push_back(0x90 | (n.channel & 0x0F));
        trackData.push_back(n.pitch);
        trackData.push_back(n.velocity);
        lastTick = n.startTicks;

        // note-off
        delta = n.durationTicks;
        writeVarLen(trackData, delta);
        trackData.push_back(0x80 | (n.channel & 0x0F));
        trackData.push_back(n.pitch);
        trackData.push_back(0);
        lastTick += n.durationTicks;
    }

    // End of track
    writeVarLen(trackData, 0);
    trackData.push_back(0xFF);
    trackData.push_back(0x2F);
    trackData.push_back(0x00);

    // Assemble file
    std::vector<uint8_t> file;
    file.insert(file.end(), {'M', 'T', 'h', 'd'});
    writeUint32BE(file, 6);
    writeUint16BE(file, 1); // format 1
    writeUint16BE(file, 1); // one track
    writeUint16BE(file, midi.ticksPerQuarter ? midi.ticksPerQuarter : 480);

    file.insert(file.end(), {'M', 'T', 'r', 'k'});
    writeUint32BE(file, static_cast<uint32_t>(trackData.size()));
    file.insert(file.end(), trackData.begin(), trackData.end());

    std::ofstream out(path, std::ios::binary);
    if (!out)
        throw MidiError("cannot write MIDI file: " + path);
    out.write(reinterpret_cast<const char*>(file.data()),
              static_cast<std::streamsize>(file.size()));
    if (!out)
        throw MidiError("failed while writing MIDI file");
}

} // namespace score_cli
} // namespace hush
