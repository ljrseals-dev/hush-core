// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#include "hush/score_cli/midi_reader.hpp"
#include "hush/score_cli/score_cli.hpp"

#include <cstring>
#include <iostream>
#include <string>

namespace {

void printHelp() {
    std::cout <<
        "hush-score — MIDI to MusicXML / engraved score / PDF\n"
        "\n"
        "Usage:\n"
        "  hush-score <in.mid> [--xml <path>] [--text <path>] [--pdf <path>]\n"
        "             [--part <name>]\n"
        "  hush-score --help\n"
        "\n"
        "If no output flag is given, engraved text is written to stdout.\n"
        "PDF requires lilypond on PATH; otherwise the program exits with an error\n"
        "and leaves no partial file.\n";
}

} // namespace

int main(int argc, char** argv) {
    try {
        if (argc < 2 || std::strcmp(argv[1], "--help") == 0 ||
            std::strcmp(argv[1], "-h") == 0) {
            printHelp();
            return argc < 2 ? 1 : 0;
        }

        std::string inPath;
        std::string xmlPath, textPath, pdfPath, partName;
        bool anyOutput = false;

        for (int i = 1; i < argc; ++i) {
            const std::string a = argv[i];
            if (a == "--xml" && i + 1 < argc) {
                xmlPath = argv[++i];
                anyOutput = true;
            } else if (a == "--text" && i + 1 < argc) {
                textPath = argv[++i];
                anyOutput = true;
            } else if (a == "--pdf" && i + 1 < argc) {
                pdfPath = argv[++i];
                anyOutput = true;
            } else if (a == "--part" && i + 1 < argc) {
                partName = argv[++i];
            } else if (a[0] != '-') {
                inPath = a;
            } else {
                std::cerr << "unknown option: " << a << "\n";
                printHelp();
                return 1;
            }
        }

        if (inPath.empty()) {
            std::cerr << "error: input MIDI file required\n";
            printHelp();
            return 1;
        }

        auto midi = hush::score_cli::readMidiFile(inPath);
        hush::score_cli::ConvertOptions opts;
        opts.partName = partName;
        auto score = hush::score_cli::midiToScore(midi, opts);

        if (!anyOutput)
            textPath = "-";

        if (!xmlPath.empty())
            hush::score_cli::writeMusicXml(score, xmlPath);
        if (!textPath.empty())
            hush::score_cli::writeEngravedText(score, textPath);
        if (!pdfPath.empty())
            hush::score_cli::writePdfViaLilyPond(score, pdfPath);

        return 0;
    } catch (const std::exception& e) {
        std::cerr << "hush-score: " << e.what() << "\n";
        return 1;
    }
}
