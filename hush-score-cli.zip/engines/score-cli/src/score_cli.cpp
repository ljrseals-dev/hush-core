// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev

#include "hush/score_cli/score_cli.hpp"

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace hush {
namespace score {

Score Score::fromMidiNotes(const std::vector<Note>& notes,
                           uint16_t ticksPerQuarter,
                           uint32_t usPerQuarter) {
    Score s;
    s.notes_ = notes;
    s.tpq_ = ticksPerQuarter ? ticksPerQuarter : 480;
    s.uspq_ = usPerQuarter ? usPerQuarter : 500000;
    return s;
}

std::string Score::toMusicXml() const {
    std::ostringstream os;
    os << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
       << "<!DOCTYPE score-partwise PUBLIC\n"
       << "    \"-//Recordare//DTD MusicXML 3.1 Partwise//EN\"\n"
       << "    \"http://www.musicxml.org/dtds/partwise.dtd\">\n"
       << "<score-partwise version=\"3.1\">\n"
       << "  <part-list>\n"
       << "    <score-part id=\"P1\">\n"
       << "      <part-name>Music</part-name>\n"
       << "    </score-part>\n"
       << "  </part-list>\n"
       << "  <part id=\"P1\">\n"
       << "    <measure number=\"1\">\n"
       << "      <attributes>\n"
       << "        <divisions>" << (tpq_ / 4) << "</divisions>\n"
       << "        <time><beats>4</beats><beat-type>4</beat-type></time>\n"
       << "        <clef><sign>G</sign><line>2</line></clef>\n"
       << "      </attributes>\n";

    // Simple note emission (one measure for brevity; real engine expands)
    for (const auto& n : notes_) {
        int step = n.pitch % 12;
        int octave = n.pitch / 12 - 1;
        static const char* steps[] = {
            "C","C","D","D","E","F","F","G","G","A","A","B"
        };
        static const char* alters[] = {
            "","1","","1","","","","1","","1","",""
        };
        os << "      <note>\n"
           << "        <pitch>\n"
           << "          <step>" << steps[step] << "</step>\n";
        if (alters[step][0])
            os << "          <alter>" << alters[step] << "</alter>\n";
        os << "          <octave>" << octave << "</octave>\n"
           << "        </pitch>\n"
           << "        <duration>" << (n.durationTicks * (tpq_ / 4) / tpq_) << "</duration>\n"
           << "        <type>quarter</type>\n"
           << "      </note>\n";
    }

    os << "    </measure>\n"
       << "  </part>\n"
       << "</score-partwise>\n";
    return os.str();
}

std::string Score::toEngravedText() const {
    std::ostringstream os;
    os << "Score (TPQ=" << tpq_ << ", tempo=" << (60000000.0 / uspq_) << " BPM)\n";
    os << "----------------------------------------\n";
    for (const auto& n : notes_) {
        os << "  tick " << n.startTicks
           << "  pitch " << int(n.pitch)
           << "  dur " << n.durationTicks
           << "  vel " << int(n.velocity)
           << "  ch " << int(n.channel) << "\n";
    }
    if (notes_.empty())
        os << "  (empty)\n";
    return os.str();
}

} // namespace score
} // namespace hush

namespace hush {
namespace score_cli {

hush::score::Score midiToScore(const MidiFile& midi, const ConvertOptions& opts) {
    std::vector<hush::score::Note> notes;
    for (const auto& trk : midi.tracks) {
        if (!opts.partName.empty() && trk.name != opts.partName)
            continue;
        for (const auto& mn : trk.notes) {
            hush::score::Note n;
            n.startTicks = mn.startTicks;
            n.durationTicks = mn.durationTicks;
            n.pitch = mn.pitch;
            n.velocity = mn.velocity;
            n.channel = mn.channel;
            notes.push_back(n);
        }
    }

    // Required by Score::fromMidiNotes
    std::sort(notes.begin(), notes.end(),
              [](const hush::score::Note& a, const hush::score::Note& b) {
                  return a.startTicks < b.startTicks;
              });

    return hush::score::Score::fromMidiNotes(
        notes,
        midi.ticksPerQuarter,
        midi.tempos.empty() ? 500000 : midi.tempos.front().microsecondsPerQuarter);
}

void writeMusicXml(const hush::score::Score& score, const std::string& path) {
    const std::string xml = score.toMusicXml();
    std::ofstream out(path);
    if (!out)
        throw std::runtime_error("cannot open MusicXML output: " + path);
    out << xml;
    if (!out)
        throw std::runtime_error("failed while writing MusicXML");
}

void writeEngravedText(const hush::score::Score& score, const std::string& path) {
    const std::string text = score.toEngravedText();
    if (path == "-") {
        std::cout << text;
        return;
    }
    std::ofstream out(path);
    if (!out)
        throw std::runtime_error("cannot open text output: " + path);
    out << text;
    if (!out)
        throw std::runtime_error("failed while writing engraved text");
}

void writePdfViaLilyPond(const hush::score::Score& score, const std::string& path) {
    if (std::system("lilypond --version > /dev/null 2>&1") != 0)
        throw std::runtime_error(
            "lilypond not found on PATH; PDF output unavailable");

    const std::string tmpXml = path + ".tmp.xml";
    writeMusicXml(score, tmpXml);

    // Strip .pdf suffix for lilypond -o base
    std::string base = path;
    if (base.size() > 4 && base.substr(base.size() - 4) == ".pdf")
        base = base.substr(0, base.size() - 4);

    const std::string cmd =
        "lilypond -fpdf -o \"" + base + "\" \"" + tmpXml + "\" 2>/dev/null";
    const int rc = std::system(cmd.c_str());
    std::remove(tmpXml.c_str());
    if (rc != 0)
        throw std::runtime_error("lilypond failed to produce PDF");
}

} // namespace score_cli
} // namespace hush
