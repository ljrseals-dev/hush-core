// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "packet.hpp"
#include <cstdint>
#include <map>
#include <vector>

namespace hush {
namespace net {

struct JitterPacket {
  PacketHeader hdr;
  std::vector<uint8_t> payload;
};

class JitterBuffer {
 public:
  JitterBuffer() : JitterBuffer(8, 64) {}
  explicit JitterBuffer(int nominalDepth, int maxDepth);

  /// Insert a decoded (possibly FEC-recovered) packet.
  /// Returns true if accepted, false if late/duplicate.
  bool insert(const JitterPacket& pkt);

  /// Pop the next in-order packet for playout. Returns false if underrun.
  bool pop(JitterPacket& out);

  int depth() const;
  uint64_t lateCount() const { return late_; }
  uint16_t nextSeq() const { return nextSeq_; }

 private:
  int nominal_;
  int max_;
  std::map<uint16_t, JitterPacket> buf_;  // keyed by seq
  uint16_t nextSeq_{0};
  bool started_{false};
  uint64_t late_{0};
};

}  // namespace net
}  // namespace hush
