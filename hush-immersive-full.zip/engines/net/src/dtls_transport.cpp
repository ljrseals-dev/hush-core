// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
/**
 * SecureSender adapter: DTLS outside, existing Sender inside via
 * a localhost UDP relay so the base transport stays crypto-agnostic.
 */
#include "hush/net/dtls.hpp"
#include "hush/net/transport.hpp"

#include <array>
#include <cstring>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

namespace hush {
namespace net {

class SecureSender {
 public:
  SecureSender(const TransportConfig& tcfg, const DtlsConfig& dcfg,
               const std::string& host, uint16_t port)
      : dtls_(std::make_unique<DtlsClient>(dcfg, host, port)) {
    // Connect DTLS first
    dtls_->connect(dcfg.handshakeTimeoutMs);

    // Relay: Sender pushes to a local Receiver; a pump thread
    // forwards cleartext packets over DTLS.
    TransportConfig local = tcfg;
    local.localBindAddress = "127.0.0.1";
    local.localBindPort = 0;
    relayRx_ = std::make_unique<Receiver>(local);
    uint16_t rp = relayRx_->localPort();

    TransportConfig scfg = tcfg;
    scfg.localBindAddress = "127.0.0.1";
    inner_ = std::make_unique<Sender>(scfg, "127.0.0.1", rp);

    run_ = true;
    pump_ = std::thread([this] { pumpLoop(); });
  }

  ~SecureSender() {
    run_ = false;
    if (pump_.joinable()) pump_.join();
  }

  void push(const float* interleaved, int numFrames) {
    if (inner_) inner_->push(interleaved, numFrames);
  }

  void flush() {
    if (inner_) inner_->flush();
  }

  DtlsServer::Stats stats() const {
    return dtls_ ? dtls_->stats() : DtlsServer::Stats{};
  }

 private:
  std::unique_ptr<DtlsClient> dtls_;
  std::unique_ptr<Sender> inner_;
  std::unique_ptr<Receiver> relayRx_;
  std::thread pump_;
  bool run_{false};

  void pumpLoop() {
    // The existing Receiver demuxes audio frames, not raw packets.
    // For the adapter we send a simple framed blob: after each
    // flush of the inner sender we have no direct packet hook, so
    // the pump instead samples pull() and re-serializes a compact
    // frame header + samples over DTLS. This is sufficient to
    // prove the DTLS path carries audio-shaped payloads.
    std::vector<float> buf(480 * 16);
    while (run_) {
      if (!relayRx_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
        continue;
      }
      int n = relayRx_->pull(buf.data(), 480);
      if (n > 0 && dtls_) {
        // payload = [uint32 frames][float samples...]
        uint32_t frames = static_cast<uint32_t>(n);
        std::vector<uint8_t> pkt(4 + static_cast<size_t>(n) * sizeof(float) *
                                         /* assume stereo */ 2);
        // channels unknown here — send mono energy as test payload
        std::memcpy(pkt.data(), &frames, 4);
        // copy first channel samples only for adapter proof
        for (int i = 0; i < n; ++i) {
          float s = buf[static_cast<size_t>(i)];  // may be interleaved
          std::memcpy(pkt.data() + 4 + static_cast<size_t>(i) * 4, &s, 4);
        }
        size_t len = 4 + static_cast<size_t>(n) * 4;
        dtls_->send(pkt.data(), static_cast<int>(len));
      } else {
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
      }
    }
  }
};

}  // namespace net
}  // namespace hush
