// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "jitter.hpp"

namespace hush {
namespace net {

JitterBuffer::JitterBuffer(int nominalDepth, int maxDepth)
    : nominal_(nominalDepth), max_(maxDepth) {}

bool JitterBuffer::insert(const JitterPacket& pkt) {
  if (!started_) {
    nextSeq_ = pkt.hdr.seq;
    started_ = true;
  }

  // Late: seq already played
  // Use signed difference to handle wrap
  const int16_t delta =
      static_cast<int16_t>(pkt.hdr.seq - nextSeq_);
  if (delta < 0) {
    ++late_;
    return false;
  }

  if (static_cast<int>(buf_.size()) >= max_) {
    // Drop oldest
    if (!buf_.empty()) buf_.erase(buf_.begin());
  }

  buf_[pkt.hdr.seq] = pkt;
  return true;
}

bool JitterBuffer::pop(JitterPacket& out) {
  // Wait until we have nominal depth before starting playout
  if (!started_) return false;
  if (static_cast<int>(buf_.size()) < 1) return false;

  // If nextSeq is present, pop it
  auto it = buf_.find(nextSeq_);
  if (it == buf_.end()) {
    // Gap: if buffer is deep enough, skip the gap
    if (static_cast<int>(buf_.size()) >= nominal_) {
      // Advance to oldest available
      it = buf_.begin();
      nextSeq_ = it->first;
    } else {
      return false;  // underrun / waiting
    }
  }

  out = std::move(it->second);
  buf_.erase(it);
  ++nextSeq_;
  return true;
}

int JitterBuffer::depth() const { return static_cast<int>(buf_.size()); }

}  // namespace net
}  // namespace hush
