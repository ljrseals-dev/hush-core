// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "mdns_backend.hpp"
#include <stdexcept>

namespace hush {
namespace net {
namespace detail {

class UnsupportedBackend final : public MdnsBackend {
 public:
  bool daemonReachable() const noexcept override { return false; }
  void registerService(const std::string&, uint16_t,
                       const std::string&) override {
    throw std::runtime_error(
        "mDNS: no platform daemon available (install avahi-daemon / "
        "libavahi-client on Linux, or use macOS Bonjour)");
  }
  void withdrawService() override {}
  void startBrowse() override {
    throw std::runtime_error(
        "mDNS: no platform daemon available (install avahi-daemon / "
        "libavahi-client on Linux, or use macOS Bonjour)");
  }
  std::vector<MdnsServiceRecord> poll(int) override { return {}; }
};

std::unique_ptr<MdnsBackend> makePlatformBackend() {
  return std::make_unique<UnsupportedBackend>();
}

}  // namespace detail
}  // namespace net
}  // namespace hush
