// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "socket_bind.hpp"

#include <arpa/inet.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netdb.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <stdexcept>
#include <string>

namespace hush {
namespace net {

namespace {

void closeQuiet(int fd) {
  if (fd >= 0) ::close(fd);
}

void setCloexecNonblock(int fd) {
  int flags = ::fcntl(fd, F_GETFL, 0);
  if (flags >= 0) ::fcntl(fd, F_SETFL, flags | O_NONBLOCK);
  int cflags = ::fcntl(fd, F_GETFD, 0);
  if (cflags >= 0) ::fcntl(fd, F_SETFD, cflags | FD_CLOEXEC);
}

bool looksNumeric(const std::string& s) {
  if (s.empty()) return false;
  // IPv4 digits/dots or IPv6 hex/colons
  bool hasColon = s.find(':') != std::string::npos;
  bool hasDot = s.find('.') != std::string::npos;
  if (hasColon) return true;
  if (hasDot) {
    for (char c : s) {
      if (!(c == '.' || (c >= '0' && c <= '9'))) return false;
    }
    return true;
  }
  return false;
}

uint32_t resolveIfaceIpv4(const std::string& ifaceName) {
  ifaddrs* list = nullptr;
  if (::getifaddrs(&list) != 0)
    throw std::runtime_error("getifaddrs failed for interface " + ifaceName);

  uint32_t addr = 0;
  for (ifaddrs* p = list; p; p = p->ifa_next) {
    if (!p->ifa_name || ifaceName != p->ifa_name) continue;
    if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET) continue;
    addr = reinterpret_cast<sockaddr_in*>(p->ifa_addr)->sin_addr.s_addr;
    break;
  }
  ::freeifaddrs(list);
  if (addr == 0)
    throw std::runtime_error("multicast interface not found: " + ifaceName);
  return addr;
}

unsigned int resolveIfaceIndex(const std::string& ifaceName) {
  unsigned int idx = ::if_nametoindex(ifaceName.c_str());
  if (idx == 0)
    throw std::runtime_error("multicast interface not found: " + ifaceName);
  return idx;
}

}  // namespace

bool isMulticastAddress(const std::string& address) {
  in_addr a4{};
  if (::inet_pton(AF_INET, address.c_str(), &a4) == 1) {
    uint32_t n = ntohl(a4.s_addr);
    return (n & 0xf0000000u) == 0xe0000000u;
  }
  in6_addr a6{};
  if (::inet_pton(AF_INET6, address.c_str(), &a6) == 1) {
    return a6.s6_addr[0] == 0xff;
  }
  return false;
}

BoundSocket bindUdp(const std::string& address, uint16_t port,
                    bool reuseAddress, bool ipv6,
                    const std::string& multicastIface) {
  BoundSocket out;

  const int family = ipv6 ? AF_INET6 : AF_INET;
  int fd = ::socket(family, SOCK_DGRAM, 0);
  if (fd < 0)
    throw std::runtime_error(std::string("socket() failed: ") +
                             std::strerror(errno));

  try {
    if (reuseAddress) {
      int yes = 1;
      ::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
#if defined(SO_REUSEPORT)
      ::setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &yes, sizeof(yes));
#endif
    }

    sockaddr_storage ss{};
    socklen_t sslen = 0;

    const bool any =
        address.empty() || address == "0.0.0.0" || address == "::";

    if (any) {
      if (ipv6) {
        auto* a = reinterpret_cast<sockaddr_in6*>(&ss);
        a->sin6_family = AF_INET6;
        a->sin6_addr = in6addr_any;
        a->sin6_port = htons(port);
        sslen = sizeof(sockaddr_in6);
      } else {
        auto* a = reinterpret_cast<sockaddr_in*>(&ss);
        a->sin_family = AF_INET;
        a->sin_addr.s_addr = INADDR_ANY;
        a->sin_port = htons(port);
        sslen = sizeof(sockaddr_in);
      }
    } else {
      addrinfo hints{};
      hints.ai_family = family;
      hints.ai_socktype = SOCK_DGRAM;
      hints.ai_flags = AI_ADDRCONFIG;
      if (looksNumeric(address)) hints.ai_flags |= AI_NUMERICHOST;
      if (port == 0) hints.ai_flags |= AI_PASSIVE;

      addrinfo* res = nullptr;
      const char* portStr = port == 0 ? nullptr : nullptr;
      char portBuf[16];
      if (port != 0) {
        std::snprintf(portBuf, sizeof(portBuf), "%u",
                      static_cast<unsigned>(port));
        portStr = portBuf;
      }
      int gai = ::getaddrinfo(address.c_str(), portStr, &hints, &res);
      if (gai != 0) {
        throw std::runtime_error(std::string("getaddrinfo(") + address +
                                 "): " + gai_strerror(gai));
      }
      addrinfo* chosen = nullptr;
      for (addrinfo* p = res; p; p = p->ai_next) {
        if (p->ai_family == family) {
          chosen = p;
          break;
        }
      }
      if (!chosen) {
        ::freeaddrinfo(res);
        throw std::runtime_error(
            "no address matching requested family for " + address);
      }
      std::memcpy(&ss, chosen->ai_addr, chosen->ai_addrlen);
      sslen = static_cast<socklen_t>(chosen->ai_addrlen);
      // Ensure port is set if getaddrinfo used nullptr port
      if (port != 0) {
        if (family == AF_INET)
          reinterpret_cast<sockaddr_in*>(&ss)->sin_port = htons(port);
        else
          reinterpret_cast<sockaddr_in6*>(&ss)->sin6_port = htons(port);
      }
      ::freeaddrinfo(res);
    }

    if (::bind(fd, reinterpret_cast<sockaddr*>(&ss), sslen) < 0) {
      throw std::runtime_error(std::string("bind(") +
                               (address.empty() ? "ANY" : address) + ":" +
                               std::to_string(port) + "): " +
                               std::strerror(errno));
    }

    if (!multicastIface.empty()) {
      if (ipv6) {
        unsigned int idx = resolveIfaceIndex(multicastIface);
        if (::setsockopt(fd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &idx,
                         sizeof(idx)) < 0) {
          throw std::runtime_error(
              std::string("IPV6_MULTICAST_IF failed for ") + multicastIface +
              ": " + std::strerror(errno));
        }
      } else {
        in_addr ifa{};
        ifa.s_addr = resolveIfaceIpv4(multicastIface);
        if (::setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &ifa, sizeof(ifa)) <
            0) {
          throw std::runtime_error(
              std::string("IP_MULTICAST_IF failed for ") + multicastIface +
              ": " + std::strerror(errno));
        }
      }
    }

    setCloexecNonblock(fd);

    // Query actual bound address/port
    socklen_t len = sizeof(ss);
    if (::getsockname(fd, reinterpret_cast<sockaddr*>(&ss), &len) == 0) {
      out.local = ss;
      out.localLen = len;
      if (ss.ss_family == AF_INET)
        out.boundPort =
            ntohs(reinterpret_cast<sockaddr_in*>(&ss)->sin_port);
      else if (ss.ss_family == AF_INET6)
        out.boundPort =
            ntohs(reinterpret_cast<sockaddr_in6*>(&ss)->sin6_port);
    }

    out.fd = fd;
    return out;
  } catch (...) {
    closeQuiet(fd);
    throw;
  }
}

}  // namespace net
}  // namespace hush
