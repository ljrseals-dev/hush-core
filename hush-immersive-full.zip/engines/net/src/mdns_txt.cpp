// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/mdns.hpp"

#include <sstream>
#include <stdexcept>

namespace hush {
namespace net {

namespace {

std::string sanitize(const std::string& s) {
  std::string out;
  out.reserve(s.size());
  for (char c : s) {
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n')
      out.push_back('_');
    else
      out.push_back(c);
  }
  return out;
}

}  // namespace

std::string buildTxtRecord(const SessionDescription& desc) {
  std::ostringstream os;
  os << "ver=1"
     << " id=" << sanitize(desc.id)
     << " name=" << sanitize(desc.name)
     << " format=" << sanitize(desc.format)
     << " rate=" << desc.sampleRate
     << " channels=" << desc.channels
     << " codec=" << sanitize(desc.codec)
     << " aport=" << desc.audioPort;
  for (const auto& a : desc.attributes) {
    os << " attr=" << sanitize(a);
  }
  return os.str();
}

SessionDescription parseTxtRecord(const std::string& txt,
                                  const std::string& instanceName,
                                  const std::string& host, uint16_t port) {
  SessionDescription d;
  d.name = instanceName;
  d.host = host;
  d.audioPort = port;

  bool haveId = false, haveVer = false, haveFormat = false;
  std::string rest = txt;
  while (!rest.empty()) {
    // Skip leading spaces
    while (!rest.empty() && (rest[0] == ' ' || rest[0] == '\t'))
      rest.erase(0, 1);
    if (rest.empty()) break;

    auto eq = rest.find('=');
    if (eq == std::string::npos) break;
    std::string key = rest.substr(0, eq);
    rest = rest.substr(eq + 1);

    // Value runs until next space-key= or end
    std::string value;
    // Find next " key=" pattern or end
    std::size_t i = 0;
    while (i < rest.size()) {
      if (rest[i] == ' ') {
        // Peek for key=
        std::size_t j = i + 1;
        while (j < rest.size() && rest[j] == ' ') ++j;
        auto eq2 = rest.find('=', j);
        if (eq2 != std::string::npos && eq2 < j + 32) {
          bool looksKey = true;
          for (std::size_t k = j; k < eq2; ++k) {
            char c = rest[k];
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                  (c >= '0' && c <= '9') || c == '_')) {
              looksKey = false;
              break;
            }
          }
          if (looksKey) break;
        }
      }
      value.push_back(rest[i]);
      ++i;
    }
    rest = rest.substr(i);

    if (key == "ver") {
      if (value != "1")
        throw std::invalid_argument("parseTxtRecord: unsupported ver=" +
                                    value);
      haveVer = true;
    } else if (key == "id") {
      d.id = value;
      haveId = true;
    } else if (key == "name") {
      d.name = value;
    } else if (key == "format") {
      d.format = value;
      haveFormat = true;
    } else if (key == "rate") {
      try {
        d.sampleRate = std::stod(value);
      } catch (...) {
        throw std::invalid_argument("parseTxtRecord: bad rate");
      }
    } else if (key == "channels") {
      try {
        d.channels = std::stoi(value);
      } catch (...) {
        throw std::invalid_argument("parseTxtRecord: bad channels");
      }
    } else if (key == "codec") {
      d.codec = value;
    } else if (key == "aport") {
      try {
        int p = std::stoi(value);
        if (p > 0 && p <= 65535) d.audioPort = static_cast<uint16_t>(p);
      } catch (...) {
        throw std::invalid_argument("parseTxtRecord: bad aport");
      }
    } else if (key == "attr") {
      d.attributes.push_back(value);
    }
  }

  if (!haveVer)
    throw std::invalid_argument("parseTxtRecord: missing ver");
  if (!haveId)
    throw std::invalid_argument("parseTxtRecord: missing id");
  if (!haveFormat)
    throw std::invalid_argument("parseTxtRecord: missing format");

  return d;
}

}  // namespace net
}  // namespace hush
