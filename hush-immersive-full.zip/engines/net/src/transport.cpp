// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/transport.hpp"
#include "jitter.hpp"
#include "packet.hpp"
#include "pll.hpp"
#include "socket_bind.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cstring>
#include <map>
#include <random>
#include <stdexcept>
#include <vector>

#if defined(_WIN32)
#error "hush::net is POSIX-only in this build"
#endif

namespace hush {
namespace net {

namespace {

double nowSec() {
  using clock = std::chrono::steady_clock;
  return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

}  // namespace

// ---------------------------------------------------------------------------
// Sender
// ---------------------------------------------------------------------------

struct Sender::Impl {
  TransportConfig cfg_;
  int sock_{-1};
  uint16_t localPort_{0};
  sockaddr_in dest_{};
  uint16_t seq_{0};
  uint16_t blockId_{0};
  uint16_t indexInBlock_{0};
  uint32_t timestamp_{0};
  int framesPerPacket_{0};

  // Current FEC block assembly
  std::vector<std::vector<uint8_t>> blockPayloads_;
  std::vector<PacketHeader> blockHeaders_;

  // Retransmit cache: seq → full packet bytes
  std::map<uint16_t, std::vector<uint8_t>> cache_;
  static constexpr int kCacheMax = 256;

  double lossRate_{0.0};
  std::mt19937 rng_{42};
  Stats stats_;
  int consecutiveSendErrors_{0};

  void sendRaw(const uint8_t* data, int len) {
    if (lossRate_ > 0.0) {
      std::uniform_real_distribution<double> dist(0.0, 1.0);
      if (dist(rng_) < lossRate_) return;  // drop
    }
    ssize_t n = ::sendto(sock_, data, static_cast<size_t>(len), 0,
                         reinterpret_cast<sockaddr*>(&dest_), sizeof(dest_));
    if (n < 0)
      ++consecutiveSendErrors_;
    else
      consecutiveSendErrors_ = 0;
  }

  void emitPacket(const PacketHeader& hdr, const uint8_t* payload,
                  int payloadLen) {
    std::vector<uint8_t> buf(static_cast<std::size_t>(kHeaderBytes + payloadLen));
    encodeHeader(buf.data(), hdr);
    if (payloadLen > 0)
      std::memcpy(buf.data() + kHeaderBytes, payload,
                  static_cast<std::size_t>(payloadLen));

    cache_[hdr.seq] = buf;
    if (static_cast<int>(cache_.size()) > kCacheMax)
      cache_.erase(cache_.begin());

    sendRaw(buf.data(), static_cast<int>(buf.size()));
    if (hdr.flags & kFlagRepair)
      ++stats_.repairSent;
    else
      ++stats_.packetsSent;
  }

  void closeBlock() {
    if (blockPayloads_.empty()) return;

    // Emit repair = XOR of data payloads
    auto repair = xorPayloads(blockPayloads_);
    PacketHeader rh;
    rh.seq = seq_++;
    rh.blockId = blockId_;
    rh.indexInBlock = static_cast<uint16_t>(cfg_.fecBlockSize);
    rh.flags = kFlagRepair;
    rh.timestamp = timestamp_;
    rh.payloadLen = static_cast<uint16_t>(repair.size());
    rh.channels = static_cast<uint16_t>(cfg_.channels);
    emitPacket(rh, repair.data(), static_cast<int>(repair.size()));

    blockPayloads_.clear();
    blockHeaders_.clear();
    indexInBlock_ = 0;
    ++blockId_;
  }
};

Sender::Sender(const TransportConfig& cfg, const std::string& remoteHost,
               uint16_t remotePort)
    : impl_(std::make_unique<Impl>()) {
  if (cfg.channels <= 0 || cfg.sampleRate <= 0 || cfg.fecBlockSize < 2)
    throw std::invalid_argument("Sender: invalid config");
  if (cfg.payloadBytesPerPacket < 4)
    throw std::invalid_argument("Sender: payloadBytesPerPacket too small");

  impl_->cfg_ = cfg;
  impl_->framesPerPacket_ =
      cfg.payloadBytesPerPacket /
      (cfg.channels * static_cast<int>(sizeof(float)));
  if (impl_->framesPerPacket_ < 1) impl_->framesPerPacket_ = 1;

  auto bound = bindUdp(cfg.localBindAddress, cfg.localBindPort,
                       cfg.reuseAddress, cfg.ipv6, cfg.multicastIface);
  impl_->sock_ = bound.fd;
  impl_->localPort_ = bound.boundPort;

  std::memset(&impl_->dest_, 0, sizeof(impl_->dest_));
  impl_->dest_.sin_family = AF_INET;
  impl_->dest_.sin_port = htons(remotePort);
  if (::inet_pton(AF_INET, remoteHost.c_str(), &impl_->dest_.sin_addr) != 1)
    throw std::runtime_error("Sender: cannot resolve " + remoteHost);

  if (isMulticastAddress(remoteHost)) {
    unsigned char ttl = 1;  // LAN only
    ::setsockopt(impl_->sock_, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl));
  }
}

Sender::~Sender() {
  if (impl_ && impl_->sock_ >= 0) ::close(impl_->sock_);
}

uint16_t Sender::localPort() const noexcept {
  return impl_ ? impl_->localPort_ : 0;
}

int Sender::consecutiveSendErrors() const noexcept {
  return impl_ ? impl_->consecutiveSendErrors_ : 0;
}

void Sender::push(const float* interleaved, int numFrames) {
  if (!interleaved || numFrames <= 0) return;
  const int ch = impl_->cfg_.channels;
  const int fpp = impl_->framesPerPacket_;
  int offset = 0;

  while (offset < numFrames) {
    const int n = std::min(fpp, numFrames - offset);
    const int nbytes = n * ch * static_cast<int>(sizeof(float));

    PacketHeader hdr;
    hdr.seq = impl_->seq_++;
    hdr.blockId = impl_->blockId_;
    hdr.indexInBlock = impl_->indexInBlock_;
    hdr.flags = kFlagData;
    hdr.timestamp = impl_->timestamp_;
    hdr.payloadLen = static_cast<uint16_t>(nbytes);
    hdr.channels = static_cast<uint16_t>(ch);

    const uint8_t* payload =
        reinterpret_cast<const uint8_t*>(interleaved + offset * ch);
    std::vector<uint8_t> pay(payload, payload + nbytes);
    impl_->blockPayloads_.push_back(pay);
    impl_->blockHeaders_.push_back(hdr);

    impl_->emitPacket(hdr, payload, nbytes);

    ++impl_->indexInBlock_;
    impl_->timestamp_ += static_cast<uint32_t>(n);
    offset += n;

    if (static_cast<int>(impl_->indexInBlock_) >= impl_->cfg_.fecBlockSize)
      impl_->closeBlock();
  }
}

void Sender::flush() {
  if (!impl_->blockPayloads_.empty()) impl_->closeBlock();
}

Sender::Stats Sender::stats() const { return impl_->stats_; }

void Sender::setTestLossRate(double lossRate) {
  impl_->lossRate_ = std::clamp(lossRate, 0.0, 1.0);
}

// ---------------------------------------------------------------------------
// Receiver
// ---------------------------------------------------------------------------

struct Receiver::Impl {
  TransportConfig cfg_;
  int sock_{-1};
  uint16_t localPort_{0};
  std::string localAddress_;
  JitterBuffer jitter_;
  ClockPll pll_;
  Stats stats_;
  double lastPacketAtSec_{0.0};

  // FEC assembly: blockId → (index → payload)
  std::map<uint16_t, std::map<uint16_t, std::vector<uint8_t>>> fecBlocks_;
  std::map<uint16_t, std::vector<uint8_t>> fecRepair_;

  // Playout residual samples
  std::vector<float> residual_;
  int residualFrames_{0};

  void tryRecover(uint16_t blockId) {
    auto& data = fecBlocks_[blockId];
    auto rit = fecRepair_.find(blockId);
    if (rit == fecRepair_.end()) return;
    const int N = cfg_.fecBlockSize;
    if (static_cast<int>(data.size()) != N - 1) return;  // need exactly one loss

    // Find missing index
    int missing = -1;
    for (int i = 0; i < N; ++i) {
      if (data.find(static_cast<uint16_t>(i)) == data.end()) {
        missing = i;
        break;
      }
    }
    if (missing < 0) return;

    // XOR repair with all present data
    std::vector<std::vector<uint8_t>> parts;
    parts.push_back(rit->second);
    for (auto& kv : data) parts.push_back(kv.second);
    auto recovered = xorPayloads(parts);

    JitterPacket jp;
    jp.hdr.seq = 0;  // unknown; use a synthetic seq near neighbours
    jp.hdr.blockId = blockId;
    jp.hdr.indexInBlock = static_cast<uint16_t>(missing);
    jp.hdr.flags = kFlagData;
    jp.hdr.payloadLen = static_cast<uint16_t>(recovered.size());
    jp.hdr.channels = static_cast<uint16_t>(cfg_.channels);
    jp.payload = std::move(recovered);

    // Approximate seq from block structure
    // (not perfect but enough for stats)
    jitter_.insert(jp);
    ++stats_.packetsRecovered;
  }

  void handlePacket(const uint8_t* buf, int len) {
    if (len < kHeaderBytes) return;
    PacketHeader hdr = decodeHeader(buf);
    const int plen = hdr.payloadLen;
    if (len < kHeaderBytes + plen) return;

    const uint8_t* payload = buf + kHeaderBytes;
    std::vector<uint8_t> pay(payload, payload + plen);

    // PLL update
    const double senderSec =
        static_cast<double>(hdr.timestamp) / cfg_.sampleRate;
    pll_.update(senderSec, nowSec());

    if (hdr.flags & kFlagRepair) {
      fecRepair_[hdr.blockId] = pay;
      tryRecover(hdr.blockId);
      return;
    }

    // Data packet
    ++stats_.packetsReceived;
    lastPacketAtSec_ = nowSec();
    fecBlocks_[hdr.blockId][hdr.indexInBlock] = pay;
    tryRecover(hdr.blockId);

    JitterPacket jp;
    jp.hdr = hdr;
    jp.payload = std::move(pay);
    if (!jitter_.insert(jp)) {
      // late
    }
  }

  void pollSocket() {
    uint8_t buf[4096];
    while (true) {
      sockaddr_in src{};
      socklen_t slen = sizeof(src);
      ssize_t n = ::recvfrom(sock_, buf, sizeof(buf), MSG_DONTWAIT,
                             reinterpret_cast<sockaddr*>(&src), &slen);
      if (n <= 0) break;
      handlePacket(buf, static_cast<int>(n));
    }
  }
};

Receiver::Receiver(const TransportConfig& cfg)
    : impl_(std::make_unique<Impl>()) {
  if (cfg.channels <= 0 || cfg.sampleRate <= 0)
    throw std::invalid_argument("Receiver: invalid config");
  if (cfg.fecBlockSize < 2)
    throw std::invalid_argument("Receiver: fecBlockSize must be >= 2");
  if (cfg.nackTimeoutMs < 0)
    throw std::invalid_argument("Receiver: negative timeout");

  impl_->cfg_ = cfg;
  impl_->jitter_ = JitterBuffer(cfg.jitterBufferPackets, cfg.maxJitterPackets);
  impl_->pll_ =
      ClockPll(cfg.sampleRate, cfg.clockPllBandwidthHz, cfg.clockPllDamping);

  auto bound = bindUdp(cfg.localBindAddress, cfg.localBindPort,
                       cfg.reuseAddress, cfg.ipv6, cfg.multicastIface);
  impl_->sock_ = bound.fd;
  impl_->localPort_ = bound.boundPort;

  char buf[INET6_ADDRSTRLEN] = {};
  if (bound.local.ss_family == AF_INET) {
    auto* a = reinterpret_cast<const sockaddr_in*>(&bound.local);
    ::inet_ntop(AF_INET, &a->sin_addr, buf, sizeof(buf));
  } else if (bound.local.ss_family == AF_INET6) {
    auto* a = reinterpret_cast<const sockaddr_in6*>(&bound.local);
    ::inet_ntop(AF_INET6, &a->sin6_addr, buf, sizeof(buf));
  }
  impl_->localAddress_ = buf;
}

Receiver::Receiver(const TransportConfig& cfg, uint16_t port)
    : Receiver([&] {
        TransportConfig c = cfg;
        c.localBindPort = port;
        return c;
      }()) {}

Receiver::~Receiver() {
  if (impl_ && impl_->sock_ >= 0) ::close(impl_->sock_);
}

uint16_t Receiver::localPort() const noexcept {
  return impl_ ? impl_->localPort_ : 0;
}

std::string Receiver::localAddress() const {
  return impl_ ? impl_->localAddress_ : std::string{};
}

double Receiver::lastPacketAtSec() const noexcept {
  return impl_ ? impl_->lastPacketAtSec_ : 0.0;
}

int Receiver::pull(float* out, int maxFrames) {
  if (!out || maxFrames <= 0) return 0;
  impl_->pollSocket();

  const int ch = impl_->cfg_.channels;
  int written = 0;

  // Drain residual first
  while (impl_->residualFrames_ > 0 && written < maxFrames) {
    for (int c = 0; c < ch; ++c)
      out[written * ch + c] = impl_->residual_[static_cast<std::size_t>(c)];
    // shift residual (only one frame stored for simplicity)
    impl_->residualFrames_ = 0;
    ++written;
  }

  while (written < maxFrames) {
    JitterPacket jp;
    if (!impl_->jitter_.pop(jp)) break;
    const int frames =
        jp.hdr.payloadLen / (ch * static_cast<int>(sizeof(float)));
    const float* samples = reinterpret_cast<const float*>(jp.payload.data());
    for (int f = 0; f < frames && written < maxFrames; ++f) {
      for (int c = 0; c < ch; ++c)
        out[written * ch + c] = samples[f * ch + c];
      ++written;
    }
  }
  return written;
}

double Receiver::estimatedSenderRate() const {
  return impl_->pll_.estimatedRate();
}

int Receiver::jitterDepth() const { return impl_->jitter_.depth(); }

Receiver::Stats Receiver::stats() const {
  auto s = impl_->stats_;
  s.latePackets = impl_->jitter_.lateCount();
  return s;
}

}  // namespace net
}  // namespace hush
