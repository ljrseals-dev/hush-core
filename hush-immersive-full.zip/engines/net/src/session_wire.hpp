// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Wire formats for session discovery and negotiation.
 *
 * Announcement: text SDP (RFC 8866 shape), CRLF lines.
 *   v=0
 *   o=- <sessionId> <name>
 *   s=<name>
 *   c=IN IP4 <host>
 *   m=audio <port> UDP/f32 <channels>
 *   a=samplerate:<rate>
 *   a=format:<ChannelFormatName>
 *   a=attr:<key>:<value>   (repeated)
 *
 * Negotiation: binary 32-byte header, network byte order.
 *   0-3   magic "HUSH"
 *   4-5   version = 1
 *   6-7   type (1=request, 2=reply)
 *   8-11  request id (random, echoed)
 *   12-13 payload length
 *   14-15 reserved
 *   16-31 reserved
 * Payload: NUL-terminated UTF-8 fields in documented order.
 */

#include "hush/net/session.hpp"

#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace hush {
namespace net {

constexpr uint16_t kNegVersion = 1;
constexpr uint16_t kNegTypeRequest = 1;
constexpr uint16_t kNegTypeReply = 2;
constexpr int kNegHeaderBytes = 32;

inline void writeU16BE(uint8_t* p, uint16_t v) {
  p[0] = static_cast<uint8_t>((v >> 8) & 0xff);
  p[1] = static_cast<uint8_t>(v & 0xff);
}
inline void writeU32BE(uint8_t* p, uint32_t v) {
  p[0] = static_cast<uint8_t>((v >> 24) & 0xff);
  p[1] = static_cast<uint8_t>((v >> 16) & 0xff);
  p[2] = static_cast<uint8_t>((v >> 8) & 0xff);
  p[3] = static_cast<uint8_t>(v & 0xff);
}
inline uint16_t readU16BE(const uint8_t* p) {
  return static_cast<uint16_t>((p[0] << 8) | p[1]);
}
inline uint32_t readU32BE(const uint8_t* p) {
  return (static_cast<uint32_t>(p[0]) << 24) |
         (static_cast<uint32_t>(p[1]) << 16) |
         (static_cast<uint32_t>(p[2]) << 8) | static_cast<uint32_t>(p[3]);
}

inline std::string serializeSdpImpl(const SessionDescription& d) {
  std::ostringstream os;
  os << "v=0\r\n";
  os << "o=- " << d.id << " " << d.name << "\r\n";
  os << "s=" << d.name << "\r\n";
  os << "c=IN IP4 " << d.host << "\r\n";
  os << "m=audio " << d.audioPort << " UDP/" << d.codec << " " << d.channels
     << "\r\n";
  os << "a=samplerate:" << d.sampleRate << "\r\n";
  os << "a=format:" << d.format << "\r\n";
  for (const auto& a : d.attributes) os << "a=attr:" << a << "\r\n";
  return os.str();
}

inline bool parseSdpImpl(const std::string& text, SessionDescription& out) {
  out = SessionDescription{};
  std::istringstream is(text);
  std::string line;
  bool sawV = false;
  while (std::getline(is, line)) {
    // Strip CR
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line.empty()) continue;
    if (line.rfind("v=", 0) == 0) {
      sawV = true;
    } else if (line.rfind("o=- ", 0) == 0) {
      // o=- <id> <name>
      std::string rest = line.substr(4);
      auto sp = rest.find(' ');
      if (sp != std::string::npos) {
        out.id = rest.substr(0, sp);
        out.name = rest.substr(sp + 1);
      } else {
        out.id = rest;
      }
    } else if (line.rfind("s=", 0) == 0) {
      if (out.name.empty()) out.name = line.substr(2);
    } else if (line.rfind("c=IN IP4 ", 0) == 0) {
      out.host = line.substr(9);
    } else if (line.rfind("m=audio ", 0) == 0) {
      // m=audio <port> UDP/<codec> <channels>
      std::istringstream ms(line.substr(8));
      ms >> out.audioPort;
      std::string proto;
      ms >> proto;
      auto slash = proto.find('/');
      if (slash != std::string::npos) out.codec = proto.substr(slash + 1);
      ms >> out.channels;
    } else if (line.rfind("a=samplerate:", 0) == 0) {
      out.sampleRate = std::stod(line.substr(13));
    } else if (line.rfind("a=format:", 0) == 0) {
      out.format = line.substr(9);
    } else if (line.rfind("a=attr:", 0) == 0) {
      out.attributes.push_back(line.substr(7));
    }
  }
  return sawV && !out.id.empty();
}

// Negotiation binary encode/decode
inline std::vector<uint8_t> encodeNegRequest(uint32_t reqId,
                                             const NegotiationRequest& r) {
  // Payload: sessionId\0 clientName\0 preferredRate\0 fmt1\0 fmt2\0 ... \0
  std::string payload;
  payload += r.sessionId;
  payload.push_back('\0');
  payload += r.clientName;
  payload.push_back('\0');
  payload += std::to_string(r.preferredSampleRate);
  payload.push_back('\0');
  for (const auto& f : r.supportedFormats) {
    payload += f;
    payload.push_back('\0');
  }
  // Empty field sentinel separates formats from attributes
  payload.push_back('\0');
  for (const auto& a : r.attributes) {
    payload += a;
    payload.push_back('\0');
  }

  std::vector<uint8_t> buf(static_cast<std::size_t>(kNegHeaderBytes) +
                           payload.size());
  std::memcpy(buf.data(), "HUSH", 4);
  writeU16BE(buf.data() + 4, kNegVersion);
  writeU16BE(buf.data() + 6, kNegTypeRequest);
  writeU32BE(buf.data() + 8, reqId);
  writeU16BE(buf.data() + 12, static_cast<uint16_t>(payload.size()));
  writeU16BE(buf.data() + 14, 0);
  std::memset(buf.data() + 16, 0, 16);
  std::memcpy(buf.data() + kNegHeaderBytes, payload.data(), payload.size());
  return buf;
}

inline bool decodeNegRequest(const uint8_t* data, int len,
                             uint32_t& reqIdOut, NegotiationRequest& r) {
  if (len < kNegHeaderBytes) return false;
  if (std::memcmp(data, "HUSH", 4) != 0) return false;
  if (readU16BE(data + 4) != kNegVersion) return false;
  if (readU16BE(data + 6) != kNegTypeRequest) return false;
  reqIdOut = readU32BE(data + 8);
  const uint16_t plen = readU16BE(data + 12);
  if (len < kNegHeaderBytes + plen) return false;

  const char* p = reinterpret_cast<const char*>(data + kNegHeaderBytes);
  const char* end = p + plen;
  auto next = [&](std::string& out) -> bool {
    if (p >= end) return false;
    const char* z = static_cast<const char*>(memchr(p, '\0', end - p));
    if (!z) return false;
    out.assign(p, z);
    p = z + 1;
    return true;
  };
  r = NegotiationRequest{};
  if (!next(r.sessionId)) return false;
  if (!next(r.clientName)) return false;
  std::string rateStr;
  if (!next(rateStr)) return false;
  try {
    r.preferredSampleRate = std::stod(rateStr);
  } catch (...) {
    return false;
  }
  std::string f;
  while (next(f)) {
    if (f.empty()) break;  // sentinel → attributes follow
    r.supportedFormats.push_back(f);
  }
  std::string a;
  while (next(a)) {
    if (!a.empty()) r.attributes.push_back(a);
  }
  return true;
}

inline std::vector<uint8_t> encodeNegReply(uint32_t reqId,
                                           const NegotiationReply& r) {
  std::string payload;
  payload += r.accepted ? "1" : "0";
  payload.push_back('\0');
  payload += r.reason;
  payload.push_back('\0');
  payload += r.chosenFormat;
  payload.push_back('\0');
  payload += std::to_string(r.chosenSampleRate);
  payload.push_back('\0');
  payload += std::to_string(r.transportPort);
  payload.push_back('\0');

  std::vector<uint8_t> buf(static_cast<std::size_t>(kNegHeaderBytes) +
                           payload.size());
  std::memcpy(buf.data(), "HUSH", 4);
  writeU16BE(buf.data() + 4, kNegVersion);
  writeU16BE(buf.data() + 6, kNegTypeReply);
  writeU32BE(buf.data() + 8, reqId);
  writeU16BE(buf.data() + 12, static_cast<uint16_t>(payload.size()));
  writeU16BE(buf.data() + 14, 0);
  std::memset(buf.data() + 16, 0, 16);
  std::memcpy(buf.data() + kNegHeaderBytes, payload.data(), payload.size());
  return buf;
}

inline bool decodeNegReply(const uint8_t* data, int len, uint32_t& reqIdOut,
                           NegotiationReply& r) {
  if (len < kNegHeaderBytes) return false;
  if (std::memcmp(data, "HUSH", 4) != 0) return false;
  if (readU16BE(data + 4) != kNegVersion) return false;
  if (readU16BE(data + 6) != kNegTypeReply) return false;
  reqIdOut = readU32BE(data + 8);
  const uint16_t plen = readU16BE(data + 12);
  if (len < kNegHeaderBytes + plen) return false;

  const char* p = reinterpret_cast<const char*>(data + kNegHeaderBytes);
  const char* end = p + plen;
  auto next = [&](std::string& out) -> bool {
    if (p >= end) return false;
    const char* z = static_cast<const char*>(memchr(p, '\0', end - p));
    if (!z) return false;
    out.assign(p, z);
    p = z + 1;
    return true;
  };
  r = NegotiationReply{};
  std::string acc, rateStr, portStr;
  if (!next(acc)) return false;
  r.accepted = (acc == "1");
  if (!next(r.reason)) return false;
  if (!next(r.chosenFormat)) return false;
  if (!next(rateStr)) return false;
  if (!next(portStr)) return false;
  try {
    r.chosenSampleRate = std::stod(rateStr);
    r.transportPort = static_cast<uint16_t>(std::stoi(portStr));
  } catch (...) {
    return false;
  }
  return true;
}

}  // namespace net
}  // namespace hush
