// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "pll.hpp"
#include <algorithm>
#include <cmath>

namespace hush {
namespace net {

ClockPll::ClockPll(double nominalRate, double bandwidthHz, double damping)
    : nominalRate_(nominalRate), bw_(bandwidthHz), damp_(damping) {}

void ClockPll::update(double senderTimeSec, double localTimeSec) {
  if (lastSenderTime_ < 0.0) {
    lastSenderTime_ = senderTimeSec;
    lastLocalTime_ = localTimeSec;
    return;
  }

  const double dSender = senderTimeSec - lastSenderTime_;
  const double dLocal = localTimeSec - lastLocalTime_;
  lastSenderTime_ = senderTimeSec;
  lastLocalTime_ = localTimeSec;

  if (dSender <= 0.0 || dLocal <= 0.0) return;

  // Phase error: sender advanced more than local → sender is fast
  // → we should increase estimated rate.
  // dSender is in "sender time units"; scale by current estimate.
  const double expectedLocal = dSender / (1.0 + freqCorrection_);
  phaseError_ = dSender - dLocal * (1.0 + freqCorrection_);

  // Second-order PI: drive freqCorrection so estimated rate tracks sender
  const double kp = 2.0 * damp_ * bw_;
  const double ki = bw_ * bw_;
  freqCorrection_ += ki * phaseError_ + kp * phaseError_ * 0.01;
  freqCorrection_ = std::clamp(freqCorrection_, -0.01, 0.01);
  (void)expectedLocal;
  ++updates_;
}

double ClockPll::estimatedRate() const {
  return nominalRate_ * (1.0 + freqCorrection_);
}

void ClockPll::reset() {
  phaseError_ = 0.0;
  freqCorrection_ = 0.0;
  lastSenderTime_ = -1.0;
  lastLocalTime_ = -1.0;
  updates_ = 0;
}

}  // namespace net
}  // namespace hush
