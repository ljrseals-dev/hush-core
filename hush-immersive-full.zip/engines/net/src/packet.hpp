// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Packet format — RTP-shaped (RFC 3550 style), not wire-compatible.
 *
 * Fixed 16-byte header, network byte order:
 *   0-1   sequence number (uint16)     — RTP-style
 *   2-3   block ID (uint16)            — needed for FEC grouping
 *   4-5   index in block (uint16)      — 0..N-1 data, N = repair
 *   6-7   flags (uint16)               — bit0=data, bit1=repair, bit2=retransmit
 *   8-11  timestamp (uint32)           — RTP-style, sample-rate units
 *  12-13  payload length (uint16)      — needed for variable frames
 *  14-15  channels (uint16)            — needed for multichannel
 * Payload: little-endian float32 interleaved.
 *
 * FEC (RFC 5109 XOR-shaped): one repair packet = XOR of all data
 * packets in the block. Recover any single loss by XOR with survivors.
 */

#include <cstdint>
#include <cstring>
#include <vector>

namespace hush {
namespace net {

constexpr int kHeaderBytes = 16;
constexpr uint16_t kFlagData = 0x0001;
constexpr uint16_t kFlagRepair = 0x0002;
constexpr uint16_t kFlagRetransmit = 0x0004;

inline void writeU16BE(uint8_t* p, uint16_t v) {
  p[0] = static_cast<uint8_t>((v >> 8) & 0xff);
  p[1] = static_cast<uint8_t>(v & 0xff);
}
inline void writeU32BE(uint8_t* p, uint32_t v) {
  p[0] = static_cast<uint8_t>((v >> 24) & 0xff);
  p[1] = static_cast<uint8_t>((v >> 16) & 0xff);
  p[2] = static_cast<uint8_t>((v >> 8) & 0xff);
  p[3] = static_cast<uint8_t>(v & 0xff);
}
inline uint16_t readU16BE(const uint8_t* p) {
  return static_cast<uint16_t>((p[0] << 8) | p[1]);
}
inline uint32_t readU32BE(const uint8_t* p) {
  return (static_cast<uint32_t>(p[0]) << 24) |
         (static_cast<uint32_t>(p[1]) << 16) |
         (static_cast<uint32_t>(p[2]) << 8) |
         static_cast<uint32_t>(p[3]);
}

struct PacketHeader {
  uint16_t seq{0};
  uint16_t blockId{0};
  uint16_t indexInBlock{0};
  uint16_t flags{0};
  uint32_t timestamp{0};
  uint16_t payloadLen{0};
  uint16_t channels{0};
};

inline void encodeHeader(uint8_t* buf, const PacketHeader& h) {
  writeU16BE(buf + 0, h.seq);
  writeU16BE(buf + 2, h.blockId);
  writeU16BE(buf + 4, h.indexInBlock);
  writeU16BE(buf + 6, h.flags);
  writeU32BE(buf + 8, h.timestamp);
  writeU16BE(buf + 12, h.payloadLen);
  writeU16BE(buf + 14, h.channels);
}

inline PacketHeader decodeHeader(const uint8_t* buf) {
  PacketHeader h;
  h.seq = readU16BE(buf + 0);
  h.blockId = readU16BE(buf + 2);
  h.indexInBlock = readU16BE(buf + 4);
  h.flags = readU16BE(buf + 6);
  h.timestamp = readU32BE(buf + 8);
  h.payloadLen = readU16BE(buf + 12);
  h.channels = readU16BE(buf + 14);
  return h;
}

// XOR-based FEC: repair = XOR of all data payloads in the block.
inline std::vector<uint8_t> xorPayloads(
    const std::vector<std::vector<uint8_t>>& payloads) {
  if (payloads.empty()) return {};
  std::vector<uint8_t> out = payloads[0];
  for (std::size_t i = 1; i < payloads.size(); ++i) {
    const auto& p = payloads[i];
    if (p.size() > out.size()) out.resize(p.size(), 0);
    for (std::size_t j = 0; j < p.size(); ++j) out[j] ^= p[j];
  }
  return out;
}

}  // namespace net
}  // namespace hush
