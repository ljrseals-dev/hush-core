// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/dtls.hpp"

#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

// DTLS 1.3 only. OpenSSL 3.0.x tops out at DTLS 1.2; 1.3 requires
// OpenSSL >= 3.2 (DTLS1_3_VERSION). Do not silently downgrade.
#ifndef DTLS1_3_VERSION
#error "hush::net DTLS requires OpenSSL with DTLS 1.3 (DTLS1_3_VERSION). Install OpenSSL >= 3.2, or build with -DHUSH_WITH_DTLS=OFF."
#endif

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstring>
#include <fstream>
#include <mutex>
#include <sstream>
#include <vector>

namespace hush {
namespace net {

namespace {

std::once_flag gSslOnce;
void initSsl() {
  std::call_once(gSslOnce, [] {
    OPENSSL_init_ssl(OPENSSL_INIT_LOAD_SSL_STRINGS |
                         OPENSSL_INIT_LOAD_CRYPTO_STRINGS,
                     nullptr);
  });
}

std::string drainErrors() {
  std::ostringstream os;
  unsigned long e;
  while ((e = ERR_get_error()) != 0) {
    char buf[256];
    ERR_error_string_n(e, buf, sizeof(buf));
    if (os.tellp() > 0) os << "; ";
    os << buf;
  }
  return os.str();
}

double nowSec() {
  using clock = std::chrono::steady_clock;
  return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

int makeUdp(uint16_t port, sockaddr_in* outAddr = nullptr) {
  int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
  if (fd < 0) throw DtlsError("socket() failed");
  int yes = 1;
  ::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  addr.sin_port = htons(port);
  if (::bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
    ::close(fd);
    throw DtlsError(std::string("bind failed: ") + strerror(errno));
  }
  if (outAddr) {
    socklen_t len = sizeof(*outAddr);
    ::getsockname(fd, reinterpret_cast<sockaddr*>(outAddr), &len);
  }
  int flags = ::fcntl(fd, F_GETFL, 0);
  if (flags >= 0) ::fcntl(fd, F_SETFL, flags | O_NONBLOCK);
  return fd;
}

SSL_CTX* makeCtx(const DtlsConfig& cfg) {
  initSsl();
  SSL_CTX* ctx = SSL_CTX_new(DTLS_method());
  if (!ctx) throw DtlsError("SSL_CTX_new failed: " + drainErrors());

  // DTLS 1.3 only — no fallback to 1.2.
  if (SSL_CTX_set_min_proto_version(ctx, DTLS1_3_VERSION) != 1 ||
      SSL_CTX_set_max_proto_version(ctx, DTLS1_3_VERSION) != 1) {
    SSL_CTX_free(ctx);
    throw DtlsError(
        "DTLS 1.3 proto version not accepted by OpenSSL: " + drainErrors());
  }

  // TLS 1.3 cipher suites only. Failure is fatal — do not fall back to
  // SSL_CTX_set_cipher_list (that is the TLS 1.2 suite API).
  if (cfg.cipherSuites.empty()) {
    SSL_CTX_free(ctx);
    throw DtlsError("cipherSuites must not be empty");
  }
  if (SSL_CTX_set_ciphersuites(ctx, cfg.cipherSuites.c_str()) != 1) {
    SSL_CTX_free(ctx);
    throw DtlsError("SSL_CTX_set_ciphersuites failed for '" +
                    cfg.cipherSuites + "': " + drainErrors());
  }

  if (SSL_CTX_use_certificate_file(ctx, cfg.certFile.c_str(),
                                   SSL_FILETYPE_PEM) != 1)
    throw DtlsError("load cert failed: " + drainErrors());
  if (SSL_CTX_use_PrivateKey_file(ctx, cfg.keyFile.c_str(),
                                  SSL_FILETYPE_PEM) != 1)
    throw DtlsError("load key failed: " + drainErrors());
  if (SSL_CTX_check_private_key(ctx) != 1)
    throw DtlsError("key does not match cert: " + drainErrors());

  if (!cfg.caFile.empty()) {
    if (SSL_CTX_load_verify_locations(ctx, cfg.caFile.c_str(), nullptr) != 1)
      throw DtlsError("load CA failed: " + drainErrors());
  }

  SSL_CTX_set_verify(ctx,
                     SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
                     nullptr);

  return ctx;
}

bool waitFd(int fd, bool forRead, int timeoutMs) {
  fd_set set;
  FD_ZERO(&set);
  FD_SET(fd, &set);
  timeval tv{};
  tv.tv_sec = timeoutMs / 1000;
  tv.tv_usec = (timeoutMs % 1000) * 1000;
  int r = forRead ? ::select(fd + 1, &set, nullptr, nullptr, &tv)
                  : ::select(fd + 1, nullptr, &set, nullptr, &tv);
  return r > 0;
}

std::string certToPem(X509* cert) {
  if (!cert) return {};
  BIO* bio = BIO_new(BIO_s_mem());
  PEM_write_bio_X509(bio, cert);
  char* data = nullptr;
  long len = BIO_get_mem_data(bio, &data);
  std::string out(data, static_cast<std::size_t>(len));
  BIO_free(bio);
  return out;
}

}  // namespace

DtlsError::DtlsError(const std::string& what) : std::runtime_error(what) {}

// ---------------------------------------------------------------------------
// Shared session state
// ---------------------------------------------------------------------------

struct Session {
  SSL_CTX* ctx{nullptr};
  SSL* ssl{nullptr};
  int fd{-1};
  DtlsConfig cfg;
  bool connected{false};
  DtlsServer::Stats stats;
  double handshakeAt{0};
  uint64_t packetsSinceRekey{0};
  std::string peerPem;
  std::string pinned;

  ~Session() {
    if (ssl) SSL_free(ssl);
    if (ctx) SSL_CTX_free(ctx);
    if (fd >= 0) ::close(fd);
  }

  void maybeRekey() {
    if (!connected || !ssl) return;
    bool need = static_cast<int>(packetsSinceRekey) >= cfg.rekeyAfterPackets;
    if (!need && cfg.rekeyAfterSeconds > 0) {
      need = (nowSec() - handshakeAt) >= cfg.rekeyAfterSeconds;
    }
    if (!need) return;
#if defined(SSL_KEY_UPDATE_REQUESTED)
    if (SSL_key_update(ssl, SSL_KEY_UPDATE_REQUESTED) == 1) {
      stats.rekeys++;
      packetsSinceRekey = 0;
    }
#endif
  }

  int doSend(const uint8_t* data, int len) {
    if (!connected || !ssl) return -1;
    maybeRekey();
    size_t written = 0;
    int r = SSL_write_ex(ssl, data, static_cast<size_t>(len), &written);
    if (r == 1) {
      stats.packetsSent++;
      packetsSinceRekey++;
      return static_cast<int>(written);
    }
    int err = SSL_get_error(ssl, r);
    if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) return 0;
    return -1;
  }

  int doRecv(uint8_t* out, int maxLen, int timeoutMs) {
    if (!connected || !ssl) return -1;
    if (!waitFd(fd, true, timeoutMs)) return 0;
    size_t readn = 0;
    int r = SSL_read_ex(ssl, out, static_cast<size_t>(maxLen), &readn);
    if (r == 1) {
      stats.packetsReceived++;
      return static_cast<int>(readn);
    }
    int err = SSL_get_error(ssl, r);
    if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) return 0;
    if (err == SSL_ERROR_SSL) {
      stats.decryptFailures++;
      ERR_clear_error();
      return -1;
    }
    return -1;
  }

  void checkPin() {
    if (pinned.empty()) return;
    X509* peer = SSL_get_peer_certificate(ssl);
    if (!peer) throw DtlsError("no peer certificate for pin check");
    std::string pem = certToPem(peer);
    X509_free(peer);
    // Compare ignoring trailing whitespace differences
    auto trim = [](std::string s) {
      while (!s.empty() && (s.back() == '\n' || s.back() == '\r' ||
                            s.back() == ' '))
        s.pop_back();
      return s;
    };
    if (trim(pem) != trim(pinned))
      throw DtlsError("certificate verification: pinned peer cert mismatch");
    peerPem = pem;
  }

  void finishPeer() {
    X509* peer = SSL_get_peer_certificate(ssl);
    if (peer) {
      peerPem = certToPem(peer);
      X509_free(peer);
    }
    if (!pinned.empty()) checkPin();
  }
};

// ---------------------------------------------------------------------------
// DtlsServer
// ---------------------------------------------------------------------------

struct DtlsServer::Impl {
  Session s;
  uint16_t port{0};
};

DtlsServer::DtlsServer(const DtlsConfig& cfg, uint16_t localPort)
    : impl_(std::make_unique<Impl>()) {
  if (cfg.certFile.empty() || cfg.keyFile.empty())
    throw DtlsError("certFile and keyFile required");
  impl_->s.cfg = cfg;
  impl_->s.pinned = cfg.pinnedPeerCert;
  impl_->port = localPort;
  impl_->s.ctx = makeCtx(cfg);
  impl_->s.fd = makeUdp(localPort);
}

DtlsServer::~DtlsServer() = default;

void DtlsServer::accept(int timeoutMs) {
  Session& s = impl_->s;
  if (s.connected) return;

  s.ssl = SSL_new(s.ctx);
  if (!s.ssl) throw DtlsError("SSL_new failed: " + drainErrors());

  SSL_set_options(s.ssl, SSL_OP_NO_QUERY_MTU);
  SSL_set_mtu(s.ssl, static_cast<unsigned>(s.cfg.mtu));
#ifdef DTLS_set_link_mtu
  DTLS_set_link_mtu(s.ssl, static_cast<unsigned>(s.cfg.mtu));
#endif

  BIO* bio = BIO_new_dgram(s.fd, BIO_NOCLOSE);
  SSL_set_bio(s.ssl, bio, bio);
  SSL_set_accept_state(s.ssl);

  const double deadline = nowSec() + timeoutMs / 1000.0;
  while (true) {
    int r = SSL_accept(s.ssl);
    if (r == 1) break;
    int err = SSL_get_error(s.ssl, r);
    if (err == SSL_ERROR_WANT_READ) {
      int left = static_cast<int>((deadline - nowSec()) * 1000);
      if (left <= 0) throw DtlsError("accept timeout");
      waitFd(s.fd, true, left);
      continue;
    }
    if (err == SSL_ERROR_WANT_WRITE) {
      int left = static_cast<int>((deadline - nowSec()) * 1000);
      if (left <= 0) throw DtlsError("accept timeout");
      waitFd(s.fd, false, left);
      continue;
    }
    throw DtlsError("SSL_accept failed: " + drainErrors());
  }

  s.finishPeer();
  s.connected = true;
  s.handshakeAt = nowSec();
}

bool DtlsServer::connected() const noexcept { return impl_->s.connected; }

int DtlsServer::send(const uint8_t* data, int len) {
  return impl_->s.doSend(data, len);
}

int DtlsServer::recv(uint8_t* out, int maxLen, int timeoutMs) {
  return impl_->s.doRecv(out, maxLen, timeoutMs);
}

std::string DtlsServer::peerCertPem() const { return impl_->s.peerPem; }

DtlsServer::Stats DtlsServer::stats() const { return impl_->s.stats; }

// ---------------------------------------------------------------------------
// DtlsClient
// ---------------------------------------------------------------------------

struct DtlsClient::Impl {
  Session s;
  std::string host;
  uint16_t port{0};
};

DtlsClient::DtlsClient(const DtlsConfig& cfg, const std::string& peerHost,
                       uint16_t peerPort)
    : impl_(std::make_unique<Impl>()) {
  if (cfg.certFile.empty() || cfg.keyFile.empty())
    throw DtlsError("certFile and keyFile required");
  impl_->s.cfg = cfg;
  impl_->s.pinned = cfg.pinnedPeerCert;
  impl_->host = peerHost;
  impl_->port = peerPort;
  impl_->s.ctx = makeCtx(cfg);
  impl_->s.fd = makeUdp(0);
}

DtlsClient::~DtlsClient() = default;

void DtlsClient::connect(int timeoutMs) {
  Session& s = impl_->s;
  if (s.connected) return;

  sockaddr_in peer{};
  peer.sin_family = AF_INET;
  peer.sin_port = htons(impl_->port);
  if (::inet_pton(AF_INET, impl_->host.c_str(), &peer.sin_addr) != 1)
    throw DtlsError("bad peer host: " + impl_->host);

  if (::connect(s.fd, reinterpret_cast<sockaddr*>(&peer), sizeof(peer)) < 0)
    throw DtlsError(std::string("connect failed: ") + strerror(errno));

  s.ssl = SSL_new(s.ctx);
  if (!s.ssl) throw DtlsError("SSL_new failed: " + drainErrors());

  SSL_set_options(s.ssl, SSL_OP_NO_QUERY_MTU);
  SSL_set_mtu(s.ssl, static_cast<unsigned>(s.cfg.mtu));
#ifdef DTLS_set_link_mtu
  DTLS_set_link_mtu(s.ssl, static_cast<unsigned>(s.cfg.mtu));
#endif

  BIO* bio = BIO_new_dgram(s.fd, BIO_NOCLOSE);
  BIO_ctrl(bio, BIO_CTRL_DGRAM_SET_CONNECTED, 0, &peer);
  SSL_set_bio(s.ssl, bio, bio);
  SSL_set_connect_state(s.ssl);

  const double deadline = nowSec() + timeoutMs / 1000.0;
  while (true) {
    int r = SSL_connect(s.ssl);
    if (r == 1) break;
    int err = SSL_get_error(s.ssl, r);
    if (err == SSL_ERROR_WANT_READ) {
      int left = static_cast<int>((deadline - nowSec()) * 1000);
      if (left <= 0) throw DtlsError("connect timeout");
      waitFd(s.fd, true, left);
      continue;
    }
    if (err == SSL_ERROR_WANT_WRITE) {
      int left = static_cast<int>((deadline - nowSec()) * 1000);
      if (left <= 0) throw DtlsError("connect timeout");
      waitFd(s.fd, false, left);
      continue;
    }
    throw DtlsError("SSL_connect failed: " + drainErrors());
  }

  s.finishPeer();
  s.connected = true;
  s.handshakeAt = nowSec();
}

bool DtlsClient::connected() const noexcept { return impl_->s.connected; }

int DtlsClient::send(const uint8_t* data, int len) {
  return impl_->s.doSend(data, len);
}

int DtlsClient::recv(uint8_t* out, int maxLen, int timeoutMs) {
  return impl_->s.doRecv(out, maxLen, timeoutMs);
}

std::string DtlsClient::peerCertPem() const { return impl_->s.peerPem; }

DtlsServer::Stats DtlsClient::stats() const { return impl_->s.stats; }

// ---------------------------------------------------------------------------
// generateSelfSigned
// ---------------------------------------------------------------------------

void generateSelfSigned(const std::string& certPath, const std::string& keyPath,
                        const std::string& commonName, int validDays) {
  initSsl();
  EVP_PKEY* pkey = EVP_PKEY_new();
  if (!pkey) throw DtlsError("EVP_PKEY_new failed");

  EVP_PKEY_CTX* pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_EC, nullptr);
  if (!pctx) {
    EVP_PKEY_free(pkey);
    throw DtlsError("EVP_PKEY_CTX_new_id failed");
  }
  if (EVP_PKEY_keygen_init(pctx) <= 0 ||
      EVP_PKEY_CTX_set_ec_paramgen_curve_nid(pctx, NID_X9_62_prime256v1) <= 0 ||
      EVP_PKEY_keygen(pctx, &pkey) <= 0) {
    EVP_PKEY_CTX_free(pctx);
    EVP_PKEY_free(pkey);
    throw DtlsError("keygen failed: " + drainErrors());
  }
  EVP_PKEY_CTX_free(pctx);

  X509* x509 = X509_new();
  if (!x509) {
    EVP_PKEY_free(pkey);
    throw DtlsError("X509_new failed");
  }
  ASN1_INTEGER_set(X509_get_serialNumber(x509), 1);
  X509_gmtime_adj(X509_getm_notBefore(x509), 0);
  X509_gmtime_adj(X509_getm_notAfter(x509),
                  static_cast<long>(60L * 60L * 24L * validDays));
  X509_set_pubkey(x509, pkey);

  X509_NAME* name = X509_get_subject_name(x509);
  X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
                             reinterpret_cast<const unsigned char*>(
                                 commonName.c_str()),
                             -1, -1, 0);
  X509_set_issuer_name(x509, name);
  if (X509_sign(x509, pkey, EVP_sha256()) == 0) {
    X509_free(x509);
    EVP_PKEY_free(pkey);
    throw DtlsError("X509_sign failed: " + drainErrors());
  }

  {
    FILE* f = ::fopen(keyPath.c_str(), "wb");
    if (!f) {
      X509_free(x509);
      EVP_PKEY_free(pkey);
      throw DtlsError("cannot write key file");
    }
    PEM_write_PrivateKey(f, pkey, nullptr, nullptr, 0, nullptr, nullptr);
    ::fclose(f);
  }
  {
    FILE* f = ::fopen(certPath.c_str(), "wb");
    if (!f) {
      X509_free(x509);
      EVP_PKEY_free(pkey);
      throw DtlsError("cannot write cert file");
    }
    PEM_write_X509(f, x509);
    ::fclose(f);
  }

  X509_free(x509);
  EVP_PKEY_free(pkey);
}

}  // namespace net
}  // namespace hush
