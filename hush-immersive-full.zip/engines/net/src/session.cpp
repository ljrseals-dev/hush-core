// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/session.hpp"
#include "session_wire.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstring>
#include <map>
#include <random>
#include <stdexcept>
#include <thread>

#if defined(_WIN32)
#error "hush::net is POSIX-only in this build"
#endif

namespace hush {
namespace net {

std::string serializeSdp(const SessionDescription& d) {
  return serializeSdpImpl(d);
}
bool parseSdp(const std::string& text, SessionDescription& out) {
  return parseSdpImpl(text, out);
}

namespace {

int makeUdp() {
  int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
  if (fd < 0) throw std::runtime_error("session: socket failed");
  int yes = 1;
  ::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
  return fd;
}

double nowSec() {
  using clock = std::chrono::steady_clock;
  return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

}  // namespace

// ---- Announcer -----------------------------------------------------------

struct Announcer::Impl {
  SessionDescription desc_;
  std::string group_;
  uint16_t port_{0};
  int sock_{-1};
  sockaddr_in dest_{};
  bool running_{false};
  std::thread thr_;
  int intervalMs_{5000};

  void sendOnce() {
    std::string sdp = serializeSdpImpl(desc_);
    ::sendto(sock_, sdp.data(), sdp.size(), 0,
             reinterpret_cast<sockaddr*>(&dest_), sizeof(dest_));
  }
};

Announcer::Announcer(const SessionDescription& desc,
                     const std::string& multicastGroup, uint16_t port)
    : impl_(std::make_unique<Impl>()) {
  impl_->desc_ = desc;
  impl_->group_ = multicastGroup;
  impl_->port_ = port;
  impl_->sock_ = makeUdp();
  // Enable multicast TTL
  unsigned char ttl = 1;
  ::setsockopt(impl_->sock_, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl));

  std::memset(&impl_->dest_, 0, sizeof(impl_->dest_));
  impl_->dest_.sin_family = AF_INET;
  impl_->dest_.sin_port = htons(port);
  if (::inet_pton(AF_INET, multicastGroup.c_str(), &impl_->dest_.sin_addr) != 1)
    throw std::runtime_error("Announcer: bad multicast group");
}

Announcer::~Announcer() {
  stop();
  if (impl_ && impl_->sock_ >= 0) ::close(impl_->sock_);
}

void Announcer::announceOnce() { impl_->sendOnce(); }

void Announcer::start(int intervalMs) {
  if (impl_->running_) return;
  impl_->intervalMs_ = intervalMs;
  impl_->running_ = true;
  impl_->thr_ = std::thread([this] {
    while (impl_->running_) {
      impl_->sendOnce();
      for (int i = 0; i < impl_->intervalMs_ / 10 && impl_->running_; ++i)
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
  });
}

void Announcer::stop() {
  if (!impl_->running_) return;
  impl_->running_ = false;
  if (impl_->thr_.joinable()) impl_->thr_.join();
}

// ---- Listener ------------------------------------------------------------

struct Listener::Impl {
  struct Entry {
    SessionDescription desc;
    double lastSeen{0.0};
  };
  std::map<std::string, Entry> sessions_;
  std::vector<SessionDescription> pending_;  // new/updated since last poll
  int sock_{-1};
  std::string group_;
  uint16_t port_{0};
};

Listener::Listener(const std::string& multicastGroup, uint16_t port)
    : impl_(std::make_unique<Impl>()) {
  impl_->group_ = multicastGroup;
  impl_->port_ = port;
  impl_->sock_ = makeUdp();

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_port = htons(port);
  if (::bind(impl_->sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) <
      0) {
    ::close(impl_->sock_);
    throw std::runtime_error("Listener: bind failed");
  }

  ip_mreq mreq{};
  if (::inet_pton(AF_INET, multicastGroup.c_str(), &mreq.imr_multiaddr) != 1)
    throw std::runtime_error("Listener: bad multicast group");
  mreq.imr_interface.s_addr = INADDR_ANY;
  if (::setsockopt(impl_->sock_, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq,
                   sizeof(mreq)) < 0) {
    // Multicast join may fail on some CI loopback setups; continue anyway
    // (unicast to the port still works for tests that inject).
  }
}

Listener::~Listener() {
  if (impl_ && impl_->sock_ >= 0) {
    ip_mreq mreq{};
    ::inet_pton(AF_INET, impl_->group_.c_str(), &mreq.imr_multiaddr);
    mreq.imr_interface.s_addr = INADDR_ANY;
    ::setsockopt(impl_->sock_, IPPROTO_IP, IP_DROP_MEMBERSHIP, &mreq,
                 sizeof(mreq));
    ::close(impl_->sock_);
  }
}

std::vector<SessionDescription> Listener::poll(int timeoutMs) {
  impl_->pending_.clear();
  const auto deadline =
      std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);

  do {
    uint8_t buf[4096];
    sockaddr_in src{};
    socklen_t slen = sizeof(src);
    ssize_t n = ::recvfrom(impl_->sock_, buf, sizeof(buf), MSG_DONTWAIT,
                           reinterpret_cast<sockaddr*>(&src), &slen);
    if (n <= 0) {
      if (timeoutMs <= 0) break;
      if (std::chrono::steady_clock::now() >= deadline) break;
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
      continue;
    }
    std::string text(reinterpret_cast<char*>(buf), static_cast<std::size_t>(n));
    SessionDescription d;
    if (!parseSdpImpl(text, d)) continue;  // malformed ignored

    auto it = impl_->sessions_.find(d.id);
    bool isNew = (it == impl_->sessions_.end());
    bool isUpdated = false;
    if (!isNew) {
      if (it->second.desc.audioPort != d.audioPort ||
          it->second.desc.format != d.format ||
          it->second.desc.sampleRate != d.sampleRate) {
        isUpdated = true;
      }
    }
    Impl::Entry e;
    e.desc = d;
    e.lastSeen = nowSec();
    impl_->sessions_[d.id] = e;
    if (isNew || isUpdated) impl_->pending_.push_back(d);
  } while (timeoutMs > 0 &&
           std::chrono::steady_clock::now() < deadline);

  return impl_->pending_;
}

std::vector<SessionDescription> Listener::known() const {
  std::vector<SessionDescription> out;
  for (const auto& kv : impl_->sessions_) out.push_back(kv.second.desc);
  return out;
}

void Listener::expire(double seconds) {
  const double cutoff = nowSec() - seconds;
  for (auto it = impl_->sessions_.begin(); it != impl_->sessions_.end();) {
    if (it->second.lastSeen < cutoff)
      it = impl_->sessions_.erase(it);
    else
      ++it;
  }
}

// ---- Negotiator (server) -------------------------------------------------

struct Negotiator::Impl {
  SessionDescription desc_;
  int sock_{-1};
  uint16_t boundPort_{0};
  uint32_t lastReqId_{0};
  sockaddr_in lastClient_{};
};

Negotiator::Negotiator(const SessionDescription& desc)
    : impl_(std::make_unique<Impl>()) {
  impl_->desc_ = desc;
}

Negotiator::~Negotiator() {
  if (impl_ && impl_->sock_ >= 0) ::close(impl_->sock_);
}

uint16_t Negotiator::listen(const std::string& iface) {
  impl_->sock_ = makeUdp();
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(0);  // ephemeral
  if (::inet_pton(AF_INET, iface.c_str(), &addr.sin_addr) != 1)
    addr.sin_addr.s_addr = INADDR_ANY;
  if (::bind(impl_->sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) <
      0) {
    ::close(impl_->sock_);
    impl_->sock_ = -1;
    throw std::runtime_error("Negotiator: bind failed");
  }
  socklen_t len = sizeof(addr);
  ::getsockname(impl_->sock_, reinterpret_cast<sockaddr*>(&addr), &len);
  impl_->boundPort_ = ntohs(addr.sin_port);
  return impl_->boundPort_;
}

std::optional<NegotiationRequest> Negotiator::pollRequest(int timeoutMs) {
  if (impl_->sock_ < 0) return std::nullopt;
  const auto deadline =
      std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
  do {
    uint8_t buf[4096];
    sockaddr_in src{};
    socklen_t slen = sizeof(src);
    ssize_t n = ::recvfrom(impl_->sock_, buf, sizeof(buf), MSG_DONTWAIT,
                           reinterpret_cast<sockaddr*>(&src), &slen);
    if (n <= 0) {
      if (timeoutMs <= 0) return std::nullopt;
      if (std::chrono::steady_clock::now() >= deadline) return std::nullopt;
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
      continue;
    }
    uint32_t reqId = 0;
    NegotiationRequest req;
    if (!decodeNegRequest(buf, static_cast<int>(n), reqId, req)) continue;
    impl_->lastReqId_ = reqId;
    impl_->lastClient_ = src;
    return req;
  } while (true);
}

void Negotiator::reply(const NegotiationReply& r, const std::string& clientHost,
                       uint16_t clientPort) {
  if (impl_->sock_ < 0) return;
  auto buf = encodeNegReply(impl_->lastReqId_, r);
  sockaddr_in dest = impl_->lastClient_;  // always prefer the peer we heard
  if (clientPort != 0) {
    dest.sin_port = htons(clientPort);
    if (::inet_pton(AF_INET, clientHost.c_str(), &dest.sin_addr) != 1) {
      dest = impl_->lastClient_;
    }
  }
  ::sendto(impl_->sock_, buf.data(), buf.size(), 0,
           reinterpret_cast<sockaddr*>(&dest), sizeof(dest));
}

// ---- NegotiationClient ---------------------------------------------------

struct NegotiationClient::Impl {
  std::string host_;
  uint16_t port_{0};
  int sock_{-1};
  std::mt19937 rng_{std::random_device{}()};
};

NegotiationClient::NegotiationClient(const std::string& serverHost,
                                     uint16_t controlPort)
    : impl_(std::make_unique<Impl>()) {
  impl_->host_ = serverHost;
  impl_->port_ = controlPort;
  impl_->sock_ = makeUdp();
  // Bind ephemeral so we can receive the reply
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_port = 0;
  if (::bind(impl_->sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) <
      0) {
    ::close(impl_->sock_);
    throw std::runtime_error("NegotiationClient: bind failed");
  }
}

NegotiationClient::~NegotiationClient() {
  if (impl_ && impl_->sock_ >= 0) ::close(impl_->sock_);
}

NegotiationReply NegotiationClient::negotiate(const NegotiationRequest& req,
                                              int timeoutMs) {
  uint32_t reqId = impl_->rng_();
  auto buf = encodeNegRequest(reqId, req);

  sockaddr_in dest{};
  dest.sin_family = AF_INET;
  dest.sin_port = htons(impl_->port_);
  if (::inet_pton(AF_INET, impl_->host_.c_str(), &dest.sin_addr) != 1)
    throw std::runtime_error("NegotiationClient: bad host");

  ::sendto(impl_->sock_, buf.data(), buf.size(), 0,
           reinterpret_cast<sockaddr*>(&dest), sizeof(dest));

  const auto deadline =
      std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
  while (std::chrono::steady_clock::now() < deadline) {
    uint8_t rbuf[4096];
    ssize_t n =
        ::recvfrom(impl_->sock_, rbuf, sizeof(rbuf), MSG_DONTWAIT, nullptr, nullptr);
    if (n <= 0) {
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
      continue;
    }
    uint32_t rid = 0;
    NegotiationReply reply;
    if (!decodeNegReply(rbuf, static_cast<int>(n), rid, reply)) continue;
    if (rid != reqId) continue;
    return reply;
  }
  throw std::runtime_error("NegotiationClient: timeout");
}

}  // namespace net
}  // namespace hush
