// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Internal UDP bind helper. Not exported.
 * Throws on missing interface / unresolvable address — never falls
 * back to INADDR_ANY silently.
 */

#include <cstdint>
#include <netinet/in.h>
#include <string>
#include <sys/socket.h>

namespace hush {
namespace net {

struct BoundSocket {
  int fd{-1};
  sockaddr_storage local{};
  socklen_t localLen{0};
  uint16_t boundPort{0};
};

/// Bind a UDP socket. address empty/"0.0.0.0" + !ipv6 → INADDR_ANY.
/// address empty/"::" + ipv6 → in6addr_any.
/// Non-empty address → getaddrinfo; family must match ipv6 flag.
/// Throws std::runtime_error on failure (fd closed first).
BoundSocket bindUdp(const std::string& address, uint16_t port,
                    bool reuseAddress, bool ipv6,
                    const std::string& multicastIface);

/// True if address is in multicast range (IPv4 or IPv6).
bool isMulticastAddress(const std::string& address);

}  // namespace net
}  // namespace hush
