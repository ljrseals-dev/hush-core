// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/supervisor.hpp"

#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <mutex>
#include <stdexcept>
#include <thread>

namespace hush {
namespace net {

namespace {

double nowSec() {
  using clock = std::chrono::steady_clock;
  return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

}  // namespace

// ---------------------------------------------------------------------------
// ClientSupervisor
// ---------------------------------------------------------------------------

struct ClientSupervisor::Impl {
  SupervisorConfig scfg_;
  std::string serverHost_;
  uint16_t controlPort_{0};
  NegotiationRequest baseReq_;
  TransportConfig tcfg_;

  std::mutex mu_;
  std::condition_variable cv_;
  std::atomic<bool> stop_{false};
  std::atomic<SupervisorState> state_{SupervisorState::Idle};
  Stats stats_{};

  std::unique_ptr<Receiver> receiver_;
  std::unique_ptr<Sender> sender_;  // optional push path
  std::thread worker_;

  int backoffMs() const {
    // attempt is stored in stats reconnectsFailed for current streak
    int attempt = static_cast<int>(stats_.reconnectsFailed);
    double ms = scfg_.minBackoffMs *
                std::pow(scfg_.backoffMultiplier, static_cast<double>(attempt));
    if (ms > scfg_.maxBackoffMs) ms = scfg_.maxBackoffMs;
    return static_cast<int>(ms);
  }

  bool connectOnce(int negotiateTimeoutMs) {
    NegotiationClient client(serverHost_, controlPort_);
    NegotiationReply reply;
    try {
      reply = client.negotiate(baseReq_, negotiateTimeoutMs);
    } catch (...) {
      return false;
    }
    if (!reply.accepted) return false;
    try {
      auto rx = makeReceiverFromReply(tcfg_, reply);
      {
        std::lock_guard<std::mutex> lock(mu_);
        receiver_ = std::move(rx);
      }
      return true;
    } catch (...) {
      return false;
    }
  }

  void workerLoop() {
    while (!stop_.load()) {
      SupervisorState st = state_.load();
      if (st != SupervisorState::Starved && st != SupervisorState::Reconnecting) {
        std::unique_lock<std::mutex> lock(mu_);
        cv_.wait_for(lock, std::chrono::milliseconds(50), [&] {
          return stop_.load() ||
                 state_.load() == SupervisorState::Starved ||
                 state_.load() == SupervisorState::Reconnecting;
        });
        continue;
      }

      state_.store(SupervisorState::Reconnecting);
      stats_.reconnectsStarted++;

      // Tear down current receiver outside lock duration for audio
      {
        std::lock_guard<std::mutex> lock(mu_);
        receiver_.reset();
      }

      int attempt = 0;
      bool ok = false;
      while (!stop_.load()) {
        if (scfg_.maxAttempts > 0 && attempt >= scfg_.maxAttempts) {
          state_.store(SupervisorState::Failed);
          break;
        }
        int sleepMs = backoffMs();
        // Sleep in small chunks so stop() is fast
        int slept = 0;
        while (slept < sleepMs && !stop_.load()) {
          std::this_thread::sleep_for(std::chrono::milliseconds(25));
          slept += 25;
        }
        if (stop_.load()) break;

        if (connectOnce(1500)) {
          stats_.reconnectsSucceeded++;
          stats_.reconnectsFailed = 0;
          state_.store(SupervisorState::Connected);
          ok = true;
          break;
        }
        stats_.reconnectsFailed++;
        ++attempt;
      }
      if (!ok && !stop_.load() && scfg_.maxAttempts > 0 &&
          attempt >= scfg_.maxAttempts) {
        state_.store(SupervisorState::Failed);
      }
    }
  }
};

ClientSupervisor::ClientSupervisor(const SupervisorConfig& scfg,
                                   const std::string& serverHost,
                                   uint16_t controlPort,
                                   const NegotiationRequest& baseRequest,
                                   const TransportConfig& tcfg)
    : impl_(std::make_unique<Impl>()) {
  impl_->scfg_ = scfg;
  impl_->serverHost_ = serverHost;
  impl_->controlPort_ = controlPort;
  impl_->baseReq_ = baseRequest;
  impl_->tcfg_ = tcfg;
}

ClientSupervisor::~ClientSupervisor() { stop(); }

void ClientSupervisor::start() {
  if (impl_->state_.load() != SupervisorState::Idle &&
      impl_->state_.load() != SupervisorState::Failed)
    return;

  impl_->stop_.store(false);
  int attempts = 0;
  while (!impl_->stop_.load()) {
    if (impl_->scfg_.maxAttempts > 0 && attempts >= impl_->scfg_.maxAttempts) {
      impl_->state_.store(SupervisorState::Failed);
      throw std::runtime_error("ClientSupervisor: max attempts exhausted");
    }
    if (impl_->connectOnce(2000)) {
      impl_->state_.store(SupervisorState::Connected);
      impl_->worker_ = std::thread([this] { impl_->workerLoop(); });
      return;
    }
    ++attempts;
    impl_->stats_.reconnectsFailed++;
    int ms = impl_->backoffMs();
    int slept = 0;
    while (slept < ms && !impl_->stop_.load()) {
      std::this_thread::sleep_for(std::chrono::milliseconds(25));
      slept += 25;
    }
  }
  throw std::runtime_error("ClientSupervisor: stopped during start");
}

void ClientSupervisor::stop() {
  impl_->stop_.store(true);
  impl_->cv_.notify_all();
  if (impl_->worker_.joinable()) impl_->worker_.join();
  {
    std::lock_guard<std::mutex> lock(impl_->mu_);
    impl_->receiver_.reset();
    impl_->sender_.reset();
  }
  impl_->state_.store(SupervisorState::Idle);
}

int ClientSupervisor::pull(float* out, int maxFrames) {
  if (!out || maxFrames <= 0) return 0;

  std::unique_ptr<Receiver> local;
  {
    std::lock_guard<std::mutex> lock(impl_->mu_);
    if (!impl_->receiver_) return 0;
  }

  int got = 0;
  {
    std::lock_guard<std::mutex> lock(impl_->mu_);
    if (impl_->receiver_) got = impl_->receiver_->pull(out, maxFrames);
  }

  if (got == 0 && impl_->state_.load() == SupervisorState::Connected) {
    double last = 0.0;
    {
      std::lock_guard<std::mutex> lock(impl_->mu_);
      if (impl_->receiver_) last = impl_->receiver_->lastPacketAtSec();
    }
    // If we never got a packet, last==0; treat as starvation only after
    // we've been connected long enough that last should have updated.
    double t = nowSec();
    if (last > 0.0 && (t - last) * 1000.0 > impl_->scfg_.starvationMs) {
      // Estimate frames lost over the starvation window
      const double rate = impl_->tcfg_.sampleRate > 0 ? impl_->tcfg_.sampleRate
                                                     : 48000.0;
      impl_->stats_.framesLostToDrop +=
          static_cast<uint64_t>(rate * impl_->scfg_.starvationMs / 1000.0 *
                                std::max(1, impl_->tcfg_.channels) /
                                std::max(1, impl_->tcfg_.channels));
      // frames = rate * time (mono equivalent); stereo frames counted once
      impl_->stats_.framesLostToDrop =
          static_cast<uint64_t>(rate * impl_->scfg_.starvationMs / 1000.0);

      impl_->state_.store(SupervisorState::Starved);
      impl_->cv_.notify_all();
    }
  }
  return got;
}

void ClientSupervisor::push(const float* interleaved, int numFrames) {
  if (!interleaved || numFrames <= 0) return;
  std::lock_guard<std::mutex> lock(impl_->mu_);
  if (!impl_->sender_) return;
  impl_->sender_->push(interleaved, numFrames);
  if (impl_->sender_->consecutiveSendErrors() >=
          impl_->scfg_.sendFailureThreshold &&
      impl_->state_.load() == SupervisorState::Connected) {
    impl_->state_.store(SupervisorState::Starved);
    impl_->cv_.notify_all();
  }
}

SupervisorState ClientSupervisor::state() const noexcept {
  return impl_->state_.load();
}

ClientSupervisor::Stats ClientSupervisor::stats() const {
  return impl_->stats_;
}

// ---------------------------------------------------------------------------
// ServerSupervisor
// ---------------------------------------------------------------------------

struct ServerSupervisor::Impl {
  SupervisorConfig scfg_;
  SessionDescription desc_;
  TransportConfig tcfg_;
  std::unique_ptr<Negotiator> negotiator_;
  std::unique_ptr<Sender> sender_;
  std::string clientHost_;
  uint16_t clientPort_{0};
  std::atomic<SupervisorState> state_{SupervisorState::Idle};
  ClientSupervisor::Stats stats_{};
  std::atomic<bool> stop_{false};
};

ServerSupervisor::ServerSupervisor(const SupervisorConfig& scfg,
                                   const SessionDescription& desc,
                                   const TransportConfig& tcfg)
    : impl_(std::make_unique<Impl>()) {
  impl_->scfg_ = scfg;
  impl_->desc_ = desc;
  impl_->tcfg_ = tcfg;
}

ServerSupervisor::~ServerSupervisor() { stop(); }

uint16_t ServerSupervisor::start() {
  impl_->stop_.store(false);
  impl_->negotiator_ = std::make_unique<Negotiator>(impl_->desc_);
  uint16_t port = impl_->negotiator_->listen("127.0.0.1");
  impl_->state_.store(SupervisorState::Connected);
  return port;
}

void ServerSupervisor::stop() {
  impl_->stop_.store(true);
  impl_->sender_.reset();
  impl_->negotiator_.reset();
  impl_->state_.store(SupervisorState::Idle);
}

void ServerSupervisor::tick() {
  if (impl_->stop_.load() || !impl_->negotiator_) return;

  auto req = impl_->negotiator_->pollRequest(0);
  if (req) {
    auto addr = returnAddressOf(*req);
    NegotiationReply reply;
    reply.accepted = true;
    reply.chosenFormat = impl_->desc_.format;
    reply.chosenSampleRate = impl_->desc_.sampleRate;
    reply.transportPort = impl_->desc_.audioPort;

    // Prefer return address for audio Sender
    if (addr) {
      impl_->clientHost_ = addr->host;
      impl_->clientPort_ = addr->port;
    } else {
      impl_->clientHost_ = "127.0.0.1";
      impl_->clientPort_ = impl_->desc_.audioPort;
    }

    impl_->negotiator_->reply(reply, "127.0.0.1", 0);

    try {
      impl_->sender_ = makeSenderForClient(impl_->tcfg_, reply,
                                           impl_->clientHost_,
                                           impl_->clientPort_);
      impl_->state_.store(SupervisorState::Connected);
    } catch (...) {
      impl_->stats_.reconnectsFailed++;
    }
  }

  if (impl_->sender_ &&
      impl_->sender_->consecutiveSendErrors() >=
          impl_->scfg_.sendFailureThreshold) {
    impl_->stats_.reconnectsStarted++;
    impl_->sender_.reset();
    impl_->state_.store(SupervisorState::Starved);
    // Next successful negotiate + sender rebuild counts as success
    if (impl_->state_.load() == SupervisorState::Starved) {
      // leave starved until next client request rebuilds sender
    }
  }
}

SupervisorState ServerSupervisor::state() const noexcept {
  return impl_->state_.load();
}

ClientSupervisor::Stats ServerSupervisor::stats() const {
  return impl_->stats_;
}

}  // namespace net
}  // namespace hush
