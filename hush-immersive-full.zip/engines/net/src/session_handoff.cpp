// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/session_handoff.hpp"

#include <cstring>
#include <sstream>

namespace hush {
namespace net {

NegotiationRejected::NegotiationRejected(const NegotiationReply& reply)
    : std::runtime_error([&] {
        std::ostringstream os;
        os << "negotiation rejected";
        if (!reply.reason.empty()) os << ": " << reply.reason;
        return os.str();
      }()),
      reply_(reply) {}

int channelCountForFormatName(const std::string& formatName) {
  // Names match immersive::channelFormatName / channelFormatFromName.
  static const std::pair<const char*, int> kTable[] = {
      {"Mono", 1},
      {"Stereo", 2},
      {"LCR", 3},
      {"Quad", 4},
      {"FivePointOne", 6},
      {"SevenPointOne", 8},
      {"FivePointOneFour", 10},
      {"SevenPointOneFour", 12},
      {"NinePointOneSix", 16},
      {"AmbisonicsFOA", 4},
      {"AmbisonicsSOA", 9},
      {"AmbisonicsHOA3", 16},
      // Aliases used in some SDP dumps
      {"5.1", 6},
      {"7.1", 8},
      {"5.1.4", 10},
      {"7.1.4", 12},
      {"9.1.6", 16},
  };
  for (const auto& row : kTable) {
    if (formatName == row.first) return row.second;
  }
  std::ostringstream os;
  os << "unknown channel format name: '" << formatName << "'";
  throw std::invalid_argument(os.str());
}

std::unique_ptr<Receiver> makeReceiverFromReply(
    TransportConfig cfg, const NegotiationReply& reply,
    const std::string& localBind) {
  if (!reply.accepted) throw NegotiationRejected(reply);
  if (reply.transportPort == 0) {
    throw std::runtime_error(
        "makeReceiverFromReply: accepted reply has transportPort == 0; "
        "the server must return a port the client can bind");
  }
  if (reply.chosenFormat.empty()) {
    throw std::runtime_error(
        "makeReceiverFromReply: accepted reply has empty chosenFormat");
  }
  if (reply.chosenSampleRate <= 0.0) {
    throw std::runtime_error(
        "makeReceiverFromReply: accepted reply has non-positive "
        "chosenSampleRate");
  }

  cfg.channels = channelCountForFormatName(reply.chosenFormat);
  cfg.sampleRate = reply.chosenSampleRate;
  // Prefer cfg.localBindAddress. Deprecated localBind applies only when
  // cfg still has the default "0.0.0.0".
  if ((cfg.localBindAddress.empty() || cfg.localBindAddress == "0.0.0.0") &&
      !localBind.empty() && localBind != "0.0.0.0") {
    cfg.localBindAddress = localBind;
  }
  cfg.localBindPort = reply.transportPort;
  return std::make_unique<Receiver>(cfg);
}

std::unique_ptr<Sender> makeSenderForClient(TransportConfig cfg,
                                            const NegotiationReply& reply,
                                            const std::string& clientHost,
                                            uint16_t clientPort) {
  if (!reply.accepted) throw NegotiationRejected(reply);
  if (clientHost.empty()) {
    throw std::invalid_argument("makeSenderForClient: clientHost is empty");
  }
  if (clientPort == 0) {
    throw std::invalid_argument(
        "makeSenderForClient: clientPort is 0; the server cannot "
        "build a Sender without a destination port");
  }
  if (reply.chosenFormat.empty()) {
    throw std::runtime_error(
        "makeSenderForClient: accepted reply has empty chosenFormat");
  }

  cfg.channels = channelCountForFormatName(reply.chosenFormat);
  cfg.sampleRate = reply.chosenSampleRate > 0.0 ? reply.chosenSampleRate
                                                 : cfg.sampleRate;

  return std::make_unique<Sender>(cfg, clientHost, clientPort);
}

namespace {
constexpr const char* kReturnHostKey = "return-host";
constexpr const char* kReturnPortKey = "return-port";
}  // namespace

void setReturnAddress(NegotiationRequest& req,
                      const ClientReturnAddress& addr) {
  auto upsert = [&](const std::string& key, const std::string& value) {
    const std::string prefix = key + "=";
    for (auto& a : req.attributes) {
      if (a.rfind(prefix, 0) == 0) {
        a = prefix + value;
        return;
      }
    }
    req.attributes.push_back(prefix + value);
  };
  upsert(kReturnHostKey, addr.host);
  upsert(kReturnPortKey, std::to_string(addr.port));
}

std::optional<ClientReturnAddress> returnAddressOf(
    const NegotiationRequest& req) {
  ClientReturnAddress out;
  bool haveHost = false, havePort = false;
  for (const auto& a : req.attributes) {
    if (a.rfind(std::string(kReturnHostKey) + "=", 0) == 0) {
      out.host = a.substr(std::strlen(kReturnHostKey) + 1);
      haveHost = true;
    } else if (a.rfind(std::string(kReturnPortKey) + "=", 0) == 0) {
      try {
        int p = std::stoi(a.substr(std::strlen(kReturnPortKey) + 1));
        if (p > 0 && p <= 65535) {
          out.port = static_cast<uint16_t>(p);
          havePort = true;
        }
      } catch (...) {
      }
    }
  }
  if (!haveHost || !havePort) return std::nullopt;
  return out;
}

}  // namespace net
}  // namespace hush
