// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/mdns.hpp"
#include "mdns_backend.hpp"

#include <chrono>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

namespace hush {
namespace net {

std::string buildTxtRecord(const SessionDescription& d) {
  std::ostringstream os;
  os << "ver=1"
     << " id=" << d.id
     << " name=" << d.name
     << " fmt=" << d.format
     << " rate=" << static_cast<long long>(d.sampleRate)
     << " ch=" << d.channels
     << " codec=" << d.codec
     << " aport=" << d.audioPort;
  for (const auto& a : d.attributes) os << " a=" << a;
  return os.str();
}

SessionDescription parseTxtRecord(const std::string& txt,
                                  const std::string& instanceName,
                                  const std::string& host, uint16_t port) {
  SessionDescription d;
  d.name = instanceName;
  d.host = host;
  d.audioPort = port;

  std::istringstream is(txt);
  std::string tok;
  bool haveVer = false, haveId = false;
  while (is >> tok) {
    auto eq = tok.find('=');
    if (eq == std::string::npos) continue;
    const std::string k = tok.substr(0, eq);
    const std::string v = tok.substr(eq + 1);
    if (k == "ver") {
      if (v != "1") throw std::invalid_argument("bad TXT ver: " + v);
      haveVer = true;
    } else if (k == "id") {
      d.id = v;
      haveId = true;
    } else if (k == "name") {
      d.name = v;
    } else if (k == "fmt" || k == "format") {
      d.format = v;
    } else if (k == "rate") {
      d.sampleRate = std::stod(v);
    } else if (k == "ch" || k == "channels") {
      d.channels = std::stoi(v);
    } else if (k == "codec") {
      d.codec = v;
    } else if (k == "aport") {
      int p = std::stoi(v);
      if (p > 0 && p <= 65535) d.audioPort = static_cast<uint16_t>(p);
    } else if (k == "a" || k == "attr") {
      d.attributes.push_back(v);
    }
  }
  if (!haveVer) throw std::invalid_argument("TXT missing ver=");
  if (!haveId) throw std::invalid_argument("TXT missing id=");
  return d;
}

bool mdnsDaemonAvailable() {
  try {
    auto b = detail::makePlatformBackend();
    return b && b->daemonReachable();
  } catch (...) {
    return false;
  }
}

struct MdnsAnnouncer::Impl {
  SessionDescription desc;
  std::unique_ptr<detail::MdnsBackend> backend;
  bool started{false};
};

MdnsAnnouncer::MdnsAnnouncer(const SessionDescription& d)
    : impl_(std::make_unique<Impl>()) {
  impl_->desc = d;
}

MdnsAnnouncer::~MdnsAnnouncer() {
  if (impl_ && impl_->started) {
    try {
      impl_->backend->withdrawService();
    } catch (...) {
    }
  }
}

void MdnsAnnouncer::start() {
  if (impl_->started) return;
  if (!impl_->backend) impl_->backend = detail::makePlatformBackend();
  if (!impl_->backend->daemonReachable())
    throw std::runtime_error(
        "mDNS daemon not reachable; install avahi-daemon (Linux) "
        "or check Bonjour (macOS)");
  const std::string name =
      impl_->desc.name.empty() ? impl_->desc.id : impl_->desc.name;
  const uint16_t port =
      impl_->desc.audioPort != 0 ? impl_->desc.audioPort : 9875;
  impl_->backend->registerService(name, port, buildTxtRecord(impl_->desc));
  impl_->started = true;
}

void MdnsAnnouncer::stop() {
  if (!impl_->started) return;
  try {
    impl_->backend->withdrawService();
  } catch (...) {
  }
  impl_->started = false;
}

bool MdnsAnnouncer::isRegistered() const noexcept {
  return impl_ && impl_->started;
}

struct MdnsBrowser::Impl {
  std::unique_ptr<detail::MdnsBackend> backend;
  bool started{false};
  mutable std::mutex mu;
  std::unordered_map<std::string, std::pair<MdnsServiceRecord, double>> known;

  static double nowSec() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double>(clock::now().time_since_epoch())
        .count();
  }
};

MdnsBrowser::MdnsBrowser() : impl_(std::make_unique<Impl>()) {}
MdnsBrowser::~MdnsBrowser() { stop(); }

void MdnsBrowser::start(int timeoutMs) {
  if (impl_->started) return;
  if (!impl_->backend) impl_->backend = detail::makePlatformBackend();
  if (!impl_->backend->daemonReachable())
    throw std::runtime_error("mDNS daemon not reachable; cannot browse");
  impl_->backend->startBrowse();
  impl_->started = true;
  (void)impl_->backend->poll(timeoutMs);
}

void MdnsBrowser::stop() {
  if (!impl_->started) return;
  try {
    if (impl_->backend) impl_->backend->stop();
  } catch (...) {
  }
  impl_->started = false;
}

std::vector<MdnsServiceRecord> MdnsBrowser::poll(int timeoutMs) {
  if (!impl_->backend || !impl_->started) return {};
  auto fresh = impl_->backend->poll(timeoutMs);
  std::lock_guard<std::mutex> lock(impl_->mu);
  const double t = Impl::nowSec();
  for (auto& r : fresh) impl_->known[r.name] = {r, t};
  return fresh;
}

std::vector<MdnsServiceRecord> MdnsBrowser::known() const {
  std::lock_guard<std::mutex> lock(impl_->mu);
  std::vector<MdnsServiceRecord> out;
  out.reserve(impl_->known.size());
  for (const auto& kv : impl_->known) out.push_back(kv.second.first);
  return out;
}

void MdnsBrowser::expire(double seconds) {
  std::lock_guard<std::mutex> lock(impl_->mu);
  const double t = Impl::nowSec();
  for (auto it = impl_->known.begin(); it != impl_->known.end();) {
    if (t - it->second.second > seconds)
      it = impl_->known.erase(it);
    else
      ++it;
  }
}

}  // namespace net
}  // namespace hush
