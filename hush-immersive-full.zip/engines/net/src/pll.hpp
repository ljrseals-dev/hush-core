// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Second-order PLL on packet arrival times for clock recovery.
 * Estimates sender rate = sampleRate * (1 + correction).
 */

namespace hush {
namespace net {

class ClockPll {
 public:
  ClockPll() : ClockPll(48000.0, 0.05, 1.0) {}
  ClockPll(double nominalRate, double bandwidthHz, double damping);

  /// Update with sender timestamp (seconds) and local arrival time (seconds).
  void update(double senderTimeSec, double localTimeSec);

  /// Estimated sender sample rate in Hz.
  double estimatedRate() const;

  void reset();

 private:
  double nominalRate_;
  double bw_;
  double damp_;
  double phaseError_{0.0};
  double freqCorrection_{0.0};  // relative: rate = nominal * (1 + corr)
  double lastSenderTime_{-1.0};
  double lastLocalTime_{-1.0};
  int updates_{0};
};

}  // namespace net
}  // namespace hush
