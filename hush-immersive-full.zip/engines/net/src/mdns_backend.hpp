// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
#include "hush/net/mdns.hpp"
#include <memory>
#include <string>
#include <vector>

namespace hush {
namespace net {
namespace detail {

constexpr const char* kServiceType = "_hush-audio._udp";

class MdnsBackend {
 public:
  virtual ~MdnsBackend() = default;
  virtual void registerService(const std::string& name, uint16_t port,
                               const std::string& txt) = 0;
  virtual void withdrawService() = 0;
  virtual void startBrowse() = 0;
  virtual std::vector<MdnsServiceRecord> poll(int timeoutMs) = 0;
  virtual void stop() {}
  virtual bool daemonReachable() const noexcept = 0;
};

std::unique_ptr<MdnsBackend> makePlatformBackend();

}  // namespace detail
}  // namespace net
}  // namespace hush
