// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace hush {
namespace net {

struct SessionDescription {
  std::string id;
  std::string name;
  std::string host;
  uint16_t audioPort{0};
  std::string format;
  double sampleRate{48000.0};
  int channels{2};
  std::string codec{"f32"};
  std::vector<std::string> attributes;
};

class Announcer {
 public:
  Announcer(const SessionDescription& desc,
            const std::string& multicastGroup = "239.255.42.99",
            uint16_t port = 9875);
  ~Announcer();

  Announcer(const Announcer&) = delete;
  Announcer& operator=(const Announcer&) = delete;

  void start(int intervalMs = 5000);
  void stop();
  void announceOnce();

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class Listener {
 public:
  Listener(const std::string& multicastGroup = "239.255.42.99",
           uint16_t port = 9875);
  ~Listener();

  Listener(const Listener&) = delete;
  Listener& operator=(const Listener&) = delete;

  std::vector<SessionDescription> poll(int timeoutMs = 0);
  std::vector<SessionDescription> known() const;
  void expire(double seconds = 30.0);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

struct NegotiationRequest {
  std::string sessionId;
  std::string clientName;
  std::vector<std::string> supportedFormats;
  double preferredSampleRate{48000.0};
  /// Free-form key=value attributes (e.g. return-host / return-port).
  std::vector<std::string> attributes;
};

struct NegotiationReply {
  bool accepted{false};
  std::string reason;
  std::string chosenFormat;
  double chosenSampleRate{0.0};
  uint16_t transportPort{0};
};

class Negotiator {
 public:
  explicit Negotiator(const SessionDescription& desc);
  ~Negotiator();

  Negotiator(const Negotiator&) = delete;
  Negotiator& operator=(const Negotiator&) = delete;

  uint16_t listen(const std::string& iface = "0.0.0.0");
  std::optional<NegotiationRequest> pollRequest(int timeoutMs = 0);
  void reply(const NegotiationReply& r, const std::string& clientHost,
             uint16_t clientPort);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class NegotiationClient {
 public:
  NegotiationClient(const std::string& serverHost, uint16_t controlPort);
  ~NegotiationClient();

  NegotiationClient(const NegotiationClient&) = delete;
  NegotiationClient& operator=(const NegotiationClient&) = delete;

  NegotiationReply negotiate(const NegotiationRequest& req,
                             int timeoutMs = 2000);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

// Wire helpers (also used by tests for T9)
std::string serializeSdp(const SessionDescription& d);
bool parseSdp(const std::string& text, SessionDescription& out);

}  // namespace net
}  // namespace hush
