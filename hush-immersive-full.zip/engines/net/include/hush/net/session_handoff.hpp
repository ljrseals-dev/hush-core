// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Session handoff: after NegotiationClient succeeds, construct a
 * Receiver (client side) or Sender (host side) pointed at the
 * negotiated endpoint.
 */

#include "hush/net/session.hpp"
#include "hush/net/transport.hpp"

#include <memory>
#include <optional>
#include <stdexcept>
#include <string>

namespace hush {
namespace net {

class NegotiationRejected : public std::runtime_error {
 public:
  explicit NegotiationRejected(const NegotiationReply& reply);
  const NegotiationReply& reply() const noexcept { return reply_; }

 private:
  NegotiationReply reply_;
};

int channelCountForFormatName(const std::string& formatName);

std::unique_ptr<Receiver> makeReceiverFromReply(
    TransportConfig cfg, const NegotiationReply& reply,
    const std::string& localBind = "0.0.0.0");

std::unique_ptr<Sender> makeSenderForClient(TransportConfig cfg,
                                            const NegotiationReply& reply,
                                            const std::string& clientHost,
                                            uint16_t clientPort);

struct ClientReturnAddress {
  std::string host;
  uint16_t port{0};
};

void setReturnAddress(NegotiationRequest& req,
                      const ClientReturnAddress& addr);

std::optional<ClientReturnAddress> returnAddressOf(
    const NegotiationRequest& req);

}  // namespace net
}  // namespace hush
