// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <cstdint>
#include <memory>
#include <string>

namespace hush {
namespace net {

struct TransportConfig {
  // Sender
  int payloadBytesPerPacket{480};  // 10 ms @ 48k mono f32
  int fecBlockSize{4};             // N data + 1 repair
  int nackRetryCount{3};
  int nackTimeoutMs{20};

  // Receiver
  int jitterBufferPackets{8};  // 80 ms nominal
  int maxJitterPackets{64};
  double clockPllBandwidthHz{0.05};
  double clockPllDamping{1.0};

  // Both
  int channels{1};
  double sampleRate{48000.0};

  // Bind selection (additive)
  std::string localBindAddress{"0.0.0.0"};  // "" = default
  uint16_t localBindPort{0};                // 0 = OS assigns
  bool reuseAddress{true};
  bool ipv6{false};
  std::string multicastIface{""};  // empty = OS default
};

class Sender {
 public:
  Sender(const TransportConfig& cfg, const std::string& remoteHost,
         uint16_t remotePort);
  ~Sender();

  Sender(const Sender&) = delete;
  Sender& operator=(const Sender&) = delete;

  void push(const float* interleaved, int numFrames);
  void flush();

  /// Actual local port after bind (0 if not bound).
  uint16_t localPort() const noexcept;

  /// Consecutive sendto() failures since last success (supervisor).
  int consecutiveSendErrors() const noexcept;

  struct Stats {
    uint64_t packetsSent{0};
    uint64_t repairSent{0};
    uint64_t nacksReceived{0};
    uint64_t retransmits{0};
  };
  Stats stats() const;

  void setTestLossRate(double lossRate);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class Receiver {
 public:
  /// Preferred: bind from cfg.localBindAddress / cfg.localBindPort.
  explicit Receiver(const TransportConfig& cfg);

  /// Compatibility: sets localBindPort = port and delegates.
  Receiver(const TransportConfig& cfg, uint16_t port);

  ~Receiver();

  Receiver(const Receiver&) = delete;
  Receiver& operator=(const Receiver&) = delete;

  int pull(float* out, int maxFrames);

  double estimatedSenderRate() const;
  int jitterDepth() const;

  /// Actual local port after bind.
  uint16_t localPort() const noexcept;

  /// Bound address as dotted quad / presentation form (for tests).
  std::string localAddress() const;

  /// Steady-clock seconds of last received packet (0 if none yet).
  double lastPacketAtSec() const noexcept;

  struct Stats {
    uint64_t packetsReceived{0};
    uint64_t packetsLost{0};
    uint64_t packetsRecovered{0};
    uint64_t nacksSent{0};
    uint64_t retransmitHits{0};
    uint64_t latePackets{0};
  };
  Stats stats() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace net
}  // namespace hush
