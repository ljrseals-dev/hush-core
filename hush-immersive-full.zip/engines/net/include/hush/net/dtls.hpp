// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * DTLS 1.3 wrapper for the audio transport.
 * Optional: built only when HUSH_WITH_DTLS=ON.
 */

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>

namespace hush {
namespace net {

enum class DtlsRole { Server, Client };

struct DtlsConfig {
  DtlsRole role{DtlsRole::Client};
  std::string certFile;
  std::string keyFile;
  std::string caFile;
  std::string pinnedPeerCert;
  std::string cipherSuites{"TLS_CHACHA20_POLY1305_SHA256"};
  int mtu{1200};
  int handshakeTimeoutMs{5000};
  int rekeyAfterPackets{1 << 22};
  int rekeyAfterSeconds{3600};
};

class DtlsError : public std::runtime_error {
 public:
  explicit DtlsError(const std::string& what);
};

class DtlsServer {
 public:
  DtlsServer(const DtlsConfig& cfg, uint16_t localPort);
  ~DtlsServer();

  DtlsServer(const DtlsServer&) = delete;
  DtlsServer& operator=(const DtlsServer&) = delete;

  void accept(int timeoutMs);
  bool connected() const noexcept;

  int send(const uint8_t* data, int len);
  int recv(uint8_t* out, int maxLen, int timeoutMs);

  std::string peerCertPem() const;

  struct Stats {
    uint64_t packetsSent{0};
    uint64_t packetsReceived{0};
    uint64_t replayDrops{0};
    uint64_t decryptFailures{0};
    uint64_t rekeys{0};
  };
  Stats stats() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class DtlsClient {
 public:
  DtlsClient(const DtlsConfig& cfg, const std::string& peerHost,
             uint16_t peerPort);
  ~DtlsClient();

  DtlsClient(const DtlsClient&) = delete;
  DtlsClient& operator=(const DtlsClient&) = delete;

  void connect(int timeoutMs);
  bool connected() const noexcept;

  int send(const uint8_t* data, int len);
  int recv(uint8_t* out, int maxLen, int timeoutMs);

  std::string peerCertPem() const;
  DtlsServer::Stats stats() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

void generateSelfSigned(const std::string& certPath,
                        const std::string& keyPath,
                        const std::string& commonName, int validDays = 1);

}  // namespace net
}  // namespace hush
