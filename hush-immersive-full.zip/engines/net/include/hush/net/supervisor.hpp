// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
/**
 * Supervised reconnect for negotiation + transport.
 * Audio path never blocks on negotiation; reconnect runs on a worker.
 */

#include "hush/net/session.hpp"
#include "hush/net/session_handoff.hpp"
#include "hush/net/transport.hpp"

#include <cstdint>
#include <memory>
#include <string>

namespace hush {
namespace net {

struct SupervisorConfig {
  int starvationMs{500};
  int sendFailureThreshold{20};
  int minBackoffMs{250};
  int maxBackoffMs{8000};
  double backoffMultiplier{2.0};
  int maxAttempts{0};  // 0 = infinite
  bool keepJitterBuffer{false};
};

enum class SupervisorState {
  Idle,
  Connected,
  Starved,
  Reconnecting,
  Failed
};

class ClientSupervisor {
 public:
  ClientSupervisor(const SupervisorConfig& scfg, const std::string& serverHost,
                   uint16_t controlPort, const NegotiationRequest& baseRequest,
                   const TransportConfig& tcfg);
  ~ClientSupervisor();

  ClientSupervisor(const ClientSupervisor&) = delete;
  ClientSupervisor& operator=(const ClientSupervisor&) = delete;

  void start();
  void stop();

  int pull(float* out, int maxFrames);
  void push(const float* interleaved, int numFrames);

  SupervisorState state() const noexcept;

  struct Stats {
    uint64_t reconnectsStarted{0};
    uint64_t reconnectsSucceeded{0};
    uint64_t reconnectsFailed{0};
    uint64_t framesLostToDrop{0};
  };
  Stats stats() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class ServerSupervisor {
 public:
  ServerSupervisor(const SupervisorConfig& scfg,
                   const SessionDescription& desc,
                   const TransportConfig& tcfg);
  ~ServerSupervisor();

  ServerSupervisor(const ServerSupervisor&) = delete;
  ServerSupervisor& operator=(const ServerSupervisor&) = delete;

  uint16_t start();
  void stop();
  void tick();

  SupervisorState state() const noexcept;
  ClientSupervisor::Stats stats() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace net
}  // namespace hush
