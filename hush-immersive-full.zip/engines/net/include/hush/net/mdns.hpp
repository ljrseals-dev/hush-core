// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once
#include "hush/net/session.hpp"
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace hush {
namespace net {

struct MdnsServiceRecord {
  std::string name;
  std::string host;
  uint16_t port{0};
  SessionDescription session;
  std::string txtRaw;
};

class MdnsAnnouncer {
 public:
  explicit MdnsAnnouncer(const SessionDescription& desc);
  ~MdnsAnnouncer();
  MdnsAnnouncer(const MdnsAnnouncer&) = delete;
  MdnsAnnouncer& operator=(const MdnsAnnouncer&) = delete;
  void start();
  void stop();
  bool isRegistered() const noexcept;
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class MdnsBrowser {
 public:
  MdnsBrowser();
  ~MdnsBrowser();
  MdnsBrowser(const MdnsBrowser&) = delete;
  MdnsBrowser& operator=(const MdnsBrowser&) = delete;
  void start(int timeoutMs = 500);
  void stop();
  std::vector<MdnsServiceRecord> poll(int timeoutMs = 0);
  std::vector<MdnsServiceRecord> known() const;
  void expire(double seconds = 30.0);
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

bool mdnsDaemonAvailable();
std::string buildTxtRecord(const SessionDescription& desc);
SessionDescription parseTxtRecord(const std::string& txt,
                                  const std::string& instanceName,
                                  const std::string& host, uint16_t port);

}  // namespace net
}  // namespace hush
