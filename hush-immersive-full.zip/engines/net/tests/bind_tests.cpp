// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/session_handoff.hpp"
#include "hush/net/transport.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstring>
#include <iostream>
#include <thread>
#include <vector>

using namespace hush::net;

static int failures = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (!(c)) {                                                          \
      std::cerr << "FAIL: " #c " at line " << __LINE__ << "\n";          \
      ++failures;                                                        \
    }                                                                    \
  } while (0)

static bool loopbackPairOk = true;

static void probeLoopbackPair() {
  // Check whether 127.0.0.2 is usable as a distinct bind address
  int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
  if (fd < 0) {
    loopbackPairOk = false;
    return;
  }
  sockaddr_in a{};
  a.sin_family = AF_INET;
  a.sin_port = 0;
  ::inet_pton(AF_INET, "127.0.0.2", &a.sin_addr);
  if (::bind(fd, reinterpret_cast<sockaddr*>(&a), sizeof(a)) < 0)
    loopbackPairOk = false;
  ::close(fd);
  if (!loopbackPairOk)
    std::cout << "NOTICE: 127.0.0.2 not bindable — T1 partial skip\n";
}

// T1 Loopback bind isolation
static void testLoopbackIsolation() {
  TransportConfig rxCfg;
  rxCfg.channels = 1;
  rxCfg.localBindAddress = "127.0.0.1";
  rxCfg.localBindPort = 0;
  Receiver rx(rxCfg);
  uint16_t port = rx.localPort();
  CHECK(port != 0);
  CHECK(rx.localAddress() == "127.0.0.1");

  TransportConfig txCfg;
  txCfg.channels = 1;
  txCfg.localBindAddress = "127.0.0.1";
  Sender tx(txCfg, "127.0.0.1", port);

  std::vector<float> in(120, 0.5f);
  tx.push(in.data(), 120);
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(30));

  std::vector<float> out(500, 0.f);
  int got = 0;
  for (int i = 0; i < 10; ++i) {
    got += rx.pull(out.data() + got, 500 - got);
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
  CHECK(got > 0);

  if (loopbackPairOk) {
    // Sender from 127.0.0.2 → Receiver on 127.0.0.1 should not receive
    // when we bind the receiver exclusively... Actually on Linux both
    // are loopback and packets to 127.0.0.1 arrive regardless of
    // sender bind. The meaningful isolation test is: Receiver bound
    // to 127.0.0.1 does not receive packets addressed to 127.0.0.2.
    TransportConfig rx2cfg;
    rx2cfg.channels = 1;
    rx2cfg.localBindAddress = "127.0.0.2";
    rx2cfg.localBindPort = 0;
    Receiver rx2(rx2cfg);
    uint16_t p2 = rx2.localPort();

    TransportConfig tx2;
    tx2.channels = 1;
    tx2.localBindAddress = "127.0.0.1";
    // Send TO 127.0.0.2 — rx on 127.0.0.1 must not see it
    Sender s2(tx2, "127.0.0.2", p2);
    s2.push(in.data(), 120);
    s2.flush();
    std::this_thread::sleep_for(std::chrono::milliseconds(30));

    std::vector<float> out1(500, 0.f);
    int leak = 0;
    for (int i = 0; i < 5; ++i) leak += rx.pull(out1.data(), 500);
    // rx bound to .1 should not get packets sent to .2
    CHECK(leak == 0);

    std::vector<float> out2(500, 0.f);
    int got2 = 0;
    for (int i = 0; i < 10; ++i) {
      got2 += rx2.pull(out2.data() + got2, 500 - got2);
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    CHECK(got2 > 0);
  }
  std::cout << "[T1] Loopback bind isolation OK\n";
}

// T2 Wrong interface throws
static void testWrongInterfaceThrows() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.localBindAddress = "198.51.100.1";  // TEST-NET-2
  cfg.localBindPort = 0;
  bool threw = false;
  try {
    Receiver r(cfg);
  } catch (const std::runtime_error& e) {
    threw = true;
    CHECK(std::string(e.what()).find("198.51.100.1") != std::string::npos ||
          std::string(e.what()).find("bind") != std::string::npos ||
          std::string(e.what()).find("getaddrinfo") != std::string::npos);
  }
  CHECK(threw);
  std::cout << "[T2] Wrong interface throws OK\n";
}

// T3 IPv6 loopback (skip if unavailable)
static void testIpv6() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.ipv6 = true;
  cfg.localBindAddress = "::1";
  cfg.localBindPort = 0;
  try {
    Receiver rx(cfg);
    CHECK(rx.localPort() != 0);
    std::cout << "[T3] IPv6 loopback OK (port " << rx.localPort() << ")\n";
  } catch (const std::exception& e) {
    std::cout << "[T3] IPv6 skipped: " << e.what() << "\n";
  }
}

// T4 Port 0 OS-assigned
static void testPortZero() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.localBindAddress = "127.0.0.1";
  cfg.localBindPort = 0;
  Receiver rx(cfg);
  uint16_t p = rx.localPort();
  CHECK(p != 0);

  TransportConfig txCfg;
  txCfg.channels = 1;
  txCfg.localBindAddress = "127.0.0.1";
  Sender tx(txCfg, "127.0.0.1", p);
  std::vector<float> in(120, 0.25f);
  tx.push(in.data(), 120);
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(30));
  std::vector<float> out(300, 0.f);
  int got = 0;
  for (int i = 0; i < 10; ++i) {
    got += rx.pull(out.data() + got, 300 - got);
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
  CHECK(got > 0);
  std::cout << "[T4] Port 0 OS-assigned OK (port=" << p << ")\n";
}

// T5 SO_REUSEADDR
static void testReuse() {
  TransportConfig a;
  a.channels = 1;
  a.localBindAddress = "127.0.0.1";
  a.localBindPort = 0;
  a.reuseAddress = true;
  Receiver r1(a);
  uint16_t p = r1.localPort();

  TransportConfig b = a;
  b.localBindPort = static_cast<uint16_t>(p + 1);
  Receiver r2(b);  // different port — both ok
  CHECK(r2.localPort() != 0);

  TransportConfig c = a;
  c.localBindPort = p;
  c.reuseAddress = false;
  bool threw = false;
  try {
    Receiver r3(c);
  } catch (const std::runtime_error&) {
    threw = true;
  }
  // With reuseAddress false on same port as live socket, bind should fail
  CHECK(threw);
  std::cout << "[T5] SO_REUSEADDR OK\n";
}

// T6 Multicast interface not found
static void testMulticastIfaceMissing() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.localBindAddress = "0.0.0.0";
  cfg.multicastIface = "nosuch0";
  bool threw = false;
  try {
    Receiver r(cfg);
  } catch (const std::runtime_error& e) {
    threw = true;
    CHECK(std::string(e.what()).find("nosuch0") != std::string::npos);
  }
  CHECK(threw);
  std::cout << "[T6] Missing multicast iface throws OK\n";
}

// T7 Deprecated localBind is no-op when cfg has address
static void testDeprecatedLocalBind() {
  NegotiationReply reply;
  reply.accepted = true;
  reply.chosenFormat = "Stereo";
  reply.chosenSampleRate = 48000.0;
  reply.transportPort = 0;  // OS assign via cfg

  TransportConfig cfg;
  cfg.localBindAddress = "127.0.0.1";
  cfg.localBindPort = 0;
  // Hand-craft: transportPort 0 is rejected by makeReceiverFromReply
  // so set a free port via OS by binding once
  Receiver probe(cfg);
  reply.transportPort = probe.localPort();
  // release probe
  // re-bind via handoff
  TransportConfig cfg2;
  cfg2.localBindAddress = "127.0.0.1";
  auto rx = makeReceiverFromReply(cfg2, reply, "10.0.0.1");  // deprecated
  CHECK(rx != nullptr);
  CHECK(rx->localAddress() == "127.0.0.1");
  std::cout << "[T7] Deprecated localBind no-op OK\n";
}

// T8 Sender multicast path
static void testSenderMulticast() {
  // Join group on a raw socket, send via Sender
  const char* group = "239.255.42.99";
  int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
  CHECK(fd >= 0);
  int yes = 1;
  ::setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(19890);
  addr.sin_addr.s_addr = INADDR_ANY;
  CHECK(::bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == 0);
  ip_mreq mreq{};
  ::inet_pton(AF_INET, group, &mreq.imr_multiaddr);
  mreq.imr_interface.s_addr = INADDR_ANY;
  ::setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq));

  TransportConfig cfg;
  cfg.channels = 1;
  cfg.localBindAddress = "0.0.0.0";
  Sender tx(cfg, group, 19890);
  std::vector<float> in(120, 0.75f);
  tx.push(in.data(), 120);
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(50));

  uint8_t buf[4096];
  ssize_t n = ::recvfrom(fd, buf, sizeof(buf), MSG_DONTWAIT, nullptr, nullptr);
  CHECK(n > 0);
  ::close(fd);
  std::cout << "[T8] Sender multicast path OK\n";
}

int main() {
  std::cout << "Per-interface bind tests\n";
  probeLoopbackPair();
  testLoopbackIsolation();
  testWrongInterfaceThrows();
  testIpv6();
  testPortZero();
  testReuse();
  testMulticastIfaceMissing();
  testDeprecatedLocalBind();
  testSenderMulticast();
  if (failures) {
    std::cerr << failures << " failure(s)\n";
    return 1;
  }
  std::cout << "ALL BIND TESTS PASSED\n";
  return 0;
}
