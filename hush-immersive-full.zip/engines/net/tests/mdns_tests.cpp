// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/mdns.hpp"
#include "hush/net/session_handoff.hpp"
#include <chrono>
#include <iostream>
#include <thread>
using namespace hush::net;
static int failures = 0;
#define CHECK(c) do { if (!(c)) { std::cerr << "FAIL: " #c " at " << __LINE__ << "\n"; ++failures; } } while(0)

static SessionDescription makeDesc(const std::string& id, const std::string& name, uint16_t port, const std::string& fmt = "Stereo") {
  SessionDescription d;
  d.id = id; d.name = name; d.host = "127.0.0.1"; d.audioPort = port;
  d.format = fmt; d.sampleRate = 48000.0; d.channels = 2; d.codec = "f32";
  d.attributes = {"room=studioA"};
  return d;
}

int main() {
  std::cout << "mDNS tests\n";
  {
    auto d = makeDesc("abc-123", "Studio_A", 51420, "SevenPointOneFour");
    auto txt = buildTxtRecord(d);
    auto back = parseTxtRecord(txt, d.name, d.host, d.audioPort);
    CHECK(back.id == d.id);
    CHECK(back.format == d.format);
    CHECK(back.sampleRate == d.sampleRate);
    CHECK(back.channels == d.channels);
    CHECK(back.codec == d.codec);
    std::cout << "[T4] TXT round-trip OK\n";
  }
  {
    bool threw = false;
    try { (void)parseTxtRecord("ver=2 id=x", "n", "h", 1); } catch (const std::invalid_argument&) { threw = true; }
    CHECK(threw);
    threw = false;
    try { (void)parseTxtRecord("ver=1", "n", "h", 1); } catch (const std::invalid_argument&) { threw = true; }
    CHECK(threw);
    std::cout << "[T5] Malformed TXT rejected OK\n";
  }
  {
    const char* formats[] = {"Mono","Stereo","LCR","Quad","FivePointOne","SevenPointOne","FivePointOneFour","SevenPointOneFour","NinePointOneSix","AmbisonicsFOA","AmbisonicsSOA","AmbisonicsHOA3"};
    for (const char* f : formats) {
      SessionDescription d; d.id="id"; d.name="n"; d.format=f; d.sampleRate=48000;
      d.channels = channelCountForFormatName(f); d.codec="f32";
      auto back = parseTxtRecord(buildTxtRecord(d), "n", "127.0.0.1", 1);
      CHECK(back.format == f); CHECK(back.channels == d.channels);
    }
    std::cout << "[T7] Format coverage OK\n";
  }
  if (!mdnsDaemonAvailable()) {
    std::cout << "[T1/T2/T3] SKIP: mDNS daemon not reachable\n";
    std::cout << "  install: sudo apt install avahi-daemon && sudo systemctl start avahi-daemon\n";
    MdnsAnnouncer a(makeDesc("x","X",1));
    bool threw = false;
    try { a.start(); } catch (const std::runtime_error& e) {
      threw = true;
      CHECK(std::string(e.what()).find("mDNS") != std::string::npos || std::string(e.what()).find("daemon") != std::string::npos);
    }
    CHECK(threw);
    std::cout << "[daemon] start() throws when unreachable OK\n";
  } else {
    std::cout << "[T1/T2/T3] daemon reachable — running live tests\n";
    auto d = makeDesc("t1-id", "T1_Studio", 51430);
    MdnsAnnouncer a(d); a.start(); CHECK(a.isRegistered());
    MdnsBrowser b; b.start(200);
    bool seen = false;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(4);
    while (std::chrono::steady_clock::now() < deadline && !seen) {
      for (const auto& r : b.poll(200)) if (r.session.id == d.id) { seen = true; break; }
    }
    CHECK(seen);
    a.stop();
    std::cout << "[T1] announce/browse/receive " << (seen?"OK":"FAIL") << "\n";
  }
  if (failures) { std::cerr << failures << " failure(s)\n"; return 1; }
  std::cout << "ALL mDNS TESTS PASSED\n";
  return 0;
}
