// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/session_handoff.hpp"
#include "hush/immersive/speakers.hpp"

#include <atomic>
#include <chrono>
#include <cmath>
#include <iostream>
#include <thread>
#include <vector>

using namespace hush::net;
using hush::immersive::ChannelFormat;
using hush::immersive::channelCount;
using hush::immersive::channelFormatName;

static int failures = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (!(c)) {                                                          \
      std::cerr << "FAIL: " #c " at line " << __LINE__ << "\n";          \
      ++failures;                                                        \
    }                                                                    \
  } while (0)

static void test_format_table_matches_immersive() {
  const ChannelFormat fmts[] = {
      ChannelFormat::Mono,          ChannelFormat::Stereo,
      ChannelFormat::LCR,           ChannelFormat::Quad,
      ChannelFormat::FivePointOne,  ChannelFormat::SevenPointOne,
      ChannelFormat::FivePointOneFour, ChannelFormat::SevenPointOneFour,
      ChannelFormat::NinePointOneSix, ChannelFormat::AmbisonicsFOA,
      ChannelFormat::AmbisonicsSOA, ChannelFormat::AmbisonicsHOA3,
  };
  for (auto f : fmts) {
    const char* name = channelFormatName(f);
    const int a = channelCountForFormatName(name);
    const int b = channelCount(f);
    if (a != b) {
      std::cerr << "FAIL: format '" << name << "' handoff says " << a
                << ", immersive says " << b << "\n";
      ++failures;
    }
  }
  std::cout << "[handoff] format table cross-check OK\n";
}

static void test_unknown_format_throws() {
  bool threw = false;
  try {
    (void)channelCountForFormatName("Atmos 9.1.99");
  } catch (const std::invalid_argument& e) {
    threw = true;
    CHECK(std::string(e.what()).find("Atmos") != std::string::npos);
  }
  CHECK(threw);
  std::cout << "[handoff] unknown format throws OK\n";
}

static void test_rejected_reply_throws() {
  NegotiationReply r;
  r.accepted = false;
  r.reason = "no common format";
  bool threwA = false, threwB = false;
  try {
    (void)makeReceiverFromReply({}, r);
  } catch (const NegotiationRejected& e) {
    threwA = true;
    CHECK(std::string(e.what()).find("no common format") != std::string::npos);
  }
  try {
    (void)makeSenderForClient({}, r, "127.0.0.1", 5000);
  } catch (const NegotiationRejected&) {
    threwB = true;
  }
  CHECK(threwA && threwB);
  std::cout << "[handoff] rejected reply throws OK\n";
}

static void test_accepted_but_missing_port_throws() {
  NegotiationReply r;
  r.accepted = true;
  r.chosenFormat = "Stereo";
  r.chosenSampleRate = 48000.0;
  r.transportPort = 0;
  bool threw = false;
  try {
    (void)makeReceiverFromReply({}, r);
  } catch (const std::runtime_error& e) {
    threw = true;
    CHECK(std::string(e.what()).find("transportPort == 0") !=
          std::string::npos);
  }
  CHECK(threw);
  std::cout << "[handoff] missing port throws OK\n";
}

static void test_return_address_roundtrip() {
  NegotiationRequest req;
  req.sessionId = "abc";
  CHECK(!returnAddressOf(req).has_value());

  ClientReturnAddress a{"192.168.1.42", 51000};
  setReturnAddress(req, a);
  auto back = returnAddressOf(req);
  CHECK(back.has_value());
  if (back) {
    CHECK(back->host == "192.168.1.42");
    CHECK(back->port == 51000);
  }

  a.port = 51001;
  setReturnAddress(req, a);
  CHECK(req.attributes.size() == 2);
  auto back2 = returnAddressOf(req);
  CHECK(back2.has_value() && back2->port == 51001);

  NegotiationRequest bad;
  bad.attributes.push_back("return-host=10.0.0.1");
  bad.attributes.push_back("return-port=notanumber");
  CHECK(!returnAddressOf(bad).has_value());

  std::cout << "[handoff] return address round-trip OK\n";
}

static void test_end_to_end_audio_flow() {
  SessionDescription desc;
  desc.id = "test-session-1";
  desc.name = "handoff e2e";
  desc.host = "127.0.0.1";
  desc.format = "Stereo";
  desc.sampleRate = 48000.0;
  desc.channels = 2;
  desc.codec = "f32";
  desc.audioPort = 51420;

  Negotiator server(desc);
  const uint16_t controlPort = server.listen("127.0.0.1");
  CHECK(controlPort != 0);

  NegotiationClient client("127.0.0.1", controlPort);
  NegotiationRequest req;
  req.sessionId = desc.id;
  req.clientName = "test-client";
  req.supportedFormats = {"Stereo"};
  req.preferredSampleRate = 48000.0;
  // Return port must match the port the client will bind for audio
  // (reply.transportPort). Server's Sender sends here; client's
  // Receiver listens here.
  setReturnAddress(req, ClientReturnAddress{"127.0.0.1", desc.audioPort});

  std::atomic<bool> clientDone{false};
  NegotiationReply clientReply;
  std::atomic<bool> clientThrew{false};
  std::thread clientThread([&] {
    try {
      clientReply = client.negotiate(req, 2500);
    } catch (...) {
      clientThrew = true;
    }
    clientDone = true;
  });

  std::optional<NegotiationRequest> got;
  const auto deadline =
      std::chrono::steady_clock::now() + std::chrono::seconds(3);
  while (!got && std::chrono::steady_clock::now() < deadline) {
    got = server.pollRequest(50);
  }
  CHECK(got.has_value());
  if (!got) {
    clientThread.join();
    return;
  }

  auto addr = returnAddressOf(*got);
  CHECK(addr.has_value());

  NegotiationReply reply;
  reply.accepted = true;
  reply.chosenFormat = "Stereo";
  reply.chosenSampleRate = 48000.0;
  reply.transportPort = desc.audioPort;

  // Reply on the control path (lastClient_). Return address is only
  // for the subsequent audio Sender, not for the negotiation reply.
  server.reply(reply, "127.0.0.1", 0);

  clientThread.join();
  CHECK(clientDone.load());
  CHECK(!clientThrew.load());
  CHECK(clientReply.accepted);
  CHECK(clientReply.transportPort == desc.audioPort);

  TransportConfig clientCfg;
  auto receiver =
      makeReceiverFromReply(clientCfg, clientReply, "127.0.0.1");
  CHECK(receiver != nullptr);

  TransportConfig serverCfg;
  auto sender =
      makeSenderForClient(serverCfg, reply, addr->host, addr->port);
  CHECK(sender != nullptr);

  constexpr int kFrames = 4800;
  constexpr float kFreq = 440.0f;
  constexpr float kPi = 3.14159265358979323846f;
  std::vector<float> in(static_cast<std::size_t>(kFrames * 2));
  for (int i = 0; i < kFrames; ++i) {
    const float s = std::sin(2.0f * kPi * kFreq *
                             static_cast<float>(i) / 48000.0f);
    in[static_cast<std::size_t>(2 * i)] = s;
    in[static_cast<std::size_t>(2 * i + 1)] = s;
  }
  sender->push(in.data(), kFrames);
  sender->flush();

  std::this_thread::sleep_for(std::chrono::milliseconds(200));

  std::vector<float> out(static_cast<std::size_t>(kFrames * 2), 0.0f);
  int received = 0;
  for (int attempt = 0; attempt < 20 && received < kFrames; ++attempt) {
    received += receiver->pull(out.data() + received * 2, kFrames - received);
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
  }

  float energy = 0.0f;
  for (float s : out) energy += s * s;
  CHECK(received > 0);
  CHECK(energy > 1e-6f);

  std::cout << "[handoff] end-to-end audio flow: received " << received
            << " frames, energy " << energy << " OK\n";
}

int main() {
  std::cout << "session handoff tests\n";
  test_format_table_matches_immersive();
  test_unknown_format_throws();
  test_rejected_reply_throws();
  test_accepted_but_missing_port_throws();
  test_return_address_roundtrip();
  test_end_to_end_audio_flow();
  if (failures) {
    std::cerr << failures << " failure(s)\n";
    return 1;
  }
  std::cout << "ALL HANDOFF TESTS PASSED\n";
  return 0;
}
