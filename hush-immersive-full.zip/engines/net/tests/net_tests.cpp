// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/net/transport.hpp"
#include "../src/pll.hpp"

#include <cmath>
#include <cstring>
#include <iostream>
#include <thread>
#include <vector>

using namespace hush::net;

static int failures = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (!(c)) {                                                          \
      std::cerr << "FAIL: " #c " at line " << __LINE__ << "\n";          \
      ++failures;                                                        \
    }                                                                    \
  } while (0)

static constexpr double kPi = 3.14159265358979323846;

// T1 Loopback no loss
static void testLoopback() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.sampleRate = 48000;
  cfg.payloadBytesPerPacket = 480;  // 120 frames
  cfg.fecBlockSize = 4;
  cfg.jitterBufferPackets = 4;

  const uint16_t port = 19001;
  Receiver rx(cfg, port);
  Sender tx(cfg, "127.0.0.1", port);

  const int nFrames = 48000;  // 1 second
  std::vector<float> in(static_cast<std::size_t>(nFrames));
  for (int i = 0; i < nFrames; ++i)
    in[static_cast<std::size_t>(i)] = static_cast<float>(
        std::sin(2.0 * kPi * 440.0 * i / 48000.0));

  // Send in chunks
  const int chunk = 480;
  for (int off = 0; off < nFrames; off += chunk) {
    int n = std::min(chunk, nFrames - off);
    tx.push(in.data() + off, n);
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(50));

  std::vector<float> out(static_cast<std::size_t>(nFrames + 1000), 0.f);
  int got = 0;
  for (int attempt = 0; attempt < 100; ++attempt) {
    int n = rx.pull(out.data() + got, nFrames - got);
    got += n;
    if (got >= nFrames * 8 / 10) break;
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }

  CHECK(got > nFrames / 10);  // jitter buffer + FEC overhead reduces yield
  // Energy present
  float energy = 0.f;
  for (int i = 0; i < got; ++i) energy += out[static_cast<std::size_t>(i)] *
                                           out[static_cast<std::size_t>(i)];
  CHECK(energy > 1.0f);
  std::cout << "[T1] Loopback OK (got " << got << " frames, energy=" << energy
            << ")\n";
}

// T2 Loss + FEC recovery
static void testFecRecovery() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.sampleRate = 48000;
  cfg.payloadBytesPerPacket = 480;
  cfg.fecBlockSize = 4;
  cfg.jitterBufferPackets = 4;

  const uint16_t port = 19002;
  Receiver rx(cfg, port);
  Sender tx(cfg, "127.0.0.1", port);
  tx.setTestLossRate(0.05);

  std::vector<float> in(4800, 0.5f);
  for (int off = 0; off < 4800; off += 120) {
    tx.push(in.data() + off, 120);
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(50));

  std::vector<float> out(6000, 0.f);
  int got = 0;
  for (int a = 0; a < 50; ++a) {
    got += rx.pull(out.data() + got, 6000 - got);
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }

  auto st = rx.stats();
  CHECK(got > 0);
  // May or may not recover depending on which packets dropped
  std::cout << "[T2] FEC recovery: got=" << got
            << " recovered=" << st.packetsRecovered
            << " received=" << st.packetsReceived << " OK\n";
}

// T4 Clock recovery (PLL unit test)
static void testClockRecovery() {
  ClockPll pll(48000.0, 0.5, 1.0);  // wider BW for fast convergence in test

  // Simulate sender 100 ppm fast
  const double trueRate = 48000.0 * 1.0001;
  double senderTime = 0.0;
  double localTime = 0.0;
  const double packetInterval = 0.01;  // 10 ms

  for (int i = 0; i < 500; ++i) {
    senderTime += packetInterval * (trueRate / 48000.0);
    localTime += packetInterval;
    pll.update(senderTime, localTime);
  }

  double est = pll.estimatedRate();
  double errPpm = (est / 48000.0 - 1.0001) * 1e6;
  std::cout << "[T4] +100ppm: est=" << est << " err=" << errPpm << " ppm\n";
  // With synthetic perfect timestamps, PLL should move toward the offset
  // PLL must move away from pure nominal
  CHECK(std::abs(est - 48000.0) > 0.01);

  // -100 ppm
  ClockPll pll2(48000.0, 0.5, 1.0);
  senderTime = 0.0;
  localTime = 0.0;
  const double trueRate2 = 48000.0 * 0.9999;
  for (int i = 0; i < 500; ++i) {
    senderTime += packetInterval * (trueRate2 / 48000.0);
    localTime += packetInterval;
    pll2.update(senderTime, localTime);
  }
  double est2 = pll2.estimatedRate();
  std::cout << "[T4] -100ppm: est=" << est2 << "\n";
  // Directional: +100ppm estimate and -100ppm estimate should differ
  CHECK(std::abs(est - est2) > 0.01);
  std::cout << "[T4] Clock recovery OK\n";
}

// T5 Jitter depth
static void testJitter() {
  TransportConfig cfg;
  cfg.channels = 1;
  cfg.jitterBufferPackets = 8;
  cfg.maxJitterPackets = 32;
  cfg.payloadBytesPerPacket = 480;

  const uint16_t port = 19003;
  Receiver rx(cfg, port);
  Sender tx(cfg, "127.0.0.1", port);

  std::vector<float> in(120, 0.25f);
  for (int i = 0; i < 40; ++i) {
    tx.push(in.data(), 120);
    // Random-ish delay
    std::this_thread::sleep_for(std::chrono::milliseconds(1 + (i % 5)));
  }
  tx.flush();
  std::this_thread::sleep_for(std::chrono::milliseconds(30));

  std::vector<float> out(5000, 0.f);
  int got = 0;
  for (int a = 0; a < 30; ++a) {
    got += rx.pull(out.data() + got, 5000 - got);
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
  int depth = rx.jitterDepth();
  std::cout << "[T5] Jitter depth=" << depth << " got=" << got << " OK\n";
  CHECK(got > 0);
}

// T7 Config sanity
static void testConfigSanity() {
  bool threw = false;
  try {
    TransportConfig cfg;
    cfg.channels = 0;
    Sender s(cfg, "127.0.0.1", 19010);
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  CHECK(threw);

  threw = false;
  try {
    TransportConfig cfg;
    cfg.fecBlockSize = 1;
    Receiver r(cfg, 19011);
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  CHECK(threw);

  threw = false;
  try {
    TransportConfig cfg;
    cfg.nackTimeoutMs = -1;
    Receiver r(cfg, 19012);
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  CHECK(threw);

  std::cout << "[T7] Config sanity OK\n";
}

int main() {
  std::cout << "Network transport tests\n";
  testConfigSanity();
  testClockRecovery();
  testLoopback();
  testFecRecovery();
  testJitter();
  if (failures) {
    std::cerr << failures << " failure(s)\n";
    return 1;
  }
  std::cout << "ALL NET TESTS PASSED\n";
  return 0;
}
