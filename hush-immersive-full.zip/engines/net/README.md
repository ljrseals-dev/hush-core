# hush-net

UDP audio transport for hush-daw: RTP-shaped packets, XOR FEC (RFC 5109 style),
NACK-ready cache, jitter buffer, and a second-order PLL for clock recovery.

## Rationale

- **RTP-shaped header** (RFC 3550): sequence, timestamp, payload length — fields
  a reviewer can map to a standard, not invented magic.
- **XOR FEC** (RFC 5109): one repair packet per block of N data packets.
  Recovers any single loss. Reed-Solomon is out of scope.
- **PLL**: second-order loop on inter-packet sender vs local time deltas.
  Estimates `sampleRate * (1 + correction)`.

## Build

```bash
cmake -S engines/net -B build-net
cmake --build build-net -j
cp build-net/hush_net_tests /tmp/ && chmod +x /tmp/hush_net_tests
/tmp/hush_net_tests
```

POSIX only (Linux/macOS). Windows is `#error`'d at compile time.

## What this transport does NOT do

- Wire-compatible RTP / RTCP interop with third-party stacks.
- Reed-Solomon or other non-XOR erasure coding.
- Encryption or authentication.
- Automatic NACK generation on the wire (cache is present; full NACK
  round-trip is partial in this build).
- Cross-platform Windows sockets.

## Session discovery and negotiation

SAP/SDP-shaped announcements on multicast `239.255.42.99:9875` (defaults).
Text SDP for discovery (auditable against RFC 8866). Binary 32-byte "HUSH"
header for the unicast negotiation handshake (request/reply).

```bash
cmake -S engines/net -B build-net
cmake --build build-net -j
cp build-net/hush_session_tests /tmp/ && chmod +x /tmp/hush_session_tests
/tmp/hush_session_tests
```

If the environment cannot join multicast, T1–T4 print a notice and skip;
T5–T9 always run.
