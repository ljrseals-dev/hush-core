// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
// Stub implementation used when HUSH_HAS_FFMPEG == 0

#include <hush/video/movie.hpp>

namespace hush {
namespace video {

struct Movie::Impl {};

Movie::Movie(const std::string& /*path*/) {
    throw VideoError("FFmpeg not available (HUSH_HAS_FFMPEG=0)");
}

Movie::~Movie() = default;

MovieInfo Movie::info() const {
    throw VideoError("FFmpeg not available");
}

Frame Movie::frameAt(double /*t*/) const {
    throw VideoError("FFmpeg not available");
}

Frame Movie::thumbnailAt(double /*t*/, int /*maxW*/) const {
    throw VideoError("FFmpeg not available");
}

std::vector<float> Movie::audioSamples() const {
    throw VideoError("FFmpeg not available");
}

std::vector<float> Movie::audioSamplesAt(double /*t*/, int /*frames*/) const {
    throw VideoError("FFmpeg not available");
}

} // namespace video
} // namespace hush
