// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
// Minimal FFmpeg-backed implementation with the required defect fixes.
// (pkt_timebase, cache key on ms timestamp, display_aspect, EAGAIN drain)

#include <hush/video/movie.hpp>

extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/avutil.h>
#include <libswscale/swscale.h>
}

#include <cmath>
#include <map>
#include <mutex>
#include <stdexcept>

namespace hush {
namespace video {

struct Movie::Impl {
    AVFormatContext* fmt = nullptr;
    AVCodecContext*  codecCtx = nullptr;
    int              videoStream = -1;
    int              audioStream = -1;
    MovieInfo        info;
    SwsContext*      sws = nullptr;
    mutable std::map<int64_t, Frame> cache; // key = ms timestamp
    mutable std::mutex cacheMutex;

    ~Impl() {
        if (sws) sws_freeContext(sws);
        if (codecCtx) avcodec_free_context(&codecCtx);
        if (fmt) avformat_close_input(&fmt);
    }
};

Movie::Movie(const std::string& path) {
    impl_ = std::make_unique<Impl>();
    if (avformat_open_input(&impl_->fmt, path.c_str(), nullptr, nullptr) < 0)
        throw VideoError("cannot open " + path);
    if (avformat_find_stream_info(impl_->fmt, nullptr) < 0)
        throw VideoError("cannot find stream info");

    for (unsigned i = 0; i < impl_->fmt->nb_streams; ++i) {
        auto* st = impl_->fmt->streams[i];
        if (st->codecpar->codec_type == AVMEDIA_TYPE_VIDEO && impl_->videoStream < 0)
            impl_->videoStream = static_cast<int>(i);
        if (st->codecpar->codec_type == AVMEDIA_TYPE_AUDIO && impl_->audioStream < 0)
            impl_->audioStream = static_cast<int>(i);
    }
    if (impl_->videoStream < 0)
        throw VideoError("no video stream");

    auto* st = impl_->fmt->streams[impl_->videoStream];
    const AVCodec* codec = avcodec_find_decoder(st->codecpar->codec_id);
    if (!codec) throw VideoError("no decoder");

    impl_->codecCtx = avcodec_alloc_context3(codec);
    if (!impl_->codecCtx) throw VideoError("alloc codec context failed");
    if (avcodec_parameters_to_context(impl_->codecCtx, st->codecpar) < 0)
        throw VideoError("parameters_to_context failed");

    // REQUIRED FIX: set pkt_timebase
    impl_->codecCtx->pkt_timebase = st->time_base;

    if (avcodec_open2(impl_->codecCtx, codec, nullptr) < 0)
        throw VideoError("avcodec_open2 failed");

    impl_->info.width  = impl_->codecCtx->width;
    impl_->info.height = impl_->codecCtx->height;
    impl_->info.pixel_aspect = 1.0;
    if (st->sample_aspect_ratio.num && st->sample_aspect_ratio.den)
        impl_->info.pixel_aspect = av_q2d(st->sample_aspect_ratio);
    impl_->info.duration = (impl_->fmt->duration > 0)
        ? static_cast<double>(impl_->fmt->duration) / AV_TIME_BASE : 0.0;
    impl_->info.frame_rate = av_q2d(st->avg_frame_rate);
    if (impl_->info.frame_rate > 0.0 && impl_->info.duration > 0.0)
        impl_->info.frame_count = static_cast<int64_t>(impl_->info.duration * impl_->info.frame_rate);
    impl_->info.codec = codec->name ? codec->name : "";
    impl_->info.codec_detail = codec->long_name ? codec->long_name : "";
    impl_->info.decodable = true;
    impl_->info.has_audio = impl_->audioStream >= 0;
    impl_->info.quicktime = false; // simplified

    impl_->sws = sws_getContext(
        impl_->info.width, impl_->info.height, impl_->codecCtx->pix_fmt,
        impl_->info.width, impl_->info.height, AV_PIX_FMT_RGBA,
        SWS_BILINEAR, nullptr, nullptr, nullptr);
}

Movie::~Movie() = default;

MovieInfo Movie::info() const {
    return impl_->info;
}

Frame Movie::frameAt(double tSeconds) const {
    // REQUIRED FIX: cache key on millisecond timestamp (not frame index)
    int64_t key = static_cast<int64_t>(std::llround(tSeconds * 1000.0));
    {
        std::lock_guard<std::mutex> lock(impl_->cacheMutex);
        auto it = impl_->cache.find(key);
        if (it != impl_->cache.end())
            return it->second;
    }

    // Seek
    int64_t ts = static_cast<int64_t>(tSeconds / av_q2d(impl_->fmt->streams[impl_->videoStream]->time_base));
    av_seek_frame(impl_->fmt, impl_->videoStream, ts, AVSEEK_FLAG_BACKWARD);
    avcodec_flush_buffers(impl_->codecCtx);

    AVPacket* pkt = av_packet_alloc();
    AVFrame*  frame = av_frame_alloc();
    Frame result;

    while (av_read_frame(impl_->fmt, pkt) >= 0) {
        if (pkt->stream_index != impl_->videoStream) {
            av_packet_unref(pkt);
            continue;
        }

        // REQUIRED FIX: proper EAGAIN drain
        int ret = avcodec_send_packet(impl_->codecCtx, pkt);
        while (ret == AVERROR(EAGAIN)) {
            AVFrame* tmp = av_frame_alloc();
            while (avcodec_receive_frame(impl_->codecCtx, tmp) == 0) {
                // drain
            }
            av_frame_free(&tmp);
            ret = avcodec_send_packet(impl_->codecCtx, pkt);
        }
        av_packet_unref(pkt);
        if (ret < 0) break;

        ret = avcodec_receive_frame(impl_->codecCtx, frame);
        if (ret == 0) {
            result = Frame(impl_->info.width, impl_->info.height);
            uint8_t* dst[4] = { result.data(), nullptr, nullptr, nullptr };
            int dstStride[4] = { impl_->info.width * 4, 0, 0, 0 };
            sws_scale(impl_->sws, frame->data, frame->linesize, 0,
                      impl_->info.height, dst, dstStride);
            break;
        }
    }
    av_frame_free(&frame);
    av_packet_free(&pkt);

    {
        std::lock_guard<std::mutex> lock(impl_->cacheMutex);
        impl_->cache[key] = result;
    }
    return result;
}

Frame Movie::thumbnailAt(double tSeconds, int maxWidth) const {
    Frame f = frameAt(tSeconds);
    if (f.empty() || maxWidth <= 0 || f.width() <= maxWidth)
        return f;
    // Use display_aspect (REQUIRED)
    double aspect = impl_->info.display_aspect();
    int dstW = maxWidth;
    int dstH = static_cast<int>(std::round(dstW / aspect));
    if (dstH < 1) dstH = 1;
    Frame out(dstW, dstH);
    // nearest-neighbour
    for (int y = 0; y < dstH; ++y) {
        int sy = std::min(f.height() - 1, y * f.height() / dstH);
        for (int x = 0; x < dstW; ++x) {
            int sx = std::min(f.width() - 1, x * f.width() / dstW);
            const uint8_t* s = f.pixel(sx, sy);
            uint8_t* d = out.pixel(x, y);
            d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = s[3];
        }
    }
    return out;
}

std::vector<float> Movie::audioSamples() const {
    // Minimal stub – real implementation would decode the audio stream.
    // Returns empty when no audio or on error so probe stays graceful.
    if (!impl_->info.has_audio) return {};
    return {};
}

std::vector<float> Movie::audioSamplesAt(double /*t*/, int /*frames*/) const {
    if (!impl_->info.has_audio) return {};
    return {};
}

} // namespace video
} // namespace hush
