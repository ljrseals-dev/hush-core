// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <memory>

namespace hush {
namespace video {

struct VideoError : public std::runtime_error {
    explicit VideoError(const std::string& m) : std::runtime_error(m) {}
};

struct MovieInfo {
    int width = 0;
    int height = 0;
    double pixel_aspect = 1.0;
    double duration = 0.0;
    double frame_rate = 0.0;
    int64_t frame_count = 0;
    std::string codec;
    std::string codec_detail;
    bool decodable = false;
    bool has_audio = false;
    bool quicktime = false;

    double display_aspect() const {
        if (height <= 0) return 1.0;
        return (static_cast<double>(width) / height) * pixel_aspect;
    }
};

class Frame {
public:
    Frame() = default;
    Frame(int w, int h) : width_(w), height_(h), data_(static_cast<size_t>(w) * h * 4, 0) {}

    bool empty() const { return width_ <= 0 || height_ <= 0 || data_.empty(); }
    int width() const { return width_; }
    int height() const { return height_; }
    const uint8_t* data() const { return data_.data(); }
    uint8_t* data() { return data_.data(); }
    const uint8_t* pixel(int x, int y) const {
        return data_.data() + (static_cast<size_t>(y) * width_ + x) * 4;
    }
    uint8_t* pixel(int x, int y) {
        return data_.data() + (static_cast<size_t>(y) * width_ + x) * 4;
    }

private:
    int width_ = 0;
    int height_ = 0;
    std::vector<uint8_t> data_;
};

class Movie {
public:
    explicit Movie(const std::string& path);
    ~Movie();

    MovieInfo info() const;
    Frame frameAt(double tSeconds) const;
    Frame thumbnailAt(double tSeconds, int maxWidth) const;

    // Audio helpers used by probe
    std::vector<float> audioSamples() const;
    std::vector<float> audioSamplesAt(double tSeconds, int frames) const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace video
} // namespace hush
