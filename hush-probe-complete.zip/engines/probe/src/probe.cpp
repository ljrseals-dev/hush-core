// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include <hush/probe/probe.hpp>
#include "png_writer.hpp"
#include "gif_writer.hpp"
#include "waveform.hpp"
#include "colour.hpp"

#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <sys/stat.h>
#include <cerrno>
#include <cstring>
#include <cstdio>

namespace hush {
namespace probe {
namespace {

bool ensureDir(const std::string& path) {
    struct stat st;
    if (stat(path.c_str(), &st) == 0)
        return S_ISDIR(st.st_mode);
#if defined(_WIN32)
    return _mkdir(path.c_str()) == 0;
#else
    return mkdir(path.c_str(), 0755) == 0 || errno == EEXIST;
#endif
}

std::string escapeJson(const std::string& s) {
    std::ostringstream o;
    for (char c : s) {
        switch (c) {
            case '"':  o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\n': o << "\\n";  break;
            case '\r': o << "\\r";  break;
            case '\t': o << "\\t";  break;
            default:
                if (static_cast<unsigned char>(c) < 0x20)
                    o << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                      << static_cast<int>(static_cast<unsigned char>(c));
                else
                    o << c;
        }
    }
    return o.str();
}

std::vector<uint8_t> scaleFrame(const video::Frame& frame, int maxWidth, double aspect,
                                int& outW, int& outH) {
    int srcW = frame.width();
    int srcH = frame.height();
    outW = srcW;
    outH = srcH;
    if (outW > maxWidth) {
        outW = maxWidth;
        outH = static_cast<int>(std::round(static_cast<double>(outW) / aspect));
        if (outH < 1) outH = 1;
    }
    std::vector<uint8_t> rgba(static_cast<size_t>(outW) * static_cast<size_t>(outH) * 4);
    for (int y = 0; y < outH; ++y) {
        int sy = std::min(srcH - 1,
            static_cast<int>(static_cast<double>(y) * srcH / outH));
        for (int x = 0; x < outW; ++x) {
            int sx = std::min(srcW - 1,
                static_cast<int>(static_cast<double>(x) * srcW / outW));
            const uint8_t* src = frame.pixel(sx, sy);
            uint8_t* dst = &rgba[(static_cast<size_t>(y) * outW + x) * 4];
            dst[0] = src[0];
            dst[1] = src[1];
            dst[2] = src[2];
            dst[3] = src[3];
        }
    }
    return rgba;
}

} // namespace

std::string movieInfoToJson(const video::MovieInfo& info) {
    std::ostringstream o;
    o << std::fixed << std::setprecision(6);
    o << "{"
      << "\"width\":" << info.width << ","
      << "\"height\":" << info.height << ","
      << "\"pixelAspect\":" << info.pixel_aspect << ","
      << "\"duration\":" << info.duration << ","
      << "\"frameRate\":" << info.frame_rate << ","
      << "\"frameCount\":" << info.frame_count << ","
      << "\"codec\":\"" << escapeJson(info.codec) << "\","
      << "\"codecDetail\":\"" << escapeJson(info.codec_detail) << "\","
      << "\"decodable\":" << (info.decodable ? "true" : "false") << ","
      << "\"hasAudio\":" << (info.has_audio ? "true" : "false") << ","
      << "\"quicktime\":" << (info.quicktime ? "true" : "false") << ","
      << "\"displayAspect\":" << info.display_aspect()
      << "}";
    return o.str();
}

void extractThumbnails(const std::string& videoPath, int count,
                       const std::string& outDir, int maxWidth) {
    if (count <= 0) throw ProbeError("thumbs count must be positive");
    if (maxWidth <= 0) throw ProbeError("max-width must be positive");
    if (!ensureDir(outDir)) throw ProbeError("cannot create " + outDir);

    video::Movie movie(videoPath);
    const auto& info = movie.info();
    if (!info.decodable) throw ProbeError("video is not decodable");

    double duration = info.duration > 0.0 ? info.duration : 1.0;
    double aspect = info.display_aspect();
    if (aspect <= 0.0)
        aspect = static_cast<double>(info.width) / std::max(1, info.height);

    for (int i = 0; i < count; ++i) {
        double t = (count == 1) ? 0.0
                 : duration * static_cast<double>(i) / static_cast<double>(count - 1);
        if (t >= duration) t = std::max(0.0, duration - 0.001);
        video::Frame frame = movie.frameAt(t);
        if (frame.empty())
            throw ProbeError("decode failed at t=" + std::to_string(t));
        int dstW = 0, dstH = 0;
        auto rgba = scaleFrame(frame, maxWidth, aspect, dstW, dstH);
        char name[64];
        std::snprintf(name, sizeof(name), "thumb_%03d.png", i);
        writePngRgba8(outDir + "/" + name, dstW, dstH, rgba);
    }
}

void extractAnimated(const std::string& videoPath, int count,
                     const std::string& outPath, int maxWidth, int delayCs) {
    if (count <= 0) throw ProbeError("frame count must be positive");
    video::Movie movie(videoPath);
    const auto& info = movie.info();
    if (!info.decodable) throw ProbeError("video is not decodable");

    double duration = info.duration > 0.0 ? info.duration : 1.0;
    double aspect = info.display_aspect();
    if (aspect <= 0.0)
        aspect = static_cast<double>(info.width) / std::max(1, info.height);

    std::vector<std::vector<uint8_t>> frames;
    int dstW = 0, dstH = 0;
    for (int i = 0; i < count; ++i) {
        double t = (count == 1) ? 0.0
                 : duration * static_cast<double>(i) / static_cast<double>(count - 1);
        video::Frame frame = movie.frameAt(t);
        if (frame.empty()) throw ProbeError("decode failed");
        int w = 0, h = 0;
        auto rgba = scaleFrame(frame, maxWidth, aspect, w, h);
        if (i == 0) { dstW = w; dstH = h; }
        frames.push_back(std::move(rgba));
    }
    writeAnimatedGif(outPath, dstW, dstH, frames, delayCs);
}

video::Frame scrub(const std::string& videoPath, double tSeconds) {
    video::Movie movie(videoPath);
    return movie.frameAt(tSeconds);
}

ProbeResult probe(const std::string& videoPath,
                  const std::string& jsonPath,
                  int thumbs,
                  const std::string& outDir,
                  int maxWidth,
                  bool wantAnimated,
                  const std::string& animatedPath,
                  bool wantWaveform,
                  int waveformBins,
                  bool wantSpectrogram) {
    ProbeResult result;
    video::Movie movie(videoPath);
    result.info = movie.info();

    if (!jsonPath.empty()) {
        std::ofstream ofs(jsonPath);
        if (!ofs) throw ProbeError("cannot write JSON: " + jsonPath);
        ofs << movieInfoToJson(result.info);
        if (!ofs) throw ProbeError("write failed for JSON: " + jsonPath);
    }

    if (thumbs > 0) {
        extractThumbnails(videoPath, thumbs, outDir, maxWidth);
        for (int i = 0; i < thumbs; ++i) {
            char name[64];
            std::snprintf(name, sizeof(name), "thumb_%03d.png", i);
            result.thumbnailPaths.push_back(outDir + "/" + name);
        }
    }

    if (wantAnimated && !animatedPath.empty()) {
        extractAnimated(videoPath, std::max(thumbs, 8), animatedPath, maxWidth, 10);
        result.animatedPath = animatedPath;
    }

    if (wantWaveform)
        result.waveform = extractWaveform(videoPath, waveformBins);

    if (wantSpectrogram)
        result.spectrogram = extractSpectrogram(videoPath);

    return result;
}

} // namespace probe
} // namespace hush
