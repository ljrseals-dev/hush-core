// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "png_writer.hpp"

#include <fstream>
#include <stdexcept>
#include <cstring>
#include <vector>
#include <cstdint>

namespace hush {
namespace probe {
namespace {

uint32_t crc32(const uint8_t* data, size_t len) {
    static uint32_t table[256];
    static bool init = false;
    if (!init) {
        for (uint32_t i = 0; i < 256; ++i) {
            uint32_t c = i;
            for (int k = 0; k < 8; ++k)
                c = (c & 1) ? (0xedb88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        init = true;
    }
    uint32_t c = 0xffffffffu;
    for (size_t i = 0; i < len; ++i)
        c = table[(c ^ data[i]) & 0xff] ^ (c >> 8);
    return c ^ 0xffffffffu;
}

void writeBe32(std::ostream& os, uint32_t v) {
    char b[4] = {
        static_cast<char>((v >> 24) & 0xff),
        static_cast<char>((v >> 16) & 0xff),
        static_cast<char>((v >>  8) & 0xff),
        static_cast<char>((v      ) & 0xff)
    };
    os.write(b, 4);
}

void writeChunk(std::ostream& os, const char* type, const uint8_t* data, size_t len) {
    writeBe32(os, static_cast<uint32_t>(len));
    os.write(type, 4);
    if (len)
        os.write(reinterpret_cast<const char*>(data), static_cast<std::streamsize>(len));
    std::vector<uint8_t> crcBuf(4 + len);
    std::memcpy(crcBuf.data(), type, 4);
    if (len)
        std::memcpy(crcBuf.data() + 4, data, len);
    writeBe32(os, crc32(crcBuf.data(), crcBuf.size()));
}

} // namespace

void writePngRgba8(const std::string& path,
                   int width,
                   int height,
                   const std::vector<uint8_t>& rgba) {
    if (width <= 0 || height <= 0)
        throw std::runtime_error("png: invalid dimensions");
    if (rgba.size() != static_cast<size_t>(width) * height * 4)
        throw std::runtime_error("png: rgba size mismatch");

    std::ofstream os(path, std::ios::binary);
    if (!os)
        throw std::runtime_error("png: cannot open " + path);

    const uint8_t sig[] = {137, 80, 78, 71, 13, 10, 26, 10};
    os.write(reinterpret_cast<const char*>(sig), 8);

    uint8_t ihdr[13];
    ihdr[0] = (width  >> 24) & 0xff; ihdr[1] = (width  >> 16) & 0xff;
    ihdr[2] = (width  >>  8) & 0xff; ihdr[3] = (width       ) & 0xff;
    ihdr[4] = (height >> 24) & 0xff; ihdr[5] = (height >> 16) & 0xff;
    ihdr[6] = (height >>  8) & 0xff; ihdr[7] = (height      ) & 0xff;
    ihdr[8]  = 8;   // bit depth
    ihdr[9]  = 6;   // RGBA
    ihdr[10] = 0;   // compression
    ihdr[11] = 0;   // filter
    ihdr[12] = 0;   // interlace
    writeChunk(os, "IHDR", ihdr, 13);

    const size_t rowBytes = static_cast<size_t>(width) * 4;
    const size_t rawLen   = (1 + rowBytes) * height;
    std::vector<uint8_t> raw(rawLen);
    for (int y = 0; y < height; ++y) {
        raw[y * (1 + rowBytes)] = 0; // filter None
        std::memcpy(&raw[y * (1 + rowBytes) + 1],
                    &rgba[y * rowBytes],
                    rowBytes);
    }

    std::vector<uint8_t> zlib;
    zlib.push_back(0x78); // CMF
    zlib.push_back(0x01); // FLG

    size_t offset = 0;
    while (offset < raw.size()) {
        size_t chunk = std::min(raw.size() - offset, size_t(65535));
        bool last = (offset + chunk) == raw.size();
        zlib.push_back(last ? 0x01 : 0x00);
        zlib.push_back(static_cast<uint8_t>(chunk & 0xff));
        zlib.push_back(static_cast<uint8_t>((chunk >> 8) & 0xff));
        uint16_t nlen = static_cast<uint16_t>(~chunk);
        zlib.push_back(static_cast<uint8_t>(nlen & 0xff));
        zlib.push_back(static_cast<uint8_t>((nlen >> 8) & 0xff));
        zlib.insert(zlib.end(), raw.begin() + offset, raw.begin() + offset + chunk);
        offset += chunk;
    }

    uint32_t a = 1, b = 0;
    for (uint8_t v : raw) {
        a = (a + v) % 65521;
        b = (b + a) % 65521;
    }
    uint32_t adler = (b << 16) | a;
    zlib.push_back((adler >> 24) & 0xff);
    zlib.push_back((adler >> 16) & 0xff);
    zlib.push_back((adler >>  8) & 0xff);
    zlib.push_back((adler      ) & 0xff);

    writeChunk(os, "IDAT", zlib.data(), zlib.size());
    writeChunk(os, "IEND", nullptr, 0);

    if (!os)
        throw std::runtime_error("png: write failed for " + path);
}

} // namespace probe
} // namespace hush
