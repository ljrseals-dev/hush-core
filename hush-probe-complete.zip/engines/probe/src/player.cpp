// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "player.hpp"

#include <chrono>
#include <vector>
#include <algorithm>

namespace hush {
namespace probe {

RealtimePlayer::Impl::Impl(const std::string& p) : path_(p) {
    movie_ = std::make_unique<video::Movie>(p);
}

RealtimePlayer::Impl::~Impl() {
    stop();
}

void RealtimePlayer::Impl::stop() {
    running_ = false;
    if (thread_.joinable())
        thread_.join();
}

void RealtimePlayer::Impl::run() {
    running_ = true;
    const auto& info = movie_->info();
    const double duration = info.duration > 0.0 ? info.duration : 1.0;
    const int channels = info.has_audio ? 2 : 0;
    const int sampleRate = 48000;
    const int block = 1024;

    double t = 0.0;
    std::vector<float> silence(static_cast<size_t>(block * std::max(1, channels)), 0.f);

    while (running_ && t < duration) {
        if (videoCb_) {
            auto f = movie_->frameAt(t);
            if (!f.empty())
                videoCb_(f);
        }
        if (audioCb_ && channels > 0) {
            auto samples = movie_->audioSamplesAt(t, block);
            if (!samples.empty())
                audioCb_(samples.data(), block, channels);
            else
                audioCb_(silence.data(), block, channels);
        }
        t += static_cast<double>(block) / static_cast<double>(sampleRate);
        std::this_thread::sleep_for(
            std::chrono::milliseconds(block * 1000 / sampleRate));
    }
    running_ = false;
}

RealtimePlayer::RealtimePlayer(const std::string& path)
    : impl_(std::make_unique<Impl>(path)) {}

RealtimePlayer::~RealtimePlayer() = default;

void RealtimePlayer::setAudioCallback(AudioCb cb) {
    impl_->audioCb_ = std::move(cb);
}

void RealtimePlayer::setVideoCallback(VideoCb cb) {
    impl_->videoCb_ = std::move(cb);
}

void RealtimePlayer::play() {
    if (impl_->running_)
        return;
    impl_->thread_ = std::thread([this] { impl_->run(); });
    if (impl_->thread_.joinable())
        impl_->thread_.join(); // blocking
}

void RealtimePlayer::stop() {
    impl_->stop();
}

bool RealtimePlayer::isPlaying() const {
    return impl_->running_;
}

} // namespace probe
} // namespace hush
