// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "waveform.hpp"

#include <hush/video/movie.hpp>
#include <cmath>
#include <algorithm>
#include <complex>
#include <vector>

namespace hush {
namespace probe {
namespace {

void fft(std::vector<std::complex<float>>& a) {
    const size_t n = a.size();
    if (n <= 1) return;
    std::vector<std::complex<float>> even(n / 2), odd(n / 2);
    for (size_t i = 0; i < n / 2; ++i) {
        even[i] = a[i * 2];
        odd[i]  = a[i * 2 + 1];
    }
    fft(even);
    fft(odd);
    for (size_t k = 0; k < n / 2; ++k) {
        auto t = std::polar(1.0f, -2.0f * 3.14159265f * static_cast<float>(k) / static_cast<float>(n)) * odd[k];
        a[k]       = even[k] + t;
        a[k + n/2] = even[k] - t;
    }
}

} // namespace

std::vector<float> extractWaveform(const std::string& path, int numBins) {
    if (numBins <= 0) return {};
    try {
        video::Movie movie(path);
        if (!movie.info().has_audio) return {};
        auto samples = movie.audioSamples();
        if (samples.empty()) return {};

        std::vector<float> bins(static_cast<size_t>(numBins), 0.f);
        const size_t per = samples.size() / static_cast<size_t>(numBins);
        if (per == 0) return bins;
        for (int b = 0; b < numBins; ++b) {
            size_t s = static_cast<size_t>(b) * per;
            size_t e = (b == numBins - 1) ? samples.size() : s + per;
            float peak = 0.f, sum = 0.f;
            for (size_t i = s; i < e; ++i) {
                float a = std::fabs(samples[i]);
                peak = std::max(peak, a);
                sum += a * a;
            }
            bins[static_cast<size_t>(b)] = 0.6f * peak + 0.4f * std::sqrt(sum / static_cast<float>(e - s));
        }
        float mx = *std::max_element(bins.begin(), bins.end());
        if (mx > 1e-9f)
            for (float& v : bins) v /= mx;
        return bins;
    } catch (...) {
        return {};
    }
}

std::vector<std::vector<float>> extractSpectrogram(const std::string& path,
                                                   int fftSize, int hop) {
    if (fftSize < 16 || (fftSize & (fftSize - 1)) || hop <= 0) return {};
    try {
        video::Movie movie(path);
        if (!movie.info().has_audio) return {};
        auto samples = movie.audioSamples();
        if (samples.size() < static_cast<size_t>(fftSize)) return {};

        std::vector<std::vector<float>> spec;
        for (size_t pos = 0; pos + static_cast<size_t>(fftSize) <= samples.size(); pos += static_cast<size_t>(hop)) {
            std::vector<std::complex<float>> buf(static_cast<size_t>(fftSize));
            for (int i = 0; i < fftSize; ++i) {
                float w = 0.5f - 0.5f * std::cos(2.f * 3.14159265f * static_cast<float>(i) / static_cast<float>(fftSize - 1));
                buf[static_cast<size_t>(i)] = samples[pos + static_cast<size_t>(i)] * w;
            }
            fft(buf);
            std::vector<float> mag(static_cast<size_t>(fftSize / 2));
            for (int i = 0; i < fftSize / 2; ++i)
                mag[static_cast<size_t>(i)] = std::abs(buf[static_cast<size_t>(i)]);
            float mx = *std::max_element(mag.begin(), mag.end());
            if (mx > 1e-12f)
                for (float& v : mag) v = std::log10(1.f + v / mx);
            spec.push_back(std::move(mag));
        }
        return spec;
    } catch (...) {
        return {};
    }
}

} // namespace probe
} // namespace hush
