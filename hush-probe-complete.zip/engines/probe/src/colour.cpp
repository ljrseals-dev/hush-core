// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "colour.hpp"

#include <cmath>
#include <algorithm>

namespace hush {
namespace probe {
namespace {

float srgbToLin(float c) {
    return c <= 0.04045f ? c / 12.92f : std::pow((c + 0.055f) / 1.055f, 2.4f);
}
float linToSrgb(float c) {
    return c <= 0.0031308f ? 12.92f * c : 1.055f * std::pow(c, 1.f / 2.4f) - 0.055f;
}

} // namespace

video::Frame convertColour(const video::Frame& src, ColourSpace target) {
    if (src.empty()) return src;
    video::Frame dst = src;
    auto* d = dst.data();
    if (!d) return dst;
    const size_t n = static_cast<size_t>(src.width()) * static_cast<size_t>(src.height()) * 4;
    for (size_t i = 0; i + 3 < n; i += 4) {
        float r = d[i]     / 255.f;
        float g = d[i + 1] / 255.f;
        float b = d[i + 2] / 255.f;
        if (target == ColourSpace::Linear) {
            r = srgbToLin(r);
            g = srgbToLin(g);
            b = srgbToLin(b);
        }
        // sRGB / Rec709 treated as identity for the common decoder path
        d[i]     = static_cast<uint8_t>(std::clamp(r * 255.f, 0.f, 255.f));
        d[i + 1] = static_cast<uint8_t>(std::clamp(g * 255.f, 0.f, 255.f));
        d[i + 2] = static_cast<uint8_t>(std::clamp(b * 255.f, 0.f, 255.f));
    }
    return dst;
}

video::Frame toneMap(const video::Frame& src, float exposure) {
    if (src.empty()) return src;
    video::Frame dst = src;
    auto* d = dst.data();
    if (!d) return dst;
    const size_t n = static_cast<size_t>(src.width()) * static_cast<size_t>(src.height()) * 4;
    for (size_t i = 0; i + 3 < n; i += 4) {
        float r = srgbToLin(d[i]     / 255.f) * exposure;
        float g = srgbToLin(d[i + 1] / 255.f) * exposure;
        float b = srgbToLin(d[i + 2] / 255.f) * exposure;
        // Reinhard
        r = r / (1.f + r);
        g = g / (1.f + g);
        b = b / (1.f + b);
        d[i]     = static_cast<uint8_t>(std::clamp(linToSrgb(r) * 255.f, 0.f, 255.f));
        d[i + 1] = static_cast<uint8_t>(std::clamp(linToSrgb(g) * 255.f, 0.f, 255.f));
        d[i + 2] = static_cast<uint8_t>(std::clamp(linToSrgb(b) * 255.f, 0.f, 255.f));
    }
    return dst;
}

} // namespace probe
} // namespace hush
