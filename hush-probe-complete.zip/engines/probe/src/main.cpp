// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include <hush/probe/probe.hpp>

#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>

namespace {

void printHelp(const char* argv0) {
    std::cout
        << "hush-probe — video probe, thumbnails, scrubbing, waveform, spectrogram\n"
        << "Usage:\n"
        << "  " << argv0 << " <in> [options]\n"
        << "  " << argv0 << " --help\n\n"
        << "Options:\n"
        << "  --json <path>        Write MovieInfo JSON\n"
        << "  --thumbs <N>         N still PNG thumbnails\n"
        << "  --out <dir>          Thumbnail directory (default ./thumbs)\n"
        << "  --max-width <px>     Max thumbnail width (default 160)\n"
        << "  --gif <path>         Also write animated GIF of the thumbs\n"
        << "  --waveform           Extract peak/RMS waveform envelope\n"
        << "  --spectrogram        Extract simple FFT spectrogram\n"
        << "  --scrub <seconds>    Decode and print frame size at time t\n"
        << "  --hwaccel            Request hardware decode if available\n";
}

} // namespace

int main(int argc, char** argv) {
    if (argc < 2) {
        printHelp(argv[0]);
        return 0;
    }
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--help") == 0 || std::strcmp(argv[i], "-h") == 0) {
            printHelp(argv[0]);
            return 0;
        }
    }

    std::string videoPath;
    std::string jsonPath;
    std::string outDir = "./thumbs";
    std::string gifPath;
    int thumbs = 0;
    int maxWidth = 160;
    bool wantWave = false;
    bool wantSpec = false;
    bool wantHw = false;
    double scrubT = -1.0;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--json" && i + 1 < argc) {
            jsonPath = argv[++i];
        } else if (a == "--thumbs" && i + 1 < argc) {
            thumbs = std::atoi(argv[++i]);
        } else if (a == "--out" && i + 1 < argc) {
            outDir = argv[++i];
        } else if (a == "--max-width" && i + 1 < argc) {
            maxWidth = std::atoi(argv[++i]);
        } else if (a == "--gif" && i + 1 < argc) {
            gifPath = argv[++i];
        } else if (a == "--waveform") {
            wantWave = true;
        } else if (a == "--spectrogram") {
            wantSpec = true;
        } else if (a == "--scrub" && i + 1 < argc) {
            scrubT = std::atof(argv[++i]);
        } else if (a == "--hwaccel") {
            wantHw = true;
        } else if (a[0] != '-') {
            if (videoPath.empty())
                videoPath = a;
            else {
                std::cerr << "unexpected argument: " << a << "\n";
                return 1;
            }
        } else {
            std::cerr << "unknown option: " << a << "\n";
            return 1;
        }
    }

    if (videoPath.empty()) {
        std::cerr << "missing input video path\n";
        return 1;
    }

    try {
        if (scrubT >= 0.0) {
            auto f = hush::probe::scrub(videoPath, scrubT);
            std::cout << "scrub t=" << scrubT
                      << " -> " << f.width() << "x" << f.height() << "\n";
            return 0;
        }

        auto result = hush::probe::probe(
            videoPath, jsonPath, thumbs, outDir, maxWidth,
            !gifPath.empty(), gifPath, wantWave, 512, wantSpec);

        if (jsonPath.empty() && thumbs == 0 && gifPath.empty() && !wantWave && !wantSpec)
            std::cout << hush::probe::movieInfoToJson(result.info) << "\n";

        if (wantWave)
            std::cout << "waveform bins: " << result.waveform.size() << "\n";
        if (wantSpec)
            std::cout << "spectrogram frames: " << result.spectrogram.size() << "\n";

        (void)wantHw; // forwarded to video engine when present
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "hush-probe: " << e.what() << "\n";
        return 1;
    }
}
