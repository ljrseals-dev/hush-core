// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "gif_writer.hpp"

#include <fstream>
#include <stdexcept>
#include <algorithm>
#include <vector>
#include <cstring>
#include <cmath>

namespace hush {
namespace probe {
namespace {

struct Palette {
    std::vector<uint8_t> data; // 256*3
    int size = 0;
};

Palette buildGlobalPalette(const std::vector<std::vector<uint8_t>>& frames) {
    const int bins = 32;
    std::vector<int> hist(bins * bins * bins, 0);
    for (const auto& fr : frames) {
        for (size_t i = 0; i + 3 < fr.size(); i += 4) {
            int r = fr[i]   >> 3;
            int g = fr[i+1] >> 3;
            int b = fr[i+2] >> 3;
            hist[(r * bins + g) * bins + b]++;
        }
    }
    std::vector<std::pair<int,int>> sorted;
    for (int i = 0; i < static_cast<int>(hist.size()); ++i)
        if (hist[i]) sorted.emplace_back(hist[i], i);
    std::sort(sorted.rbegin(), sorted.rend());

    Palette p;
    p.data.assign(256 * 3, 0);
    p.size = std::min(256, static_cast<int>(sorted.size()));
    for (int i = 0; i < p.size; ++i) {
        int idx = sorted[i].second;
        int r = (idx / (bins * bins)) << 3;
        int g = ((idx / bins) % bins) << 3;
        int b = (idx % bins) << 3;
        p.data[i*3+0] = static_cast<uint8_t>(r);
        p.data[i*3+1] = static_cast<uint8_t>(g);
        p.data[i*3+2] = static_cast<uint8_t>(b);
    }
    return p;
}

std::vector<uint8_t> indexFrame(const std::vector<uint8_t>& rgba, int w, int h,
                                const Palette& pal) {
    std::vector<uint8_t> indexed(static_cast<size_t>(w) * h);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            size_t off = (y * w + x) * 4;
            int best = 0, bestD = 1 << 30;
            for (int p = 0; p < pal.size; ++p) {
                int dr = int(rgba[off])   - pal.data[p*3+0];
                int dg = int(rgba[off+1]) - pal.data[p*3+1];
                int db = int(rgba[off+2]) - pal.data[p*3+2];
                int d = dr*dr + dg*dg + db*db;
                if (d < bestD) { bestD = d; best = p; }
            }
            indexed[y * w + x] = static_cast<uint8_t>(best);
        }
    }
    return indexed;
}

std::vector<uint8_t> lzwEncode(const std::vector<uint8_t>& indexed) {
    const int clear = 256, end = 257;
    std::vector<uint8_t> out;
    out.push_back(8); // min code size
    std::vector<uint8_t> block;
    block.push_back(static_cast<uint8_t>(clear & 0xff));
    for (uint8_t v : indexed) {
        block.push_back(v);
        if (block.size() >= 250) {
            out.push_back(static_cast<uint8_t>(block.size()));
            out.insert(out.end(), block.begin(), block.end());
            block.clear();
            block.push_back(static_cast<uint8_t>(clear & 0xff));
        }
    }
    block.push_back(static_cast<uint8_t>(end & 0xff));
    out.push_back(static_cast<uint8_t>(block.size()));
    out.insert(out.end(), block.begin(), block.end());
    out.push_back(0); // terminator
    return out;
}

} // namespace

void writeAnimatedGif(const std::string& path, int width, int height,
                      const std::vector<std::vector<uint8_t>>& framesRgba,
                      int delayCs) {
    if (framesRgba.empty() || width <= 0 || height <= 0)
        throw std::runtime_error("gif: invalid arguments");

    auto pal = buildGlobalPalette(framesRgba);

    std::ofstream os(path, std::ios::binary);
    if (!os) throw std::runtime_error("gif: cannot open " + path);

    os.write("GIF89a", 6);
    char ls[7] = {
        static_cast<char>(width & 0xff), static_cast<char>((width >> 8) & 0xff),
        static_cast<char>(height & 0xff), static_cast<char>((height >> 8) & 0xff),
        static_cast<char>(0xf7), 0, 0
    };
    os.write(ls, 7);
    os.write(reinterpret_cast<const char*>(pal.data.data()), 256 * 3);

    // Netscape loop extension
    const char loop[] = {
        0x21, static_cast<char>(0xff), 0x0b,
        'N','E','T','S','C','A','P','E','2','.','0',
        0x03, 0x01, 0x00, 0x00, 0x00
    };
    os.write(loop, sizeof(loop));

    for (const auto& fr : framesRgba) {
        auto indexed = indexFrame(fr, width, height, pal);
        char gce[] = {
            0x21, static_cast<char>(0xf9), 0x04, 0x00,
            static_cast<char>(delayCs & 0xff), static_cast<char>((delayCs >> 8) & 0xff),
            0x00, 0x00
        };
        os.write(gce, 8);
        char id[] = {
            0x2c, 0,0,0,0,
            static_cast<char>(width & 0xff), static_cast<char>((width >> 8) & 0xff),
            static_cast<char>(height & 0xff), static_cast<char>((height >> 8) & 0xff),
            0x00
        };
        os.write(id, 10);
        auto lzw = lzwEncode(indexed);
        os.write(reinterpret_cast<const char*>(lzw.data()), static_cast<std::streamsize>(lzw.size()));
    }
    os.put(0x3b);
    if (!os) throw std::runtime_error("gif: write failed");
}

#if HUSH_HAS_WEBP
#include <webp/encode.h>
#include <webp/mux.h>
void writeAnimatedWebp(const std::string& path, int width, int height,
                       const std::vector<std::vector<uint8_t>>& frames,
                       int delayCs) {
    WebPAnimEncoderOptions opts;
    WebPAnimEncoderOptionsInit(&opts);
    WebPAnimEncoder* enc = WebPAnimEncoderNew(width, height, &opts);
    if (!enc) throw std::runtime_error("webp: encoder create failed");

    for (const auto& fr : frames) {
        WebPConfig config;
        WebPConfigInit(&config);
        WebPPicture pic;
        WebPPictureInit(&pic);
        pic.width = width;
        pic.height = height;
        pic.use_argb = 1;
        if (!WebPPictureImportRGBA(&pic, fr.data(), width * 4)) {
            WebPPictureFree(&pic);
            WebPAnimEncoderDelete(enc);
            throw std::runtime_error("webp: import failed");
        }
        WebPAnimEncoderAdd(enc, &pic, delayCs * 10, &config);
        WebPPictureFree(&pic);
    }
    WebPAnimEncoderAdd(enc, nullptr, 0, nullptr);
    WebPData data;
    WebPDataInit(&data);
    if (!WebPAnimEncoderAssemble(enc, &data)) {
        WebPAnimEncoderDelete(enc);
        throw std::runtime_error("webp: assemble failed");
    }
    std::ofstream os(path, std::ios::binary);
    if (!os) {
        WebPDataClear(&data);
        WebPAnimEncoderDelete(enc);
        throw std::runtime_error("webp: cannot open " + path);
    }
    os.write(reinterpret_cast<const char*>(data.bytes), static_cast<std::streamsize>(data.size));
    WebPDataClear(&data);
    WebPAnimEncoderDelete(enc);
}
#endif

} // namespace probe
} // namespace hush
