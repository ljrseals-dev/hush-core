// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <string>
#include <vector>

namespace hush {
namespace probe {

std::vector<float> extractWaveform(const std::string& path, int numBins = 512);
std::vector<std::vector<float>> extractSpectrogram(const std::string& path,
                                                   int fftSize = 1024,
                                                   int hop = 512);

} // namespace probe
} // namespace hush
