// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace hush {
namespace probe {

/// Minimal RGBA8 PNG writer (zlib stored blocks, compression level 0).
/// No libpng dependency. Throws std::runtime_error on I/O failure.
void writePngRgba8(const std::string& path,
                   int width,
                   int height,
                   const std::vector<uint8_t>& rgba);

} // namespace probe
} // namespace hush
