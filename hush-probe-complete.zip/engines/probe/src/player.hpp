// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <hush/probe/probe.hpp>
#include <atomic>
#include <thread>
#include <memory>
#include <string>

namespace hush {
namespace probe {

struct RealtimePlayer::Impl {
    std::string path_;
    std::unique_ptr<video::Movie> movie_;
    RealtimePlayer::AudioCb audioCb_;
    RealtimePlayer::VideoCb videoCb_;
    std::atomic<bool> running_{false};
    std::thread thread_;

    explicit Impl(const std::string& p);
    ~Impl();
    void stop();
    void run();
};

} // namespace probe
} // namespace hush
