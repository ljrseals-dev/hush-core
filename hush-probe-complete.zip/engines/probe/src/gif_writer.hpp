// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace hush {
namespace probe {

/// Write a simple animated GIF with a single global palette reused across frames.
void writeAnimatedGif(const std::string& path,
                      int width, int height,
                      const std::vector<std::vector<uint8_t>>& framesRgba,
                      int delayCs);

#if HUSH_HAS_WEBP
void writeAnimatedWebp(const std::string& path,
                       int width, int height,
                       const std::vector<std::vector<uint8_t>>& framesRgba,
                       int delayCs);
#endif

} // namespace probe
} // namespace hush
