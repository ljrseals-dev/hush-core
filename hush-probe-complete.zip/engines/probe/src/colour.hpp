// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <hush/video/movie.hpp>

namespace hush {
namespace probe {

enum class ColourSpace { sRGB, Linear, Rec709 };

video::Frame convertColour(const video::Frame& src, ColourSpace target);
video::Frame toneMap(const video::Frame& src, float exposure = 1.0f);

} // namespace probe
} // namespace hush
