// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include <hush/probe/probe.hpp>
#include <hush/video/movie.hpp>

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <cstdio>

#define CHECK(cond) do { \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " at " << __FILE__ << ":" << __LINE__ << "\n"; \
        std::exit(1); \
    } \
} while (0)

#define CHECK_THROWS(expr) do { \
    bool threw = false; \
    try { (void)(expr); } catch (...) { threw = true; } \
    if (!threw) { \
        std::cerr << "FAIL: expected throw from " << #expr << "\n"; \
        std::exit(1); \
    } \
} while (0)

int main() {
    // Failure mode: non-existent file
    CHECK_THROWS(hush::video::Movie("/no/such/file.mp4"));

    // PNG writer
    {
        std::vector<uint8_t> rgba(4, 255);
        hush::probe::writePngRgba8("test_1x1.png", 1, 1, rgba);
        std::ifstream f("test_1x1.png", std::ios::binary);
        CHECK(f.good());
        char sig[8];
        f.read(sig, 8);
        CHECK(sig[0] == static_cast<char>(137) && sig[1] == 'P');
        std::remove("test_1x1.png");
    }

    // JSON generation
    {
        hush::video::MovieInfo info;
        info.width = 1920;
        info.height = 1080;
        info.pixel_aspect = 1.0;
        info.duration = 10.5;
        info.frame_rate = 24.0;
        info.frame_count = 252;
        info.codec = "h264";
        info.codec_detail = "High";
        info.decodable = true;
        info.has_audio = true;
        info.quicktime = false;
        std::string j = hush::probe::movieInfoToJson(info);
        CHECK(j.find("\"width\":1920") != std::string::npos);
        CHECK(j.find("\"height\":1080") != std::string::npos);
        CHECK(j.find("\"codec\":\"h264\"") != std::string::npos);
        CHECK(j.find("\"decodable\":true") != std::string::npos);
    }

    // Waveform / spectrogram empty on missing file
    {
        auto w = hush::probe::extractWaveform("/no/such.mp4", 64);
        CHECK(w.empty());
        auto s = hush::probe::extractSpectrogram("/no/such.mp4");
        CHECK(s.empty());
    }

    // Colour conversion does not crash on empty
    {
        hush::video::Frame empty;
        auto c = hush::probe::convertColour(empty, hush::probe::ColourSpace::Linear);
        CHECK(c.empty());
        auto t = hush::probe::toneMap(empty, 1.0f);
        CHECK(t.empty());
    }

    // Argument validation
    CHECK_THROWS(hush::probe::extractThumbnails("x", 0, "./t"));
    CHECK_THROWS(hush::probe::extractThumbnails("x", 1, "./t", 0));

    // Live tests only when asset present
    if (const char* sample = std::getenv("HUSH_TEST_VIDEO")) {
        auto r = hush::probe::probe(sample, "test_info.json", 3, "./test_thumbs",
                                    80, true, "test_anim.gif", true, 256, true);
        CHECK(r.info.width > 0);
        CHECK(r.info.height > 0);
        CHECK(r.thumbnailPaths.size() == 3);
        for (const auto& p : r.thumbnailPaths) {
            std::ifstream f(p, std::ios::binary);
            CHECK(f.good());
        }
        std::ifstream j("test_info.json");
        CHECK(j.good());
        CHECK(!r.animatedPath.empty());
    } else {
        std::cout << "note: HUSH_TEST_VIDEO not set – skipping live decode test\n";
    }

    std::cout << "ALL TESTS PASSED\n";
    return 0;
}
