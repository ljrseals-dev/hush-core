// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <hush/video/movie.hpp>
#include <string>
#include <vector>
#include <cstdint>
#include <functional>
#include <memory>
#include <stdexcept>

namespace hush {
namespace probe {

struct ProbeError : public std::runtime_error {
    explicit ProbeError(const std::string& m) : std::runtime_error(m) {}
};

/// Write MovieInfo as compact JSON (no external JSON library).
std::string movieInfoToJson(const video::MovieInfo& info);

/// Extract N evenly-spaced still PNG thumbnails.
void extractThumbnails(const std::string& videoPath, int count,
                       const std::string& outDir, int maxWidth = 160);

/// Extract an animated GIF (or WebP when available) of N frames.
void extractAnimated(const std::string& videoPath, int count,
                     const std::string& outPath, int maxWidth = 160,
                     int delayCs = 10);

/// Real-time scrubbing helper: seek to time t and return the decoded frame.
video::Frame scrub(const std::string& videoPath, double tSeconds);

/// Extract a simple peak/RMS audio waveform envelope (normalised 0..1).
std::vector<float> extractWaveform(const std::string& path, int numBins = 512);

/// Simple power-of-two FFT spectrogram (magnitude, log-scaled).
std::vector<std::vector<float>> extractSpectrogram(const std::string& path,
                                                   int fftSize = 1024,
                                                   int hop = 512);

enum class ColourSpace { sRGB, Linear, Rec709 };

/// Basic transfer-function colour conversion of an RGBA8 frame.
video::Frame convertColour(const video::Frame& src, ColourSpace target);

/// Simple Reinhard tone-map with exposure control.
video::Frame toneMap(const video::Frame& src, float exposure = 1.0f);

/// Headless real-time continuous playback.
/// audioCallback receives interleaved float32 samples.
/// videoCallback receives the latest decoded frame.
class RealtimePlayer {
public:
    using AudioCb = std::function<void(const float* interleaved, int frames, int channels)>;
    using VideoCb = std::function<void(const video::Frame&)>;

    explicit RealtimePlayer(const std::string& path);
    ~RealtimePlayer();

    void setAudioCallback(AudioCb cb);
    void setVideoCallback(VideoCb cb);
    void play();   // blocking until stop() or end-of-file
    void stop();
    bool isPlaying() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

struct ProbeResult {
    video::MovieInfo info;
    std::vector<std::string> thumbnailPaths;
    std::string animatedPath;
    std::vector<float> waveform;
    std::vector<std::vector<float>> spectrogram;
};

ProbeResult probe(const std::string& videoPath,
                  const std::string& jsonPath,
                  int thumbs,
                  const std::string& outDir,
                  int maxWidth,
                  bool wantAnimated = false,
                  const std::string& animatedPath = {},
                  bool wantWaveform = false,
                  int waveformBins = 512,
                  bool wantSpectrogram = false);

} // namespace probe
} // namespace hush
