# hush-probe

Video probe, still + animated thumbnails, real-time scrubbing helper,
audio waveform / spectrogram, colour conversion and headless real-time
playback for the hush-daw project.

## Features

- Dump `MovieInfo` as JSON
- N evenly-spaced PNG thumbnails (RGBA8, zlib stored, no libpng)
- Animated GIF with global palette reuse (WebP when libwebp is found)
- Real-time single-frame scrub and headless continuous decode + audio callback
- Peak/RMS waveform envelope and simple FFT spectrogram
- sRGB ↔ linear transfer + Reinhard tone-map
- Builds cleanly with or without FFmpeg (stub throws `VideoError`)

## Build

```bash
cmake -S . -B build
cmake --build build -j
ctest --test-dir build --output-on-failure
```

## Run

```bash
./build/engines/probe/hush-probe --help

./build/engines/probe/hush-probe sample.mp4
./build/engines/probe/hush-probe sample.mp4 --json info.json --thumbs 8 --out thumbs --gif anim.gif --waveform --spectrogram
./build/engines/probe/hush-probe sample.mp4 --scrub 12.5
```

## Dependencies

- `hush::video` (mandatory)
- FFmpeg (optional at configure time)
- libwebp (optional, for WebP sequences)

## License

SPDX-License-Identifier: MIT  
Copyright (c) 2026 ljrseals-dev
