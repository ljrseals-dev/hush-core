# hush-render

Immersive mixer CLI for the hush-daw project.

## Build

From the repository root (this tree):

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

## Run

```bash
./build/engines/render/hush-render --help

# Example (after creating a mono source WAV)
./build/engines/render/hush-render scene.txt --out out.wav --levels levels.json
```

### Scene grammar

```
format <ChannelFormatName>
bed <source.wav> gain <dB>
object <name> <source.wav> az <deg> el <deg> div <0..1> size <0..1> gain <dB>
# comments and blank lines allowed
```

Supported formats: Mono, Stereo, LCR, Quad, 5.1, 7.1, 5.1.4, 7.1.4, 9.1.6, FOA, SOA, HOA3.

WAV input: 16/24/32-bit PCM and float32. Mono or stereo (stereo down-mixed unless it exactly matches the target layout, in which case it is treated as a discrete bed).

Output: interleaved float32 WAV + optional JSON speaker levels.
