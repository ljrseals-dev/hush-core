// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/render/render.hpp"
#include "hush/render/scene.hpp"
#include "hush/render/wav_io.hpp"
#include <cmath>
#include <fstream>
#include <iostream>
#include <stdexcept>

#define CHECK(cond)                                                            \
  do {                                                                         \
    if (!(cond)) {                                                             \
      std::cerr << "FAIL: " << #cond << " at " << __FILE__ << ":" << __LINE__  \
                << "\n";                                                       \
      return 1;                                                                \
    }                                                                          \
  } while (0)

static void writeMinimalWav(const std::string& path, int sr, int frames) {
  hush::render::WavData w;
  w.sampleRate = sr;
  w.channels = 1;
  w.bitsPerSample = 32;
  w.samples.assign(static_cast<size_t>(frames), 0.5f);
  hush::render::writeWav(path, w);
}

int main() {
  writeMinimalWav("test_src.wav", 48000, 100);
  {
    std::ofstream sc("test_scene.txt");
    sc << "format Stereo\n";
    sc << "bed test_src.wav gain -6\n";
    sc << "object front test_src.wav az 0 el 0 div 0 size 0 gain 0\n";
  }

  auto scene = hush::render::parseScene("test_scene.txt");
  CHECK(scene.format == hush::immersive::ChannelFormat::Stereo);
  CHECK(scene.beds.size() == 1);
  CHECK(scene.objects.size() == 1);

  auto result = hush::render::renderScene(scene);
  CHECK(result.wav.channels == 2);
  CHECK(result.wav.samples.size() == 200);
  CHECK(!result.levels.empty());

  bool threw = false;
  try {
    hush::render::readWav("does_not_exist.wav");
  } catch (const std::runtime_error&) {
    threw = true;
  }
  CHECK(threw);

  {
    std::ofstream sc("bad_scene.txt");
    sc << "format NotARealFormat\n";
  }
  threw = false;
  try {
    hush::render::parseScene("bad_scene.txt");
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  CHECK(threw);

  // Discrete multi-channel bed
  {
    hush::render::WavData stereo;
    stereo.sampleRate = 48000;
    stereo.channels = 2;
    stereo.bitsPerSample = 32;
    stereo.samples = {0.8f, -0.6f, 0.8f, -0.6f};
    hush::render::writeWav("stereo_bed.wav", stereo);

    std::ofstream sc("discrete_scene.txt");
    sc << "format Stereo\n";
    sc << "bed stereo_bed.wav gain 0\n";
    auto scn = hush::render::parseScene("discrete_scene.txt");
    auto res = hush::render::renderScene(scn);
    CHECK(res.wav.channels == 2);
    CHECK(std::abs(res.wav.samples[0] - 0.8f) < 1e-4f);
    CHECK(std::abs(res.wav.samples[1] - (-0.6f)) < 1e-4f);
  }

  std::cout << "all render tests passed\n";
  return 0;
}
