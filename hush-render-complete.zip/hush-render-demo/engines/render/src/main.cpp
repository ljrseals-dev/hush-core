// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/render/render.hpp"
#include "hush/render/scene.hpp"
#include "hush/render/wav_io.hpp"
#include <fstream>
#include <iostream>
#include <string>

static void printHelp() {
  std::cout
      << "hush-render — immersive mixer CLI\n"
      << "Usage:\n"
      << "  hush-render <scene.txt> --out <out.wav> [--levels <levels.json>]\n"
      << "  hush-render --help\n"
      << "\n"
      << "Scene grammar:\n"
      << "  format <ChannelFormatName>\n"
      << "  bed <source.wav> gain <dB>\n"
      << "  object <name> <source.wav> az <deg> el <deg> div <0..1> size <0..1> "
         "gain <dB>\n"
      << "  # comments and blank lines allowed\n";
}

int main(int argc, char** argv) {
  if (argc < 2) {
    printHelp();
    return 0;
  }
  std::string scenePath;
  std::string outPath;
  std::string levelsPath;

  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    if (a == "--help" || a == "-h") {
      printHelp();
      return 0;
    }
    if (a == "--out" && i + 1 < argc) {
      outPath = argv[++i];
    } else if (a == "--levels" && i + 1 < argc) {
      levelsPath = argv[++i];
    } else if (a[0] != '-') {
      scenePath = a;
    } else {
      std::cerr << "unknown option: " << a << "\n";
      return 1;
    }
  }

  if (scenePath.empty() || outPath.empty()) {
    std::cerr << "scene and --out are required\n";
    printHelp();
    return 1;
  }

  try {
    auto scene = hush::render::parseScene(scenePath);
    auto result = hush::render::renderScene(scene);
    hush::render::writeWav(outPath, result.wav);

    if (!levelsPath.empty()) {
      std::ofstream jf(levelsPath);
      if (!jf)
        throw std::runtime_error("cannot write levels: " + levelsPath);
      jf << "[\n";
      for (size_t i = 0; i < result.levels.size(); ++i) {
        jf << "  {\"id\":\"" << result.levels[i].first
           << "\",\"levelDb\":" << result.levels[i].second << "}";
        if (i + 1 < result.levels.size())
          jf << ",";
        jf << "\n";
      }
      jf << "]\n";
    }
  } catch (const std::exception& e) {
    std::cerr << "error: " << e.what() << "\n";
    return 1;
  }
  return 0;
}
