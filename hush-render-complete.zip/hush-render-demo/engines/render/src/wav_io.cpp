// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/render/wav_io.hpp"
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <vector>

namespace hush {
namespace render {

namespace {

uint32_t readU32(const uint8_t* p) {
  return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
         (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
}
uint16_t readU16(const uint8_t* p) {
  return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}

void writeU32(std::ostream& os, uint32_t v) {
  char b[4] = {static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff),
               static_cast<char>((v >> 16) & 0xff),
               static_cast<char>((v >> 24) & 0xff)};
  os.write(b, 4);
}
void writeU16(std::ostream& os, uint16_t v) {
  char b[2] = {static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff)};
  os.write(b, 2);
}

} // namespace

WavData readWav(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f)
    throw std::runtime_error("cannot open WAV: " + path);

  std::vector<uint8_t> buf((std::istreambuf_iterator<char>(f)),
                           std::istreambuf_iterator<char>());
  if (buf.size() < 44)
    throw std::runtime_error("WAV too short: " + path);

  if (std::memcmp(buf.data(), "RIFF", 4) != 0 ||
      std::memcmp(buf.data() + 8, "WAVE", 4) != 0)
    throw std::runtime_error("not a RIFF/WAVE file: " + path);

  size_t pos = 12;
  int sampleRate = 0, channels = 0, bits = 0, audioFormat = 0;
  const uint8_t* dataPtr = nullptr;
  size_t dataSize = 0;

  while (pos + 8 <= buf.size()) {
    const char* id = reinterpret_cast<const char*>(buf.data() + pos);
    uint32_t sz = readU32(buf.data() + pos + 4);
    pos += 8;
    if (pos + sz > buf.size())
      throw std::runtime_error("chunk size exceeds file: " + path);

    if (std::memcmp(id, "fmt ", 4) == 0) {
      if (sz < 16)
        throw std::runtime_error("fmt chunk too small");
      audioFormat = readU16(buf.data() + pos);
      channels = readU16(buf.data() + pos + 2);
      sampleRate = static_cast<int>(readU32(buf.data() + pos + 4));
      bits = readU16(buf.data() + pos + 14);
    } else if (std::memcmp(id, "data", 4) == 0) {
      dataPtr = buf.data() + pos;
      dataSize = sz;
    }
    pos += sz + (sz & 1); // word align
  }

  if (!dataPtr || channels <= 0 || sampleRate <= 0)
    throw std::runtime_error("missing fmt or data chunk: " + path);

  WavData out;
  out.sampleRate = sampleRate;
  out.channels = channels;
  out.bitsPerSample = bits;

  const size_t frameBytes = static_cast<size_t>(channels * (bits / 8));
  if (frameBytes == 0 || dataSize % frameBytes != 0)
    throw std::runtime_error("inconsistent data size: " + path);

  const size_t frames = dataSize / frameBytes;
  out.samples.resize(frames * static_cast<size_t>(channels));

  if (audioFormat == 1) { // PCM
    if (bits == 16) {
      for (size_t i = 0; i < frames * static_cast<size_t>(channels); ++i) {
        int16_t s = static_cast<int16_t>(readU16(dataPtr + i * 2));
        out.samples[i] = static_cast<float>(s) / 32768.f;
      }
    } else if (bits == 24) {
      for (size_t i = 0; i < frames * static_cast<size_t>(channels); ++i) {
        const uint8_t* p = dataPtr + i * 3;
        int32_t s = (static_cast<int32_t>(p[0]) << 8) |
                    (static_cast<int32_t>(p[1]) << 16) |
                    (static_cast<int32_t>(p[2]) << 24);
        s >>= 8;
        out.samples[i] = static_cast<float>(s) / 8388608.f;
      }
    } else if (bits == 32) {
      for (size_t i = 0; i < frames * static_cast<size_t>(channels); ++i) {
        int32_t s = static_cast<int32_t>(readU32(dataPtr + i * 4));
        out.samples[i] = static_cast<float>(s) / 2147483648.f;
      }
    } else {
      throw std::runtime_error("unsupported PCM bit depth: " + path);
    }
  } else if (audioFormat == 3 && bits == 32) { // IEEE float
    for (size_t i = 0; i < frames * static_cast<size_t>(channels); ++i) {
      float v;
      std::memcpy(&v, dataPtr + i * 4, 4);
      out.samples[i] = v;
    }
  } else {
    throw std::runtime_error("unsupported WAV format (only PCM 16/24/32 and float32): " +
                             path);
  }
  return out;
}

void writeWav(const std::string& path, const WavData& data) {
  if (data.channels <= 0 || data.sampleRate <= 0)
    throw std::runtime_error("invalid WavData for write");

  const uint32_t dataBytes =
      static_cast<uint32_t>(data.samples.size() * sizeof(float));
  const uint32_t fmtSize = 16;
  const uint32_t riffSize = 4 + (8 + fmtSize) + (8 + dataBytes);

  std::ofstream f(path, std::ios::binary);
  if (!f)
    throw std::runtime_error("cannot create WAV: " + path);

  f.write("RIFF", 4);
  writeU32(f, riffSize);
  f.write("WAVE", 4);

  f.write("fmt ", 4);
  writeU32(f, fmtSize);
  writeU16(f, 3); // IEEE float
  writeU16(f, static_cast<uint16_t>(data.channels));
  writeU32(f, static_cast<uint32_t>(data.sampleRate));
  const uint32_t byteRate =
      static_cast<uint32_t>(data.sampleRate * data.channels * sizeof(float));
  writeU32(f, byteRate);
  writeU16(f, static_cast<uint16_t>(data.channels * sizeof(float)));
  writeU16(f, 32);

  f.write("data", 4);
  writeU32(f, dataBytes);
  f.write(reinterpret_cast<const char*>(data.samples.data()),
          static_cast<std::streamsize>(dataBytes));
}

} // namespace render
} // namespace hush
