// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/render/render.hpp"
#include "hush/immersive/renderer.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace hush {
namespace render {

namespace {
float dbToLin(double db) {
  return static_cast<float>(std::pow(10.0, db / 20.0));
}
} // namespace

RenderResult renderScene(const Scene& scene) {
  const int nCh = immersive::channelCount(scene.format);
  immersive::Renderer renderer(scene.format);

  struct Source {
    WavData wav;
    immersive::PannerState state;
    bool isBed = false;
    bool discrete = false;
  };
  std::vector<Source> sources;
  int sampleRate = 48000;
  size_t maxFrames = 0;

  auto load = [&](const std::string& path, const immersive::PannerState& st,
                  bool bed) {
    WavData w = readWav(path);
    const bool canDiscrete = bed && (w.channels == nCh);
    if (!canDiscrete && w.channels != 1 && w.channels != 2)
      throw std::runtime_error(
          "source must be mono, stereo, or match target channel count: " + path);

    if (!canDiscrete && w.channels == 2) {
      std::vector<float> mono(w.samples.size() / 2);
      for (size_t i = 0; i < mono.size(); ++i)
        mono[i] = 0.5f * (w.samples[i * 2] + w.samples[i * 2 + 1]);
      w.samples = std::move(mono);
      w.channels = 1;
    }

    sampleRate = w.sampleRate;
    maxFrames = std::max(maxFrames,
                         w.samples.size() / static_cast<size_t>(std::max(1, w.channels)));
    sources.push_back({std::move(w), st, bed, canDiscrete});
  };

  for (const auto& b : scene.beds) {
    immersive::PannerState st;
    st.gainDb = b.gainDb;
    load(b.path, st, true);
  }
  for (const auto& o : scene.objects)
    load(o.path, o.state, false);

  if (sources.empty())
    throw std::runtime_error("scene contains no audio sources");

  WavData out;
  out.sampleRate = sampleRate;
  out.channels = nCh;
  out.bitsPerSample = 32;
  out.samples.assign(maxFrames * static_cast<size_t>(nCh), 0.f);

  for (size_t frame = 0; frame < maxFrames; ++frame) {
    float* dest = out.samples.data() + frame * static_cast<size_t>(nCh);

    for (const auto& src : sources) {
      if (src.discrete) {
        const size_t base = frame * static_cast<size_t>(nCh);
        if (base + static_cast<size_t>(nCh) <= src.wav.samples.size()) {
          const float g = dbToLin(src.state.gainDb);
          for (int c = 0; c < nCh; ++c)
            dest[c] += src.wav.samples[base + static_cast<size_t>(c)] * g;
        }
      } else {
        float sample = 0.f;
        if (frame < src.wav.samples.size())
          sample = src.wav.samples[frame];
        renderer.process(sample, src.state, dest);
      }
    }
  }

  RenderResult result;
  result.wav = std::move(out);
  const auto& speakers = immersive::speakersFor(scene.format);
  const auto& levels = renderer.levelsDb();
  for (size_t i = 0; i < speakers.size(); ++i)
    result.levels.emplace_back(speakers[i].id, levels[i]);
  return result;
}

} // namespace render
} // namespace hush
