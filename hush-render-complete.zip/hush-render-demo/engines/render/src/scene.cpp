// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/render/scene.hpp"
#include <fstream>
#include <sstream>
#include <stdexcept>

namespace hush {
namespace render {

Scene parseScene(const std::string& path) {
  std::ifstream f(path);
  if (!f)
    throw std::runtime_error("cannot open scene: " + path);

  Scene scene;
  std::string line;
  int lineNo = 0;
  while (std::getline(f, line)) {
    ++lineNo;
    auto hash = line.find('#');
    if (hash != std::string::npos)
      line.resize(hash);
    size_t start = line.find_first_not_of(" \t\r\n");
    if (start == std::string::npos)
      continue;
    size_t end = line.find_last_not_of(" \t\r\n");
    line = line.substr(start, end - start + 1);

    std::istringstream iss(line);
    std::string cmd;
    iss >> cmd;
    if (cmd == "format") {
      std::string name;
      iss >> name;
      if (name.empty())
        throw std::runtime_error("line " + std::to_string(lineNo) +
                                 ": format requires a name");
      scene.format = immersive::parseChannelFormat(name);
    } else if (cmd == "bed") {
      Bed b;
      iss >> b.path;
      std::string tok;
      while (iss >> tok) {
        if (tok == "gain") {
          if (!(iss >> b.gainDb))
            throw std::runtime_error("line " + std::to_string(lineNo) +
                                     ": gain expects a number");
        } else {
          throw std::runtime_error("line " + std::to_string(lineNo) +
                                   ": unexpected token in bed: " + tok);
        }
      }
      if (b.path.empty())
        throw std::runtime_error("line " + std::to_string(lineNo) +
                                 ": bed requires a path");
      scene.beds.push_back(std::move(b));
    } else if (cmd == "object") {
      Object o;
      iss >> o.name >> o.path;
      if (o.name.empty() || o.path.empty())
        throw std::runtime_error("line " + std::to_string(lineNo) +
                                 ": object requires name and path");
      std::string tok;
      while (iss >> tok) {
        if (tok == "az") {
          if (!(iss >> o.state.azimuthDeg))
            throw std::runtime_error("bad az");
        } else if (tok == "el") {
          if (!(iss >> o.state.elevationDeg))
            throw std::runtime_error("bad el");
        } else if (tok == "div") {
          if (!(iss >> o.state.divergence))
            throw std::runtime_error("bad div");
        } else if (tok == "size") {
          if (!(iss >> o.state.size))
            throw std::runtime_error("bad size");
        } else if (tok == "gain") {
          if (!(iss >> o.state.gainDb))
            throw std::runtime_error("bad gain");
        } else {
          throw std::runtime_error("line " + std::to_string(lineNo) +
                                   ": unexpected token in object: " + tok);
        }
      }
      scene.objects.push_back(std::move(o));
    } else {
      throw std::runtime_error("line " + std::to_string(lineNo) +
                               ": unknown command: " + cmd);
    }
  }
  return scene;
}

} // namespace render
} // namespace hush
