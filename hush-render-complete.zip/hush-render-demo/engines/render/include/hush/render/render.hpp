// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "hush/render/scene.hpp"
#include "hush/render/wav_io.hpp"
#include <string>
#include <utility>
#include <vector>

namespace hush {
namespace render {

struct RenderResult {
  WavData wav;
  std::vector<std::pair<std::string, float>> levels; // id, levelDb
};

// Renders the scene offline. All sources are mixed at the sample rate of the
// first successfully loaded source (or 48000 if none). Throws on I/O errors.
RenderResult renderScene(const Scene& scene);

} // namespace render
} // namespace hush
