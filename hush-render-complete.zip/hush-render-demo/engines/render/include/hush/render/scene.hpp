// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "hush/immersive/channel_format.hpp"
#include "hush/immersive/panner_state.hpp"
#include <string>
#include <vector>

namespace hush {
namespace render {

struct Bed {
  std::string path;
  double gainDb = 0.0;
};

struct Object {
  std::string name;
  std::string path;
  immersive::PannerState state;
};

struct Scene {
  immersive::ChannelFormat format = immersive::ChannelFormat::Stereo;
  std::vector<Bed> beds;
  std::vector<Object> objects;
};

// Parses the documented scene grammar. Throws on syntax / semantic errors.
Scene parseScene(const std::string& path);

} // namespace render
} // namespace hush
