// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace hush {
namespace render {

struct WavData {
  int sampleRate = 0;
  int channels = 0;
  int bitsPerSample = 0;
  std::vector<float> samples; // interleaved, normalised to [-1,1]
};

// Minimal std::-only reader. Supports 16/24/32-bit PCM and IEEE float32.
// Throws std::runtime_error on any I/O or format error.
WavData readWav(const std::string& path);

// Writes interleaved float32 WAV (IEEE).
void writeWav(const std::string& path, const WavData& data);

} // namespace render
} // namespace hush
