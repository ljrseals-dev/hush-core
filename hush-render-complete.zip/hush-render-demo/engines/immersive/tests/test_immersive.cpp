// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/immersive/channel_format.hpp"
#include "hush/immersive/panner.hpp"
#include "hush/immersive/renderer.hpp"
#include <cmath>
#include <iostream>
#include <stdexcept>

#define CHECK(cond)                                                            \
  do {                                                                         \
    if (!(cond)) {                                                             \
      std::cerr << "FAIL: " << #cond << " at " << __FILE__ << ":" << __LINE__  \
                << "\n";                                                       \
      return 1;                                                                \
    }                                                                          \
  } while (0)

int main() {
  using namespace hush::immersive;

  CHECK(channelCount(ChannelFormat::Mono) == 1);
  CHECK(channelCount(ChannelFormat::Stereo) == 2);
  CHECK(channelCount(ChannelFormat::SevenPointOne) == 8);
  CHECK(channelCount(ChannelFormat::AmbisonicsFOA) == 4);
  CHECK(channelCount(ChannelFormat::AmbisonicsSOA) == 9);
  CHECK(channelCount(ChannelFormat::AmbisonicsHOA3) == 16);

  bool threw = false;
  try {
    speakersFor(static_cast<ChannelFormat>(999));
  } catch (const std::invalid_argument&) {
    threw = true;
  }
  CHECK(threw);

  // FOA reference (front centre)
  PannerState front;
  front.azimuthDeg = 0.0;
  front.elevationDeg = 0.0;
  front.gainDb = 0.0;
  auto g = pan(front, ChannelFormat::AmbisonicsFOA);
  CHECK(g.size() == 4);
  const float wRef = static_cast<float>(1.0 / std::sqrt(2.0));
  CHECK(std::abs(g[0] - wRef) < 1e-4f);
  CHECK(std::abs(g[1]) < 1e-4f);
  CHECK(std::abs(g[2]) < 1e-4f);
  CHECK(std::abs(g[3] - 1.f) < 1e-4f);

  // SOA / HOA3 non-zero higher channels
  PannerState side;
  side.azimuthDeg = 90.0;
  side.elevationDeg = 0.0;
  auto g2 = pan(side, ChannelFormat::AmbisonicsSOA);
  CHECK(g2.size() == 9);
  CHECK(std::abs(g2[1]) > 0.3f); // Y significant

  auto g3 = pan(side, ChannelFormat::AmbisonicsHOA3);
  CHECK(g3.size() == 16);
  CHECK(std::abs(g3[1]) > 0.3f);

  Renderer r(ChannelFormat::Stereo);
  float out[2] = {0.f, 0.f};
  r.process(1.0f, front, out);
  CHECK(r.levelsDb().size() == 2);

  std::cout << "all immersive tests passed\n";
  return 0;
}
