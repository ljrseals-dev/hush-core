// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "hush/immersive/channel_format.hpp"
#include "hush/immersive/panner_state.hpp"
#include <string>
#include <vector>

namespace hush {
namespace immersive {

class Renderer {
public:
  explicit Renderer(ChannelFormat fmt);

  // Mix one mono input frame into the output buffer using the given panner state.
  // out must have size == channelCount(fmt).
  void process(float monoSample, const PannerState& state, float* out);

  // Live peak levels in dB (one entry per speaker, updated after each process call).
  const std::vector<float>& levelsDb() const { return levelsDb_; }

  ChannelFormat format() const { return fmt_; }

private:
  ChannelFormat fmt_;
  std::vector<float> levelsDb_;
  std::vector<float> peakAbs_;
};

} // namespace immersive
} // namespace hush
