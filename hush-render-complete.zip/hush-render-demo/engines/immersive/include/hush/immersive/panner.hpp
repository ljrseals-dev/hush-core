// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include "hush/immersive/channel_format.hpp"
#include "hush/immersive/panner_state.hpp"
#include <vector>

namespace hush {
namespace immersive {

// Portable π (C++17 does not guarantee M_PI).
inline constexpr double kPi = 3.14159265358979323846;

// Returns gains for every speaker in the layout.
// For AmbisonicsFOA / SOA / HOA3 the gains are the ACN/SN3D encoding coefficients.
// For discrete layouts a simple VBAP-style nearest-speaker + size spread is used.
// Throws on unsupported format (already guaranteed by speakersFor).
std::vector<float> pan(const PannerState& state, ChannelFormat fmt);

} // namespace immersive
} // namespace hush
