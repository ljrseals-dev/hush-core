// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

namespace hush {
namespace immersive {

struct PannerState {
  double azimuthDeg   = 0.0;
  double elevationDeg = 0.0;
  double divergence   = 0.0; // 0..1
  double size         = 0.0; // 0..1
  double gainDb       = 0.0;
  double distance     = 0.0; // metres; 0 = on unit sphere (default preserves old behaviour)
  double screenAnchor = 0.0; // 0..1
};

} // namespace immersive
} // namespace hush
