// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#pragma once

#include <stdexcept>
#include <string>
#include <vector>

namespace hush {
namespace immersive {

enum class ChannelFormat {
  Mono,
  Stereo,
  LCR,
  Quad,
  FivePointOne,
  SevenPointOne,
  FivePointOneFour,
  SevenPointOneFour,
  NinePointOneSix,
  AmbisonicsFOA,   // 4 channels, ACN/SN3D
  AmbisonicsSOA,   // 9 channels
  AmbisonicsHOA3   // 16 channels
};

struct Speaker {
  std::string id;
  double azimuthDeg = 0.0;   // degrees, 0 = front, positive = left
  double elevationDeg = 0.0;
  double x = 0.0, y = 0.0, z = 0.0; // unit sphere
};

// Returns the canonical speaker list for the format.
// Throws std::invalid_argument for any unsupported / unknown format.
// Never silently falls back to 7.1.
const std::vector<Speaker>& speakersFor(ChannelFormat fmt);

int channelCount(ChannelFormat fmt);

ChannelFormat parseChannelFormat(const std::string& name);
std::string toString(ChannelFormat fmt);

} // namespace immersive
} // namespace hush
