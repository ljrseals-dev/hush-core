// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/immersive/renderer.hpp"
#include "hush/immersive/panner.hpp"
#include <algorithm>
#include <cmath>

namespace hush {
namespace immersive {

Renderer::Renderer(ChannelFormat fmt)
    : fmt_(fmt), levelsDb_(static_cast<size_t>(channelCount(fmt)), -120.f),
      peakAbs_(static_cast<size_t>(channelCount(fmt)), 0.f) {}

void Renderer::process(float monoSample, const PannerState& state, float* out) {
  const auto gains = pan(state, fmt_);
  const int n = static_cast<int>(gains.size());
  for (int i = 0; i < n; ++i) {
    out[i] += monoSample * gains[static_cast<size_t>(i)];
    peakAbs_[static_cast<size_t>(i)] = std::max(peakAbs_[static_cast<size_t>(i)], std::abs(out[i]));
    levelsDb_[static_cast<size_t>(i)] = peakAbs_[static_cast<size_t>(i)] > 1e-6f
                       ? 20.f * std::log10(peakAbs_[static_cast<size_t>(i)])
                       : -120.f;
  }
}

} // namespace immersive
} // namespace hush
