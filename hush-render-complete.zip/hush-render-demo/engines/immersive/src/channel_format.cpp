// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/immersive/channel_format.hpp"
#include "hush/immersive/panner.hpp" // for kPi
#include <cmath>
#include <unordered_map>

namespace hush {
namespace immersive {

namespace {

Speaker makeSpeaker(const std::string& id, double az, double el) {
  Speaker s;
  s.id = id;
  s.azimuthDeg = az;
  s.elevationDeg = el;
  const double azr = az * kPi / 180.0;
  const double elr = el * kPi / 180.0;
  s.x = std::cos(elr) * std::sin(azr);
  s.y = std::cos(elr) * std::cos(azr);
  s.z = std::sin(elr);
  return s;
}

const std::vector<Speaker>& mono() {
  static const std::vector<Speaker> s{makeSpeaker("M", 0.0, 0.0)};
  return s;
}
const std::vector<Speaker>& stereo() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0)};
  return s;
}
const std::vector<Speaker>& lcr() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("C", 0.0, 0.0),
      makeSpeaker("R", -30.0, 0.0)};
  return s;
}
const std::vector<Speaker>& quad() {
  static const std::vector<Speaker> s{
      makeSpeaker("FL", 45.0, 0.0), makeSpeaker("FR", -45.0, 0.0),
      makeSpeaker("RL", 135.0, 0.0), makeSpeaker("RR", -135.0, 0.0)};
  return s;
}
const std::vector<Speaker>& fivePointOne() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0),
      makeSpeaker("C", 0.0, 0.0), makeSpeaker("LFE", 0.0, -90.0),
      makeSpeaker("Ls", 110.0, 0.0), makeSpeaker("Rs", -110.0, 0.0)};
  return s;
}
const std::vector<Speaker>& sevenPointOne() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0),
      makeSpeaker("C", 0.0, 0.0), makeSpeaker("LFE", 0.0, -90.0),
      makeSpeaker("Ls", 90.0, 0.0), makeSpeaker("Rs", -90.0, 0.0),
      makeSpeaker("Lrs", 150.0, 0.0), makeSpeaker("Rrs", -150.0, 0.0)};
  return s;
}
const std::vector<Speaker>& fivePointOneFour() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0),
      makeSpeaker("C", 0.0, 0.0), makeSpeaker("LFE", 0.0, -90.0),
      makeSpeaker("Ls", 110.0, 0.0), makeSpeaker("Rs", -110.0, 0.0),
      makeSpeaker("Tfl", 45.0, 45.0), makeSpeaker("Tfr", -45.0, 45.0),
      makeSpeaker("Tbl", 135.0, 45.0), makeSpeaker("Tbr", -135.0, 45.0)};
  return s;
}
const std::vector<Speaker>& sevenPointOneFour() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0),
      makeSpeaker("C", 0.0, 0.0), makeSpeaker("LFE", 0.0, -90.0),
      makeSpeaker("Ls", 90.0, 0.0), makeSpeaker("Rs", -90.0, 0.0),
      makeSpeaker("Lrs", 150.0, 0.0), makeSpeaker("Rrs", -150.0, 0.0),
      makeSpeaker("Tfl", 45.0, 45.0), makeSpeaker("Tfr", -45.0, 45.0),
      makeSpeaker("Tbl", 135.0, 45.0), makeSpeaker("Tbr", -135.0, 45.0)};
  return s;
}
const std::vector<Speaker>& ninePointOneSix() {
  static const std::vector<Speaker> s{
      makeSpeaker("L", 30.0, 0.0), makeSpeaker("R", -30.0, 0.0),
      makeSpeaker("C", 0.0, 0.0), makeSpeaker("LFE", 0.0, -90.0),
      makeSpeaker("Lw", 60.0, 0.0), makeSpeaker("Rw", -60.0, 0.0),
      makeSpeaker("Ls", 90.0, 0.0), makeSpeaker("Rs", -90.0, 0.0),
      makeSpeaker("Lrs", 150.0, 0.0), makeSpeaker("Rrs", -150.0, 0.0),
      makeSpeaker("Tfl", 45.0, 45.0), makeSpeaker("Tfr", -45.0, 45.0),
      makeSpeaker("Tfc", 0.0, 45.0), makeSpeaker("Tbl", 135.0, 45.0),
      makeSpeaker("Tbr", -135.0, 45.0), makeSpeaker("Tbc", 180.0, 45.0)};
  return s;
}
const std::vector<Speaker>& foa() {
  static const std::vector<Speaker> s{
      makeSpeaker("W", 0.0, 0.0), makeSpeaker("Y", 90.0, 0.0),
      makeSpeaker("Z", 0.0, 90.0), makeSpeaker("X", 0.0, 0.0)};
  return s;
}
const std::vector<Speaker>& soa() {
  static const std::vector<Speaker> s(9, makeSpeaker("ACn", 0.0, 0.0));
  return s;
}
const std::vector<Speaker>& hoa3() {
  static const std::vector<Speaker> s(16, makeSpeaker("ACn", 0.0, 0.0));
  return s;
}

} // namespace

const std::vector<Speaker>& speakersFor(ChannelFormat fmt) {
  switch (fmt) {
  case ChannelFormat::Mono:            return mono();
  case ChannelFormat::Stereo:          return stereo();
  case ChannelFormat::LCR:             return lcr();
  case ChannelFormat::Quad:            return quad();
  case ChannelFormat::FivePointOne:    return fivePointOne();
  case ChannelFormat::SevenPointOne:   return sevenPointOne();
  case ChannelFormat::FivePointOneFour:return fivePointOneFour();
  case ChannelFormat::SevenPointOneFour:return sevenPointOneFour();
  case ChannelFormat::NinePointOneSix: return ninePointOneSix();
  case ChannelFormat::AmbisonicsFOA:   return foa();
  case ChannelFormat::AmbisonicsSOA:   return soa();
  case ChannelFormat::AmbisonicsHOA3:  return hoa3();
  }
  throw std::invalid_argument("unsupported ChannelFormat");
}

int channelCount(ChannelFormat fmt) {
  return static_cast<int>(speakersFor(fmt).size());
}

ChannelFormat parseChannelFormat(const std::string& name) {
  static const std::unordered_map<std::string, ChannelFormat> map = {
      {"Mono", ChannelFormat::Mono},
      {"Stereo", ChannelFormat::Stereo},
      {"LCR", ChannelFormat::LCR},
      {"Quad", ChannelFormat::Quad},
      {"5.1", ChannelFormat::FivePointOne},
      {"7.1", ChannelFormat::SevenPointOne},
      {"5.1.4", ChannelFormat::FivePointOneFour},
      {"7.1.4", ChannelFormat::SevenPointOneFour},
      {"9.1.6", ChannelFormat::NinePointOneSix},
      {"FOA", ChannelFormat::AmbisonicsFOA},
      {"AmbisonicsFOA", ChannelFormat::AmbisonicsFOA},
      {"SOA", ChannelFormat::AmbisonicsSOA},
      {"HOA3", ChannelFormat::AmbisonicsHOA3}};
  auto it = map.find(name);
  if (it == map.end())
    throw std::invalid_argument("unknown channel format: " + name);
  return it->second;
}

std::string toString(ChannelFormat fmt) {
  switch (fmt) {
  case ChannelFormat::Mono: return "Mono";
  case ChannelFormat::Stereo: return "Stereo";
  case ChannelFormat::LCR: return "LCR";
  case ChannelFormat::Quad: return "Quad";
  case ChannelFormat::FivePointOne: return "5.1";
  case ChannelFormat::SevenPointOne: return "7.1";
  case ChannelFormat::FivePointOneFour: return "5.1.4";
  case ChannelFormat::SevenPointOneFour: return "7.1.4";
  case ChannelFormat::NinePointOneSix: return "9.1.6";
  case ChannelFormat::AmbisonicsFOA: return "FOA";
  case ChannelFormat::AmbisonicsSOA: return "SOA";
  case ChannelFormat::AmbisonicsHOA3: return "HOA3";
  }
  throw std::invalid_argument("unsupported ChannelFormat");
}

} // namespace immersive
} // namespace hush
