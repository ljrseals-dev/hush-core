// SPDX-License-Identifier: MIT
// Copyright (c) 2026 ljrseals-dev
#include "hush/immersive/panner.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace hush {
namespace immersive {

namespace {

float dbToLin(double db) {
  return static_cast<float>(std::pow(10.0, db / 20.0));
}

// Associated Legendre (stable for l ≤ 3)
double legendre(int l, int m, double x) {
  if (l == 0) return 1.0;
  if (l == 1) {
    if (m == 0) return x;
    if (m == 1) return -std::sqrt(std::max(0.0, 1.0 - x * x));
  }
  if (l == 2) {
    if (m == 0) return 0.5 * (3.0 * x * x - 1.0);
    if (m == 1) return -3.0 * x * std::sqrt(std::max(0.0, 1.0 - x * x));
    if (m == 2) return 3.0 * (1.0 - x * x);
  }
  if (l == 3) {
    if (m == 0) return 0.5 * x * (5.0 * x * x - 3.0);
    if (m == 1) return -1.5 * (5.0 * x * x - 1.0) * std::sqrt(std::max(0.0, 1.0 - x * x));
    if (m == 2) return 15.0 * x * (1.0 - x * x);
    if (m == 3) return -15.0 * (1.0 - x * x) * std::sqrt(std::max(0.0, 1.0 - x * x));
  }
  return 0.0;
}

double sn3dFactor(int /*l*/, int m) {
  if (m == 0) return 1.0;
  return 1.0 / std::sqrt(2.0);
}

double sh(int l, int m, double az, double el) {
  // el is elevation from horizon; polar theta = pi/2 - el → cos(theta) = sin(el)
  const double cosTheta = std::sin(el);
  const double phi = az;
  const double p = legendre(l, std::abs(m), cosTheta);
  // SN3D: W (l=0) scaled by 1/√2; m≠0 already handled by sn3dFactor
  if (l == 0) return p / std::sqrt(2.0);
  const double norm = sn3dFactor(l, m);
  if (m > 0) return norm * p * std::cos(static_cast<double>(m) * phi);
  if (m < 0) return norm * p * std::sin(static_cast<double>(-m) * phi);
  return p;
}

void acnToLM(int acn, int& l, int& m) {
  l = static_cast<int>(std::floor(std::sqrt(static_cast<double>(acn))));
  m = acn - l * l - l;
}

std::vector<float> encodeAmbisonics(const PannerState& st, int order) {
  const int nCh = (order + 1) * (order + 1);
  std::vector<float> g(static_cast<size_t>(nCh), 0.f);
  const double az = st.azimuthDeg * kPi / 180.0;
  const double el = st.elevationDeg * kPi / 180.0;
  const float gain = dbToLin(st.gainDb);

  // Classic SN3D FOA (order 1) – exact reference values
  // ACN: 0=W, 1=Y, 2=Z, 3=X
  if (order >= 1) {
    g[0] = static_cast<float>(1.0 / std::sqrt(2.0)) * gain;          // W
    g[1] = static_cast<float>(std::sin(az) * std::cos(el)) * gain;   // Y
    g[2] = static_cast<float>(std::sin(el)) * gain;                  // Z
    g[3] = static_cast<float>(std::cos(az) * std::cos(el)) * gain;   // X
  }

  // Higher orders: place remaining energy via the general SH path
  // (correct channel count; full N3D/SN3D tables can be refined later)
  if (order >= 2) {
    for (int acn = 4; acn < nCh; ++acn) {
      int l = 0, m = 0;
      acnToLM(acn, l, m);
      g[static_cast<size_t>(acn)] = static_cast<float>(sh(l, m, az, el)) * gain;
    }
  }

  if (st.distance > 0.0) {
    const float att = static_cast<float>(1.0 / std::max(st.distance * st.distance, 0.1));
    for (auto& v : g) v *= att;
  }
  return g;
}

std::vector<float> vbapLike(const PannerState& st, ChannelFormat fmt) {
  const auto& speakers = speakersFor(fmt);
  const int n = static_cast<int>(speakers.size());
  std::vector<float> gains(static_cast<size_t>(n), 0.f);
  if (n == 0) return gains;

  const double az = st.azimuthDeg * kPi / 180.0;
  const double el = st.elevationDeg * kPi / 180.0;
  const float sx = static_cast<float>(std::cos(el) * std::sin(az));
  const float sy = static_cast<float>(std::cos(el) * std::cos(az));
  const float sz = static_cast<float>(std::sin(el));

  int best = 0;
  float bestDot = -2.f;
  for (int i = 0; i < n; ++i) {
    const float dot = sx * static_cast<float>(speakers[static_cast<size_t>(i)].x) +
                      sy * static_cast<float>(speakers[static_cast<size_t>(i)].y) +
                      sz * static_cast<float>(speakers[static_cast<size_t>(i)].z);
    if (dot > bestDot) {
      bestDot = dot;
      best = i;
    }
  }

  const float g = dbToLin(st.gainDb);
  const float size = static_cast<float>(std::clamp(st.size, 0.0, 1.0));
  gains[static_cast<size_t>(best)] = g * (1.f - size * 0.7f);
  if (size > 0.f && n > 1) {
    const float spread = g * size * 0.7f / static_cast<float>(n - 1);
    for (int i = 0; i < n; ++i)
      if (i != best) gains[static_cast<size_t>(i)] += spread;
  } else {
    gains[static_cast<size_t>(best)] = g;
  }

  if (st.distance > 0.0) {
    const float att = static_cast<float>(1.0 / std::max(st.distance * st.distance, 0.1));
    for (auto& v : gains) v *= att;
  }
  return gains;
}

} // namespace

std::vector<float> pan(const PannerState& state, ChannelFormat fmt) {
  switch (fmt) {
  case ChannelFormat::AmbisonicsFOA:
    return encodeAmbisonics(state, 1);
  case ChannelFormat::AmbisonicsSOA:
    return encodeAmbisonics(state, 2);
  case ChannelFormat::AmbisonicsHOA3:
    return encodeAmbisonics(state, 3);
  default:
    return vbapLike(state, fmt);
  }
}

} // namespace immersive
} // namespace hush
